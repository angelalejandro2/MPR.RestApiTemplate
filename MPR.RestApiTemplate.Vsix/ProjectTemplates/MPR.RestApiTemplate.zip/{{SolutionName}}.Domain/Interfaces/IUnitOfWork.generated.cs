﻿using {{SolutionName}}.Domain.Interfaces.Repositories;

namespace {{SolutionName}}.Domain.Interfaces
{
	public partial interface IUnitOfWork : IDisposable
	{
		// TODO: Add repository interfaces here

		Task<int> SaveChangesAsync();
	}
}