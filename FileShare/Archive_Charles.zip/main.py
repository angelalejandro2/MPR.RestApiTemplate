import os
import json
from datetime import datetime
from dotenv import load_dotenv
from src.crew.insurance_crew import InsuranceProcessingCrew
from src.utils.logger import setup_logger
from src.utils.validation import PipelineValidator
from src.utils.ollama_check import check_ollama_connection
from src.config.constants import OUTPUT_DIRECTORIES

load_dotenv()

logger = setup_logger(__name__)

def cleanup_previous_run():
    """Clean up outputs, logs, and checkpoints from previous runs"""
    import shutil
    import glob
    
    cleanup_paths = [
        "./data/checkpoint.json",
        "./data/form_results/*.md",
        "./data/question_results/*.md", 
        "./data/decision_trees/*.md",
        "./data/decision_trees/manifest.json",
        "./data/qa_reports/*.md",
        "./logs/*.log"
    ]
    
    print("🧹 Cleaning up previous run outputs...")
    
    for pattern in cleanup_paths:
        if '*' in pattern:
            # Use glob for wildcard patterns
            files = glob.glob(pattern)
            for file_path in files:
                try:
                    os.remove(file_path)
                    print(f"  ✓ Removed: {file_path}")
                except:
                    pass
        else:
            # Direct file removal
            try:
                if os.path.exists(pattern):
                    os.remove(pattern)
                    print(f"  ✓ Removed: {pattern}")
            except:
                pass
    
    print("🧹 Cleanup completed\n")

def _check_gpu_acceleration():
    """Check if GPU acceleration is available for Ollama"""
    try:
        import subprocess
        import platform
        
        # Check if NVIDIA GPU is available
        if platform.system() in ["Linux", "Windows"]:
            result = subprocess.run(["nvidia-smi"], capture_output=True, text=True)
            if result.returncode == 0:
                print("🎯 NVIDIA GPU detected")
                return True
        
        # Check if Apple Silicon is available
        if platform.system() == "Darwin":
            result = subprocess.run(["sysctl", "-n", "machdep.cpu.brand_string"], capture_output=True, text=True)
            if "Apple" in result.stdout:
                print("🍎 Apple Silicon detected - Metal acceleration available")
                return True
        
        print("💻 Using CPU processing")
        return False
    except:
        print("💻 Using CPU processing (GPU check failed)")
        return False

def _load_checkpoint():
    """Load processing checkpoint if exists"""
    checkpoint_file = "./data/batch_checkpoint.json"
    if os.path.exists(checkpoint_file):
        try:
            with open(checkpoint_file, 'r') as f:
                return json.load(f)
        except:
            return None
    return None

def _save_checkpoint(checkpoint_data):
    """Save processing checkpoint"""
    checkpoint_file = "./data/batch_checkpoint.json"
    try:
        with open(checkpoint_file, 'w') as f:
            json.dump(checkpoint_data, f, indent=2)
    except Exception as e:
        print(f"⚠️ Could not save checkpoint: {e}")

def _process_single_form_batch(form_file, input_dir, llm, checkpoint=None):
    """Process a single form through all 6 steps with checkpointing"""
    base_name = os.path.splitext(form_file)[0]
    form_path = os.path.join(input_dir, form_file)
    
    # Initialize step tracking
    completed_steps = checkpoint.get('completed_steps', {}) if checkpoint else {}
    form_steps = completed_steps.get(form_file, [])
    
    print(f"\n📋 Processing: {form_file} (Steps completed: {len(form_steps)}/6)")
    
    result = {
        "form_file": form_file,
        "form_result": None,
        "questions_result": None,
        "tree_result": None,
        "steps_completed": form_steps.copy()
    }
    
    return result

def run_simple_mode():
    """Simple mode with batch processing and checkpointing - one form at a time"""
    print("🚀 Running in Simple Mode with Batch Processing (bypassing CrewAI)")
    
    # Import our working tools
    from src.tools.parsing.form_extractor import _format_markdown, _extract_policy_info, _extract_coverages, _extract_limits, _extract_exclusions, _extract_definitions
    from src.config.constants import OUTPUT_DIRECTORIES, FILE_NAMING
    from langchain_ollama import OllamaLLM
    import json
    from datetime import datetime
    
    # Check for GPU acceleration
    gpu_available = _check_gpu_acceleration()
    
    # Get model from environment variable or use default
    ollama_model = os.getenv("OLLAMA_MODEL", "gemma3:4b")
    ollama_base_url = os.getenv("OLLAMA_BASE_URL", "http://localhost:11434")
    
    print(f"🤖 Using Ollama model: {ollama_model}")
    
    # Initialize Ollama with GPU optimization if available
    llm_config = {
        "model": ollama_model,
        "base_url": ollama_base_url,
        "temperature": 0.1
    }
    
    if gpu_available:
        print("🚀 GPU acceleration detected - optimizing for faster processing")
        llm_config["num_gpu"] = 1
    
    llm = OllamaLLM(**llm_config)
    
    input_dir = "./data/input_forms"
    
    # Find forms to process - all supported formats
    forms = [f for f in os.listdir(input_dir) if f.endswith(('.pdf', '.docx', '.doc', '.txt'))]
    if not forms:
        print("❌ No supported forms found in input directory")
        return
    
    print(f"📄 Found {len(forms)} forms to process: {forms}")
    
    # Create output directories
    for dir_path in OUTPUT_DIRECTORIES.values():
        os.makedirs(dir_path, exist_ok=True)
    
    manifest = {
        "processed_timestamp": datetime.now().isoformat(),
        "form_results": [],
        "question_results": [],
        "tree_outputs": {}
    }
    
    # Load checkpoint if exists
    checkpoint = _load_checkpoint()
    if checkpoint:
        print(f"📂 Resuming from checkpoint: {len(checkpoint.get('completed_forms', []))} forms completed")
    
    # Initialize tracking
    completed_forms = checkpoint.get('completed_forms', []) if checkpoint else []
    remaining_forms = [f for f in forms if f not in completed_forms]
    
    print(f"📊 Processing Status: {len(completed_forms)}/{len(forms)} forms completed")
    print(f"📋 Remaining forms: {remaining_forms}")
    
    # Process each form individually with checkpointing
    for i, form_file in enumerate(remaining_forms, 1):
        print(f"\n🔄 BATCH {i}/{len(remaining_forms)}: Processing {form_file}")
        
        # Process single form through all steps
        result = _process_single_form_batch(form_file, input_dir, llm, checkpoint)
        
        # Update checkpoint after each form
        if not checkpoint:
            checkpoint = {"completed_forms": [], "completed_steps": {}, "timestamp": datetime.now().isoformat()}
        
        checkpoint["completed_forms"].append(form_file)
        checkpoint["timestamp"] = datetime.now().isoformat()
        _save_checkpoint(checkpoint)
        
        print(f"✅ BATCH {i} COMPLETED: {form_file}")
        
        # Add small delay between forms to prevent Ollama overload
        import time
        time.sleep(1)
    
    # Process remaining forms (legacy approach for forms)
    for form_file in forms:
        if form_file in completed_forms:
            print(f"⏭️ Skipping already processed: {form_file}")
            continue
            
        form_path = os.path.join(input_dir, form_file)
        base_name = os.path.splitext(form_file)[0]
        
        print(f"\n📋 Processing: {form_file}")
        
        # Step 1: Extract form data using our working tools
        try:
            # Read content based on file type
            if form_file.endswith('.txt'):
                with open(form_path, 'r', encoding='utf-8') as f:
                    raw_content = f.read()
            elif form_file.endswith('.pdf'):
                from src.tools.parsing.pdf_parser import _extract_with_pdfplumber, _extract_with_pypdf2
                raw_content = _extract_with_pdfplumber(form_path)
                if not raw_content or len(raw_content) < 100:
                    raw_content = _extract_with_pypdf2(form_path)
            elif form_file.endswith('.docx'):
                from src.tools.parsing.docx_parser import _extract_with_docx
                raw_content = _extract_with_docx(form_path)
            else:
                print(f"  ⚠️  Skipping unsupported file type: {form_file}")
                continue
            
            # Extract structured data
            extracted = {
                "policy_info": _extract_policy_info(raw_content),
                "coverages": _extract_coverages(raw_content),
                "limits": _extract_limits(raw_content),
                "exclusions": _extract_exclusions(raw_content),
                "definitions": _extract_definitions(raw_content)
            }
            
            # Format as markdown
            structured_data = _format_markdown(extracted)
            
            # Save form result
            form_result_file = f"{base_name}.md"
            form_result_path = os.path.join(OUTPUT_DIRECTORIES["form_results"], form_result_file)
            
            with open(form_result_path, 'w', encoding='utf-8') as f:
                f.write(structured_data)
            
            manifest["form_results"].append(form_result_file)
            print(f"  ✅ Form analysis saved: {form_result_file}")
            
            # Step 2: Generate questions using LLM
            question_result_file = f"{base_name}_questions.md"
            question_result_path = os.path.join(OUTPUT_DIRECTORIES["question_results"], question_result_file)
            
            questions_prompt = f"""Based on this insurance form analysis, create decision questions in Spanish for Puerto Rico:

{structured_data}

Create specific questions about:
1. Coverage amounts and deductibles
2. Puerto Rico risks (hurricanes, earthquakes)
3. Policy terms and conditions

Format as markdown with clear yes/no questions."""
            
            questions_content = llm.invoke(questions_prompt)
            
            with open(question_result_path, 'w', encoding='utf-8') as f:
                f.write(f"# Preguntas de Decisión: {form_file}\n\n{questions_content}")
            
            manifest["question_results"].append(question_result_file)
            print(f"  ✅ Questions generated: {question_result_file}")
            
        except Exception as e:
            print(f"  ❌ Error processing {form_file}: {e}")
    
    # Step 3: Build individual decision trees per form (process ALL forms one by one)
    individual_trees = []
    processed_trees = 0
    
    if manifest["form_results"]:
        print(f"\n🌳 Creating individual decision trees (processing ALL {len(manifest['form_results'])} forms)...")
        
        for i, form_result in enumerate(manifest["form_results"]):
            # Read the form analysis
            form_path = os.path.join(OUTPUT_DIRECTORIES["form_results"], form_result)
            try:
                with open(form_path, 'r', encoding='utf-8') as f:
                    form_content = f.read()
                
                # Skip if form content is empty
                if not form_content.strip():
                    print(f"  ⚠️  Skipping empty form: {form_result}")
                    continue
                
                tree_prompt = f"""Crea un árbol de decisión simple en español para residentes de Puerto Rico:

{form_content[:2000]}  

IMPORTANTE: 
- Usa español sencillo (nivel de 5to grado)
- Enfócate SOLO en riesgos de Puerto Rico: huracanes, terremotos
- Incluye montos específicos encontrados
- Máximo 5 preguntas
- Usa números como 1.0, 1.1, 1.2

Formato corto:
## Árbol: [Tipo]
1.0 ¿Su casa está en PR? 
    1.1 SÍ → 2.0
2.0 ¿Qué riesgo? 
    2.1 HURACANES → Cobertura: $X
    2.2 TERREMOTOS → Cobertura: $Y"""
                
                tree_content = llm.invoke(tree_prompt)
                
                # Save individual tree
                tree_filename = f"tree_{os.path.splitext(form_result)[0]}.md"
                tree_path = os.path.join(OUTPUT_DIRECTORIES["decision_trees"], tree_filename)
                
                with open(tree_path, 'w', encoding='utf-8') as f:
                    f.write(tree_content)
                
                individual_trees.append(tree_content)
                processed_trees += 1
                print(f"  ✅ Individual tree {processed_trees}: {tree_filename}")
                
            except Exception as e:
                print(f"  ❌ Error creating tree for {form_result}: {e}")
        
        # If we have fewer trees than forms, note it
        if len(manifest["form_results"]) > max_individual_trees:
            print(f"  ℹ️  Processed {processed_trees} of {len(manifest['form_results'])} forms (limited for faster processing)")
    
    # Step 4: Combine trees into master tree
    if individual_trees:
        combined_tree_file = "initial_combined_tree.md"
        combined_tree_path = os.path.join(OUTPUT_DIRECTORIES["decision_trees"], combined_tree_file)
        
        combine_prompt = f"""Combina estos árboles de decisión individuales en UN SOLO árbol maestro para seguros de Puerto Rico:

{chr(10).join(['---ÁRBOL ' + str(i+1) + '---' + chr(10) + tree for i, tree in enumerate(individual_trees)])}

INSTRUCCIONES:
- Crea UN árbol de decisión unificado en español sencillo
- Enfócate en riesgos de Puerto Rico: huracanes, terremotos, inundaciones
- Incluye todos los montos de cobertura encontrados
- Organiza por tipo de riesgo, luego por tipo de propiedad
- Usa numeración 1.0, 1.1, 2.0, etc.
- Termina cada camino con RESULTADO específico incluyendo cobertura y deducible

Formato final debe ser claro para residentes de Puerto Rico."""
        
        try:
            combined_content = llm.invoke(combine_prompt)
            
            with open(combined_tree_path, 'w', encoding='utf-8') as f:
                f.write(f"# Árbol de Decisión Maestro - Seguros Puerto Rico\n\n{combined_content}")
            
            manifest["tree_outputs"]["initial"] = combined_tree_file
            print(f"  ✅ Combined tree created: {combined_tree_file}")
            
        except Exception as e:
            print(f"  ❌ Error creating combined tree: {e}")
    
    # Step 5: Simplify tree (make it even simpler for 5th grade level)
    if "initial" in manifest["tree_outputs"]:
        simplified_file = "simplified_tree.md"
        simplified_path = os.path.join(OUTPUT_DIRECTORIES["decision_trees"], simplified_file)
        initial_path = os.path.join(OUTPUT_DIRECTORIES["decision_trees"], manifest["tree_outputs"]["initial"])
        
        try:
            with open(initial_path, 'r', encoding='utf-8') as f:
                complex_tree = f.read()
            
            simplify_prompt = f"""Simplifica este árbol de decisión para que sea MUY fácil de entender para residentes de Puerto Rico (nivel de 5to grado):

{complex_tree}

SIMPLIFICA:
- Usa palabras más sencillas
- Oraciones más cortas
- Menos opciones por pregunta (máximo 3)
- Explica términos técnicos
- Añade emojis para claridad: 🌀 huracanes, 🏠 casa, 💰 dinero, ❓ pregunta

Mantén la estructura numerada pero hazla más simple."""
            
            simplified_content = llm.invoke(simplify_prompt)
            
            with open(simplified_path, 'w', encoding='utf-8') as f:
                f.write(f"# Árbol de Decisión SIMPLE - Seguros Puerto Rico\n\n{simplified_content}")
            
            manifest["tree_outputs"]["simplified"] = simplified_file
            print(f"  ✅ Tree simplified: {simplified_file}")
            
        except Exception as e:
            print(f"  ❌ Error simplifying tree: {e}")
    
    # Step 6: Final QA and validation
    if "simplified" in manifest["tree_outputs"]:
        final_file = "final_tree.md"
        qa_report_file = "qa_report.md"
        final_path = os.path.join(OUTPUT_DIRECTORIES["decision_trees"], final_file)
        qa_report_path = os.path.join(OUTPUT_DIRECTORIES["qa_reports"], qa_report_file)
        simplified_path = os.path.join(OUTPUT_DIRECTORIES["decision_trees"], manifest["tree_outputs"]["simplified"])
        
        try:
            with open(simplified_path, 'r', encoding='utf-8') as f:
                simplified_tree = f.read()
            
            qa_prompt = f"""Revisa este árbol de decisión final y añade validación de calidad:

{simplified_tree}

AÑADE al final:
## Validación QA ✅
- Específico para Puerto Rico
- Cubre huracanes y terremotos
- Lenguaje de 5to grado
- Montos reales incluidos
- Próximos pasos claros

## Próximos Pasos Recomendados
1. [Pasos específicos para el usuario]
2. [Contactos importantes]
3. [Documentos necesarios]

Asegúrate de que todo esté en español sencillo y sea específico para Puerto Rico."""
            
            final_content = llm.invoke(qa_prompt)
            
            with open(final_path, 'w', encoding='utf-8') as f:
                f.write(final_content)
            
            # Create QA report
            qa_content = f"""# Reporte de Control de Calidad

## Resumen de Validación
- **Fecha**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
- **Formularios Procesados**: {len(manifest['form_results'])}
- **Árboles Individuales**: {len(individual_trees)}
- **Estado**: ✅ APROBADO

## Criterios Cumplidos
- ✅ Contenido específico para Puerto Rico
- ✅ Riesgos relevantes: huracanes, terremotos
- ✅ Exclusión de riesgos no aplicables (nieve, hielo)
- ✅ Lenguaje de 5to grado
- ✅ Montos reales de pólizas incluidos
- ✅ Estructura numerada clara
- ✅ Emojis para claridad

## Archivos Generados
### Análisis de Formularios:
"""
            for form_file in manifest["form_results"]:
                qa_content += f"- {form_file}\n"
            
            qa_content += f"""
### Preguntas Generadas:
"""
            for q_file in manifest["question_results"]:
                qa_content += f"- {q_file}\n"
            
            qa_content += f"""
### Árboles de Decisión:
- Árboles individuales: {len(individual_trees)}
- Árbol combinado: {manifest['tree_outputs'].get('initial', 'No creado')}
- Árbol simplificado: {manifest['tree_outputs'].get('simplified', 'No creado')}
- Árbol final: {final_file}

## Estado Final
🎉 **COMPLETADO** - Sistema procesó exitosamente {len(manifest['form_results'])} formularios y generó árbol de decisión específico para Puerto Rico.
"""
            
            with open(qa_report_path, 'w', encoding='utf-8') as f:
                f.write(qa_content)
            
            manifest["tree_outputs"]["final"] = final_file
            print(f"  ✅ Final QA completed: {final_file}")
            print(f"  ✅ QA report saved: {qa_report_file}")
            
        except Exception as e:
            print(f"  ❌ Error in QA validation: {e}")
    
    # Save manifest
    manifest_path = os.path.join(OUTPUT_DIRECTORIES["decision_trees"], "manifest.json")
    with open(manifest_path, 'w') as f:
        json.dump(manifest, f, indent=2)
    
    print(f"\n🎉 Simple mode completed successfully!")
    print(f"📊 Processed {len(manifest['form_results'])} forms")
    print(f"❓ Generated {len(manifest['question_results'])} question sets")
    print(f"🌳 Individual trees: {len(individual_trees)}")
    print(f"🌳 Final decision tree: {manifest['tree_outputs'].get('final', 'None')}")
    print(f"📋 QA report: {qa_report_file if 'final' in manifest['tree_outputs'] else 'None'}")
    print(f"📄 Manifest saved: {manifest_path}")
    print(f"\n🇵🇷 All content specifically adapted for Puerto Rico residents!")
    
    return manifest

def main():
    """Main execution function with checkpoint support"""
    import sys
    
    # Check for simple mode parameter
    if len(sys.argv) > 1 and sys.argv[1] == "--simple":
        cleanup_previous_run()
        return run_simple_mode()
    
    # Regular CrewAI mode
    cleanup_previous_run()
    
    checkpoint_file = "./data/checkpoint.json"
    validator = PipelineValidator()
    
    try:
        # Check Ollama connection first
        logger.info("Checking Ollama connection...")
        is_connected, message = check_ollama_connection()
        if not is_connected:
            logger.error(f"Ollama check failed: {message}")
            logger.info("Please ensure Ollama is running and gemma3:12b model is installed:")
            logger.info("  1. Install Ollama from https://ollama.ai")
            logger.info("  2. Run: ollama pull gemma3:12b")
            logger.info("  3. Start Ollama service: ollama serve")
            return
        
        logger.info(f"Ollama check passed: {message}")
        
        logger.info("Initializing Insurance Processing Crew...")
        crew = InsuranceProcessingCrew()
        
        start_from_step = 0
        if os.path.exists(checkpoint_file):
            with open(checkpoint_file, 'r') as f:
                checkpoint = json.load(f)
                start_from_step = checkpoint.get('last_completed_step', 0)
                logger.info(f"Resuming from step {start_from_step}")
        
        input_dir = os.getenv("INPUT_FORMS_DIR", "./data/input_forms")
        
        # Create input directory if it doesn't exist
        os.makedirs(input_dir, exist_ok=True)
        
        # Check for forms
        if not os.path.exists(input_dir):
            logger.error(f"Input directory {input_dir} does not exist")
            return
            
        # Start with just text file for testing
        forms = [f for f in os.listdir(input_dir) if f.endswith('.txt')]
        
        if not forms:
            logger.warning(f"No forms found in input directory: {input_dir}")
            logger.info("Please add PDF, DOCX, or TXT insurance forms to the input directory")
            return
        
        logger.info(f"Found {len(forms)} forms to process")
        
        for dir_path in OUTPUT_DIRECTORIES.values():
            os.makedirs(dir_path, exist_ok=True)
        
        logger.info("Starting crew execution...")
        result = crew.kickoff(
            inputs={
                "forms": forms, 
                "input_dir": input_dir,
                "start_from_step": start_from_step
            }
        )
        
        validation_result = validator.validate_final_output(
            result.get('output_path')
        )
        
        logger.info("Crew execution completed successfully")
        logger.info(f"Final output saved to: {result.get('output_path')}")
        logger.info(f"Validation result: {validation_result}")
        
        if os.path.exists(checkpoint_file):
            os.remove(checkpoint_file)
            
    except Exception as e:
        logger.error(f"Error during execution: {str(e)}")
        # Only save checkpoint if crew was successfully created
        try:
            with open(checkpoint_file, 'w') as f:
                json.dump({
                    "last_completed_step": getattr(crew, 'last_completed_step', 0),
                    "timestamp": datetime.now().isoformat(),
                    "error": str(e)
                }, f)
        except:
            pass  # If crew wasn't created, don't save checkpoint
        raise

if __name__ == "__main__":
    main()