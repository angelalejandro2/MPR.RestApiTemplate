# 🚀 Deployment Guide - Insurance Claim Processing System

Guía completa para instalar y ejecutar el sistema en cualquier máquina.

## 🎯 Instalación Automatizada (Recomendada)

### Opción 1: Script de Setup Automático

```bash
# 1. Clonar repositorio
git clone <repository-url>
cd insurance-claim-crew

# 2. Ejecutar script de instalación automática
chmod +x setup.sh
./setup.sh

# 3. ¡Listo! El sistema está configurado
```

### ¿Qué hace el script automático?
- ✅ Verifica Python 3.8+
- ✅ Crea entorno virtual
- ✅ Instala todas las dependencias
- ✅ Descarga e instala Ollama
- ✅ Descarga modelo gemma3:4b
- ✅ Crea directorios necesarios
- ✅ Configura permisos
- ✅ Ejecuta pruebas del sistema

## 🔧 Instalación Manual

### Paso 1: Prerrequisitos del Sistema

**Python 3.8+**
```bash
# Verificar versión
python3 --version

# Si no tienes Python 3.8+:
# Ubuntu/Debian: sudo apt install python3.8 python3.8-venv
# macOS: brew install python@3.8
# Windows: Descargar de python.org
```

**Git**
```bash
# Verificar Git
git --version

# Si no tienes Git:
# Ubuntu/Debian: sudo apt install git
# macOS: xcode-select --install
# Windows: git-scm.com
```

### Paso 2: Clonar y Configurar Proyecto

```bash
# Clonar repositorio
git clone <repository-url>
cd insurance-claim-crew

# Crear entorno virtual
python3 -m venv venv

# Activar entorno virtual
# macOS/Linux:
source venv/bin/activate
# Windows:
venv\Scripts\activate

# Actualizar pip
pip install --upgrade pip

# Instalar dependencias
pip install -r requirements.txt
```

### Paso 3: Instalar Ollama

**macOS/Linux:**
```bash
# Instalar Ollama
curl -fsSL https://ollama.ai/install.sh | sh

# Iniciar servicio
ollama serve &

# Instalar modelo
ollama pull gemma3:4b
```

**Windows:**
```bash
# Descargar desde: https://ollama.ai/download
# Ejecutar instalador
# Abrir terminal y ejecutar:
ollama pull gemma3:4b
```

### Paso 4: Crear Directorios

```bash
mkdir -p data/input_forms
mkdir -p data/form_results  
mkdir -p data/question_results
mkdir -p data/decision_trees
mkdir -p data/qa_reports
mkdir -p logs
```

### Paso 5: Configurar Permisos (macOS/Linux)

```bash
chmod +x main.py
chmod -R 755 data/
```

## ✅ Verificar Instalación

### Test Básico
```bash
# Activar entorno virtual
source venv/bin/activate  # o venv\Scripts\activate en Windows

# Verificar Ollama
curl http://localhost:11434/api/tags

# Verificar Python dependencies
python -c "from langchain_ollama import OllamaLLM; print('✅ Dependencies OK')"

# Verificar sistema completo
python -c "
from src.utils.ollama_check import check_ollama_connection
is_connected, msg = check_ollama_connection()
print(f'Ollama: {\"✅ OK\" if is_connected else \"❌ \" + msg}')
"
```

### Test con Archivo de Prueba
```bash
# Crear archivo de prueba
echo "Test insurance policy content" > data/input_forms/test.txt

# Ejecutar sistema
python main.py --simple

# Verificar resultados
ls -la data/decision_trees/
```

## 🌐 Configuración para Diferentes Sistemas

### Ubuntu/Debian
```bash
# Instalar dependencias del sistema
sudo apt update
sudo apt install python3.8 python3.8-venv python3-pip git curl

# Continuar con instalación normal
```

### CentOS/RHEL
```bash
# Instalar dependencias
sudo yum install python38 python38-venv git curl

# Continuar con instalación normal
```

### macOS
```bash
# Instalar Homebrew si no está instalado
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"

# Instalar Python
brew install python@3.8

# Continuar con instalación normal
```

### Windows
```powershell
# Instalar Python desde python.org
# Instalar Git desde git-scm.com

# En PowerShell:
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt

# Instalar Ollama desde ollama.ai/download
```

## 🚀 Ejecutar el Sistema

### Comando Básico
```bash
# Activar entorno virtual
source venv/bin/activate

# Colocar pólizas en data/input_forms/
cp mi_poliza.pdf data/input_forms/

# Ejecutar procesamiento
python main.py --simple
```

### Verificar Resultados
```bash
# Listar archivos generados
echo "Form results:" && ls data/form_results/
echo "Questions:" && ls data/question_results/  
echo "Trees:" && ls data/decision_trees/
echo "QA Reports:" && ls data/qa_reports/

# Ver árbol final
cat data/decision_trees/FINAL_TREE.md
```

## 🔧 Solución de Problemas Comunes

### Error: "Python command not found"
```bash
# Probar diferentes comandos:
python --version
python3 --version
python3.8 --version

# Usar el que funcione para crear venv
```

### Error: "Ollama connection failed"
```bash
# Verificar que Ollama esté corriendo:
ps aux | grep ollama

# Si no está corriendo:
ollama serve &

# Verificar puerto:
netstat -an | grep 11434
```

### Error: "Module not found"
```bash
# Verificar que el entorno virtual esté activado:
which python  # Debe mostrar ruta con 'venv'

# Si no está activado:
source venv/bin/activate  # o venv\Scripts\activate

# Reinstalar dependencias:
pip install -r requirements.txt
```

### Error: "Permission denied"
```bash
# En macOS/Linux:
chmod +x main.py
chmod -R 755 data/

# En Windows, ejecutar como administrador
```

### Error: "GPU not detected"
```bash
# Esto es normal - el sistema funcionará con CPU
# Para GPU en macOS: Automático con Apple Silicon
# Para GPU en Linux: Instalar CUDA toolkit
```

## 📦 Dependencias del Sistema

### Dependencias Python (se instalan automáticamente)
```
crewai>=0.28.8
langchain-ollama>=0.3.0
PyPDF2>=3.0.1
pdfplumber>=0.11.0
python-docx>=1.1.0
ollama>=0.4.0
```

### Dependencias del Sistema Operativo
- **Python 3.8+** (requerido)
- **Git** (para clonar repo)
- **curl** (para instalar Ollama)
- **5GB espacio libre** (para modelo LLM)

## 🌍 Configuración Multi-idioma

```bash
# Editar .env para otros idiomas:
OUTPUT_LANGUAGE=en  # Para inglés
OUTPUT_LANGUAGE=es  # Para español (default)
```

## 📊 Monitoreo del Sistema

### Logs
```bash
# Ver logs en tiempo real:
tail -f logs/insurance_crew_*.log

# Ver errores:
grep ERROR logs/insurance_crew_*.log
```

### Rendimiento
```bash
# Verificar uso de memoria:
ps aux | grep python

# Verificar uso de GPU (si aplica):
nvidia-smi  # En sistemas NVIDIA
```

---

## ✅ Checklist de Deployment

- [ ] Python 3.8+ instalado
- [ ] Git instalado  
- [ ] Repositorio clonado
- [ ] Entorno virtual creado
- [ ] Dependencias Python instaladas
- [ ] Ollama instalado
- [ ] Modelo gemma3:4b descargado
- [ ] Directorios creados
- [ ] Permisos configurados
- [ ] Test básico exitoso
- [ ] Test con archivo de prueba exitoso

**🎉 ¡Sistema listo para producción!**