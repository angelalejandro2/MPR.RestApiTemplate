#!/usr/bin/env python3
"""
Simple test script to verify form parsing works without CrewAI complexity
"""

import os
import sys
sys.path.append('src')

from src.tools.parsing.txt_parser import TxtParserTool
from src.tools.parsing.form_extractor import FormExtractorTool

def main():
    input_file = "./data/input_forms/sample_insurance_form.txt"
    output_file = "./data/form_results/simple_test_output.md"
    
    print(f"Testing form parsing with: {input_file}")
    
    # Test TXT parser - read file directly
    print("1. Testing TXT parser...")
    with open(input_file, 'r') as f:
        raw_text = f.read()
    print(f"Raw text length: {len(raw_text)}")
    print(f"First 200 chars: {raw_text[:200]}...")
    
    # Test form extractor - call underlying function
    print("\n2. Testing form extractor...")
    from src.tools.parsing.form_extractor import _format_markdown, _extract_policy_info, _extract_coverages, _extract_limits, _extract_exclusions, _extract_definitions
    
    extracted = {
        "policy_info": _extract_policy_info(raw_text),
        "coverages": _extract_coverages(raw_text),
        "limits": _extract_limits(raw_text),
        "exclusions": _extract_exclusions(raw_text),
        "definitions": _extract_definitions(raw_text)
    }
    
    structured_data = _format_markdown(extracted)
    print(f"Structured data length: {len(structured_data)}")
    
    # Save output
    os.makedirs(os.path.dirname(output_file), exist_ok=True)
    with open(output_file, 'w') as f:
        f.write(structured_data)
    
    print(f"\n3. Output saved to: {output_file}")
    print("\nTest completed successfully!")
    
    return structured_data

if __name__ == "__main__":
    result = main()
    print("\n" + "="*50)
    print("FINAL RESULT:")
    print("="*50)
    print(result)