import os
import json
from typing import Dict, List

class PipelineValidator:
    """Validates outputs at each stage of the pipeline"""
    
    def validate_form_parsing(self, output_dir: str, expected_files: list) -> dict:
        """Validate form parser outputs"""
        if not os.path.exists(output_dir):
            return {"validation_passed": False, "error": "Output directory does not exist"}
        
        files_created = len([f for f in os.listdir(output_dir) if f.endswith('.md')])
        expected_sections = ["definitions", "coverages", "exclusions"]
        
        validation_result = {
            "files_created": files_created,
            "expected_files": len(expected_files),
            "expected_sections": expected_sections,
            "missing_files": [],
            "validation_passed": files_created >= len(expected_files)
        }
        
        return validation_result
    
    def validate_question_generation(self, output_dir: str) -> dict:
        """Validate question generator outputs"""
        if not os.path.exists(output_dir):
            return {"validation_passed": False, "error": "Output directory does not exist"}
        
        files = [f for f in os.listdir(output_dir) if f.endswith('.md')]
        
        return {
            "files_created": len(files),
            "validation_passed": len(files) > 0
        }
    
    def validate_tree_structure(self, tree_path: str) -> dict:
        """Validate tree has proper structure"""
        if not os.path.exists(tree_path):
            return {"validation_passed": False, "error": "Tree file does not exist"}
        
        with open(tree_path, 'r', encoding='utf-8') as f:
            content = f.read()
        
        has_nodes = "1.0" in content and "→" in content
        has_results = "RESULTADO" in content
        
        return {
            "has_nodes": has_nodes,
            "has_results": has_results,
            "validation_passed": has_nodes and has_results
        }
    
    def validate_final_output(self, final_tree_path: str) -> dict:
        """Validate the final decision tree output"""
        if not os.path.exists(final_tree_path):
            return {"validation_passed": False, "error": "Final tree does not exist"}
        
        with open(final_tree_path, 'r', encoding='utf-8') as f:
            content = f.read()
        
        required_elements = [
            "ÁRBOL DE DECISIÓN",
            "RESULTADO",
            "COBERTURA",
            "LÍMITE",
            "DEDUCIBLE",
            "PRÓXIMOS PASOS"
        ]
        
        elements_found = {element: element in content for element in required_elements}
        all_found = all(elements_found.values())
        
        return {
            "elements_found": elements_found,
            "validation_passed": all_found,
            "content_length": len(content)
        }