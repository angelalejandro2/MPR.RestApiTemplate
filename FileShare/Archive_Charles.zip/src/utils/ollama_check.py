import requests
import os
from dotenv import load_dotenv

load_dotenv()

def check_ollama_connection():
    """Check if Ollama is running and model is available"""
    
    base_url = os.getenv("OLLAMA_BASE_URL", "http://localhost:11434")
    model = os.getenv("OLLAMA_MODEL", "gemma3:4b")
    
    try:
        # Check if Ollama is running
        response = requests.get(f"{base_url}/api/tags", timeout=5)
        if response.status_code != 200:
            return False, f"Ollama not responding at {base_url}"
        
        # Check if model is available
        models = response.json().get("models", [])
        model_names = [m.get("name", "") for m in models]
        
        if not any(model in name for name in model_names):
            return False, f"Model {model} not found. Available models: {model_names}"
        
        return True, "Ollama connection successful"
        
    except requests.exceptions.ConnectionError:
        return False, f"Cannot connect to Ollama at {base_url}. Is Ollama running?"
    except Exception as e:
        return False, f"Error checking Ollama: {str(e)}"