from crewai import Task
import os

def _get_file_content(file_path: str) -> str:
    """Helper function to read file content directly"""
    try:
        if file_path.endswith('.txt'):
            with open(file_path, 'r', encoding='utf-8') as f:
                return f.read()
        else:
            return f"File type not supported for direct reading: {file_path}"
    except Exception as e:
        return f"Error reading file {file_path}: {str(e)}"

def _extract_policy_number(file_path: str) -> str:
    """Extract policy number from file content for tracking"""
    try:
        content = _get_file_content(file_path)
        import re
        match = re.search(r'Policy Number:\s*([A-Z0-9-]+)', content, re.IGNORECASE)
        if match:
            return match.group(1)
        return "Unknown"
    except:
        return "Unknown"

class FormParsingTaskDefinition:
    
    @staticmethod
    def create(agent, form_path: str, output_path: str):
        return Task(
            description=f"""
            **Pre-processed Content:** The insurance form content has been pre-extracted and is provided below:

            FILE: {form_path}
            CONTENT:
            {_get_file_content(form_path)}
            
            **Objective:** Analyze the above insurance form content and create a comprehensive structured markdown analysis at {output_path}.
            
            **CRITICAL INSTRUCTION - YOU MUST CREATE A FILE:**
            After analyzing the content above, you MUST create a markdown file at: {output_path}
            
            **Requirements for the analysis:**
            • Extract ALL definitions, coverages, limits, and exclusions from the content above
            • Use consistent markdown formatting starting with "# Insurance Form Analysis"
            • Include the policy number: {_extract_policy_number(form_path)}
            • Separate general vs coverage-specific exclusions  
            • Focus on Puerto Rico specific elements (hurricanes, earthquakes)
            • Remove any mainland-specific perils (snow, ice)
            
            **IMPORTANT - Content Analysis Only:**
            The content above contains all the form data you need. 
            Analyze it directly and provide a comprehensive markdown analysis.
            Do NOT use any tools - just analyze the content and respond with structured markdown.
            
            **Your response should be the complete markdown analysis ready to save to {output_path}**
            
            **Success Criteria:** 
            1. File exists at {output_path}
            2. File contains complete analysis of policy {_extract_policy_number(form_path)}
            3. All coverage amounts extracted: verify $150,000, $75,000, $30,000 are captured
            """,
            agent=agent,
            expected_output=f"Structured markdown file saved to {output_path}"
        )