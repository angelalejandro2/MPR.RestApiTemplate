from crewai import Task

class QATaskDefinition:
    
    @staticmethod
    def create(agent, spanish_tree_path: str, original_forms: list, output_path: str, qa_report_path: str):
        return Task(
            description=f"""
            **Objective:** Validate tree at {spanish_tree_path} covers all scenarios from {original_forms} with 100% accuracy.
            
            **Context:** This final check ensures no coverage gaps exist. Any missed scenario could result in 
            incorrect claim denials.
            
            **Requirements:**
            • Cross-reference every coverage in original forms
            • Test all decision paths for correct results
            • Verify Spanish translations are accurate
            • Generate coverage matrix report
            • Save final validated tree to: {output_path}
            • Save QA report to: {qa_report_path}
            
            **Success Criteria:** QA report showing 100% coverage with test results for every path.
            """,
            agent=agent,
            expected_output=f"Final validated tree saved to {output_path} and comprehensive QA report saved to {qa_report_path}"
        )