from crewai import Task

class QuestionGenerationTaskDefinition:
    
    @staticmethod
    def create(agent, form_summary_path: str, output_path: str):
        return Task(
            description=f"""
            **Objective:** Generate comprehensive Spanish questions from {form_summary_path} that determine coverage eligibility, save to {output_path}.
            
            **Context:** These questions will guide users through the decision tree. They must cover every coverage 
            trigger and exclusion without requiring insurance knowledge.
            
            **Requirements:**
            • Questions in simple Spanish (5th grade level)
            • Focus on observable facts only
            • Cover all coverages and exclusions
            • Include "No estoy seguro" options where appropriate
            • Save output to: {output_path}
            
            **Success Criteria:** Question set that maps to every coverage scenario in the form with zero gaps.
            """,
            agent=agent,
            expected_output=f"Question markdown file saved to {output_path}"
        )