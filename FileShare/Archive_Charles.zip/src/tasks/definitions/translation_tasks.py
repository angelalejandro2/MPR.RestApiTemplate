from crewai import Task

class TranslationTaskDefinition:
    
    @staticmethod
    def create(agent, simplified_tree_path: str, output_path: str):
        return Task(
            description=f"""
            **Objective:** Translate tree at {simplified_tree_path} to Puerto Rican Spanish and remove irrelevant scenarios, save to {output_path}.
            
            **Context:** Puerto Rico has specific risks (hurricanes, earthquakes) and doesn't need mainland 
            scenarios (snow, tornadoes).
            
            **Requirements:**
            • Use Puerto Rican Spanish terminology
            • Remove snow/ice/freeze damage questions
            • Emphasize hurricane and earthquake paths
            • Maintain all PR-relevant coverage options
            • Save output to: {output_path}
            
            **Success Criteria:** Spanish tree with only PR-relevant scenarios and culturally appropriate language.
            """,
            agent=agent,
            expected_output=f"Spanish decision tree adapted for Puerto Rico context saved to {output_path}"
        )