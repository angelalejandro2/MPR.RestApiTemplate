from crewai import Task

class SimplificationTaskDefinition:
    
    @staticmethod
    def create(agent, tree_path: str, output_path: str):
        return Task(
            description=f"""
            **Objective:** Simplify language in decision tree at {tree_path} while maintaining complete accuracy, save to {output_path}.
            
            **Context:** Users have varying education levels. Simplified language reduces errors and improves 
            claim processing speed.
            
            **Requirements:**
            • Replace technical terms with everyday language
            • Maintain all decision paths unchanged
            • Keep questions mutually exclusive
            • Preserve all coverage determinations
            • Save output to: {output_path}
            
            **Success Criteria:** Simplified tree passes readability tests while maintaining identical routing logic.
            """,
            agent=agent,
            expected_output=f"Simplified decision tree with improved readability saved to {output_path}"
        )