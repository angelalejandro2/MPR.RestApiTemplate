from crewai import Task

class TreeBuildingTaskDefinition:
    
    @staticmethod
    def create(agent, question_files: list, output_path: str):
        return Task(
            description=f"""
            **Objective:** Build a comprehensive decision tree from questions in {question_files} with proper routing logic, save to {output_path}.
            
            **Context:** This tree will be the primary interface for claim assessment. Clear navigation is critical 
            for user success.
            
            **Requirements:**
            • Use decimal numbering (1.0, 1.1, 2.0)
            • Every path must lead to a result
            • Group related questions logically
            • Include navigation instructions at each node
            • Save output to: {output_path}
            
            **Success Criteria:** Complete tree with all questions integrated, zero dead ends, and validated paths.
            """,
            agent=agent,
            expected_output=f"Decision tree in markdown with numbered nodes saved to {output_path}"
        )