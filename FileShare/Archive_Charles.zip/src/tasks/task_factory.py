import os
from typing import List, Dict
from src.tasks.definitions.form_parsing_tasks import FormParsingTaskDefinition
from src.tasks.definitions.question_generation_tasks import QuestionGenerationTaskDefinition
from src.tasks.definitions.tree_building_tasks import TreeBuildingTaskDefinition
from src.tasks.definitions.simplification_tasks import SimplificationTaskDefinition
from src.tasks.definitions.translation_tasks import TranslationTaskDefinition
from src.tasks.definitions.qa_tasks import QATaskDefinition
from src.config.constants import FILE_NAMING, OUTPUT_DIRECTORIES
from src.utils.logger import setup_logger

logger = setup_logger(__name__)

class TaskFactory:
    """Factory for creating pipeline tasks with output chaining"""
    
    def __init__(self):
        self.form_results = []
        self.question_results = []
        self.manifest = {
            "form_results": [],
            "question_results": [],
            "tree_outputs": {}
        }
    
    def create_pipeline_tasks(self, agents: dict, forms: list, input_dir: str, start_from_step: int = 0):
        """Create all tasks with proper output chaining"""
        tasks = []
        
        # Step 1: Form parsing tasks
        if start_from_step <= 1:
            for form in forms:
                output_filename = FILE_NAMING["form_results"].format(
                    original_filename_without_extension=os.path.splitext(form)[0]
                )
                output_path = os.path.join(OUTPUT_DIRECTORIES["form_results"], output_filename)
                
                task = FormParsingTaskDefinition.create(
                    agent=agents['form_parser'],
                    form_path=os.path.join(input_dir, form),
                    output_path=output_path
                )
                tasks.append(task)
                self.form_results.append(output_path)
                self.manifest["form_results"].append(output_filename)
        else:
            self._load_existing_outputs("form_results")
        
        # Step 2: Question generation tasks
        if start_from_step <= 2:
            for form_result_path in self.form_results:
                base_name = os.path.basename(form_result_path).replace('.md', '')
                output_filename = FILE_NAMING["question_results"].format(
                    original_filename_without_extension=base_name
                )
                output_path = os.path.join(OUTPUT_DIRECTORIES["question_results"], output_filename)
                
                task = QuestionGenerationTaskDefinition.create(
                    agent=agents['question_generator'],
                    form_summary_path=form_result_path,
                    output_path=output_path
                )
                tasks.append(task)
                self.question_results.append(output_path)
                self.manifest["question_results"].append(output_filename)
        else:
            self._load_existing_outputs("question_results")
        
        # Step 3: Tree building
        if start_from_step <= 3:
            tree_output_path = os.path.join(
                OUTPUT_DIRECTORIES["decision_trees"], 
                FILE_NAMING["trees"]["initial"]
            )
            
            task = TreeBuildingTaskDefinition.create(
                agent=agents['tree_builder'],
                question_files=self.question_results,
                output_path=tree_output_path
            )
            tasks.append(task)
            self.manifest["tree_outputs"]["initial"] = FILE_NAMING["trees"]["initial"]
        
        # Step 4: Simplification
        if start_from_step <= 4:
            initial_tree_path = os.path.join(
                OUTPUT_DIRECTORIES["decision_trees"],
                FILE_NAMING["trees"]["initial"]
            )
            simplified_tree_path = os.path.join(
                OUTPUT_DIRECTORIES["decision_trees"],
                FILE_NAMING["trees"]["simplified"]
            )
            
            task = SimplificationTaskDefinition.create(
                agent=agents['tree_simplifier'],
                tree_path=initial_tree_path,
                output_path=simplified_tree_path
            )
            tasks.append(task)
            self.manifest["tree_outputs"]["simplified"] = FILE_NAMING["trees"]["simplified"]
        
        # Step 5: Translation to Spanish with PR context
        if start_from_step <= 5:
            simplified_tree_path = os.path.join(
                OUTPUT_DIRECTORIES["decision_trees"],
                FILE_NAMING["trees"]["simplified"]
            )
            spanish_tree_path = os.path.join(
                OUTPUT_DIRECTORIES["decision_trees"],
                FILE_NAMING["trees"]["spanish"]
            )
            
            task = TranslationTaskDefinition.create(
                agent=agents['spanish_translator'],
                simplified_tree_path=simplified_tree_path,
                output_path=spanish_tree_path
            )
            tasks.append(task)
            self.manifest["tree_outputs"]["spanish"] = FILE_NAMING["trees"]["spanish"]
        
        # Step 6: QA validation
        if start_from_step <= 6:
            spanish_tree_path = os.path.join(
                OUTPUT_DIRECTORIES["decision_trees"],
                FILE_NAMING["trees"]["spanish"]
            )
            final_tree_path = os.path.join(
                OUTPUT_DIRECTORIES["decision_trees"],
                FILE_NAMING["trees"]["final"]
            )
            
            task = QATaskDefinition.create(
                agent=agents['qa_manager'],
                spanish_tree_path=spanish_tree_path,
                original_forms=self.form_results,
                output_path=final_tree_path,
                qa_report_path=os.path.join(OUTPUT_DIRECTORIES["qa_reports"], "qa_report.md")
            )
            tasks.append(task)
            self.manifest["tree_outputs"]["final"] = FILE_NAMING["trees"]["final"]
        
        self._save_manifest()
        
        return tasks
    
    def _load_existing_outputs(self, output_type: str):
        """Load existing outputs from previous runs"""
        directory = OUTPUT_DIRECTORIES.get(output_type)
        if directory and os.path.exists(directory):
            files = [f for f in os.listdir(directory) if f.endswith('.md')]
            file_paths = [os.path.join(directory, f) for f in files]
            
            if output_type == "form_results":
                self.form_results = file_paths
                logger.info(f"Loaded {len(file_paths)} existing form results")
            elif output_type == "question_results":
                self.question_results = file_paths
                logger.info(f"Loaded {len(file_paths)} existing question results")
        else:
            logger.warning(f"Directory {directory} does not exist for {output_type}")
    
    def _save_manifest(self):
        """Save manifest of all outputs"""
        import json
        manifest_path = os.path.join(OUTPUT_DIRECTORIES["decision_trees"], "manifest.json")
        with open(manifest_path, 'w') as f:
            json.dump(self.manifest, f, indent=2)