FILE_NAMING = {
    "form_results": "{original_filename_without_extension}.md",
    "question_results": "{original_filename_without_extension}_questions.md",
    "trees": {
        "initial": "initial_tree.md",
        "simplified": "simplified_tree.md",
        "spanish": "spanish_tree.md",
        "final": "final_tree.md"
    }
}

OUTPUT_DIRECTORIES = {
    "form_results": "./data/form_results",
    "question_results": "./data/question_results",
    "decision_trees": "./data/decision_trees",
    "qa_reports": "./data/qa_reports"
}