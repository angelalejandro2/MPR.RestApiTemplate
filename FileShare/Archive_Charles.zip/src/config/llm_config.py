import os
from dotenv import load_dotenv

load_dotenv()

def get_ollama_llm():
    """Create and return Ollama LLM instance for CrewAI agents"""
    # Use CrewAI's LLM with the correct litellm format
    from crewai import LLM
    
    return LLM(
        model="ollama/gemma3:4b",  # This is the format litellm expects
        base_url="http://localhost:11434",
        temperature=0.1,
        api_key="ollama",  # Sometimes needed for litellm compatibility
    )