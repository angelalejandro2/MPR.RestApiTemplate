from crewai import Crew, Process
from src.agents.agent_factory import AgentFactory
from src.tasks.task_factory import TaskFactory
from src.utils.logger import setup_logger

logger = setup_logger(__name__)

class InsuranceProcessingCrew:
    """Main crew orchestrator for insurance form processing"""
    
    def __init__(self):
        logger.info("Initializing Insurance Processing Crew")
        
        self.agent_factory = AgentFactory()
        self.task_factory = TaskFactory()
        
        self.agents = self.agent_factory.create_all_agents()
        
        self.crew = None
        self.last_completed_step = 0
        
    def kickoff(self, inputs: dict):
        """Execute the crew with given inputs"""
        logger.info(f"Starting crew kickoff with {len(inputs.get('forms', []))} forms")
        
        tasks = self.task_factory.create_pipeline_tasks(
            agents=self.agents,
            forms=inputs.get('forms', []),
            input_dir=inputs.get('input_dir', './data/input_forms'),
            start_from_step=inputs.get('start_from_step', 0)
        )
        
        self.crew = Crew(
            agents=list(self.agents.values()),
            tasks=tasks,
            process=Process.sequential,
            verbose=True,
            memory=False,  # Disable memory for Ollama compatibility
            cache=False,  # Disable cache to prevent JSON errors
            # No max_rpm for local Ollama - unlimited requests
            max_execution_time=300  # 5 minute timeout per task
        )
        
        result = self.crew.kickoff()
        
        return {
            'success': True,
            'output_path': './data/decision_trees/final_tree.md',
            'result': result
        }