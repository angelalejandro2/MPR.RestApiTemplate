from crewai import tools

@tools.tool("Compliance Checker")
def ComplianceCheckerTool(tree: str) -> str:
    """Checks compliance with insurance regulations."""
    return f"Compliance check complete"