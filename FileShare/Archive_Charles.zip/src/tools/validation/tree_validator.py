from langchain.tools import BaseTool
from pydantic import BaseModel, Field
from typing import Dict, List, Tuple
import re

class TreeValidatorInput(BaseModel):
    tree_content: str = Field(description="Decision tree content to validate")
    
class TreeValidatorTool(BaseTool):
    name: str = "Tree Validator"
    description: str = "Validates decision tree structure, paths, and completeness"
    args_schema: type[BaseModel] = TreeValidatorInput
    
    def _run(self, tree_content: str) -> str:
        validation_results = {
            "is_valid": True,
            "errors": [],
            "warnings": [],
            "statistics": {
                "total_nodes": 0,
                "total_results": 0,
                "dead_ends": [],
                "circular_references": []
            }
        }
        
        node_pattern = r"(\d+\.\d*)\s+.*?→\s+(?:Continuar a|RESULTADO)\s+([A-Z0-9.]+)"
        nodes = re.findall(node_pattern, tree_content)
        
        result_pattern = r"RESULTADO\s+([A-Z]):"
        results = re.findall(result_pattern, tree_content)
        
        validation_results["statistics"]["total_nodes"] = len(nodes)
        validation_results["statistics"]["total_results"] = len(results)
        
        nav_map = {}
        for node_id, target in nodes:
            nav_map[node_id] = target
        
        all_targets = set(target for _, target in nodes)
        all_nodes = set(node_id for node_id, _ in nodes)
        result_ids = set(f"RESULTADO {r}" for r in results)
        
        valid_targets = all_nodes.union(result_ids)
        
        for node_id, target in nav_map.items():
            if target not in valid_targets and not target.startswith("RESULTADO"):
                validation_results["errors"].append(
                    f"Node {node_id} points to non-existent target: {target}"
                )
                validation_results["statistics"]["dead_ends"].append(node_id)
        
        required_fields = ["COBERTURA", "LÍMITE", "DEDUCIBLE", "REFERENCIA", "PRÓXIMOS PASOS"]
        result_sections = re.split(r"RESULTADO\s+[A-Z]:", tree_content)[1:]
        
        for i, section in enumerate(result_sections):
            result_id = chr(65 + i)
            for field in required_fields:
                if field not in section:
                    validation_results["warnings"].append(
                        f"RESULTADO {result_id} missing required field: {field}"
                    )
        
        pr_terms = ["huracán", "terremoto", "inundación", "derrumbe"]
        mainland_terms = ["snow", "ice", "freeze", "tornado"]
        
        content_lower = tree_content.lower()
        
        has_pr_content = any(term in content_lower for term in pr_terms)
        if not has_pr_content:
            validation_results["warnings"].append(
                "Tree may be missing Puerto Rico specific scenarios"
            )
        
        for term in mainland_terms:
            if term in content_lower:
                validation_results["errors"].append(
                    f"Tree contains mainland-specific term that should be removed: {term}"
                )
        
        validation_results["is_valid"] = len(validation_results["errors"]) == 0
        
        return self._format_validation_report(validation_results)
    
    def _format_validation_report(self, results: Dict) -> str:
        report = "# Tree Validation Report\n\n"
        
        report += f"## Overall Status: {'✅ VALID' if results['is_valid'] else '❌ INVALID'}\n\n"
        
        report += "## Statistics\n\n"
        stats = results["statistics"]
        report += f"- **Total Nodes**: {stats['total_nodes']}\n"
        report += f"- **Total Results**: {stats['total_results']}\n"
        report += f"- **Dead Ends**: {len(stats['dead_ends'])}\n"
        report += f"- **Circular References**: {len(stats['circular_references'])}\n\n"
        
        if results["errors"]:
            report += "## ❌ Errors (Must Fix)\n\n"
            for error in results["errors"]:
                report += f"- {error}\n"
            report += "\n"
        
        if results["warnings"]:
            report += "## ⚠️ Warnings (Should Review)\n\n"
            for warning in results["warnings"]:
                report += f"- {warning}\n"
            report += "\n"
        
        if results["is_valid"]:
            report += "## ✅ Validation Passed\n\n"
            report += "The decision tree meets all validation criteria and is ready for use.\n"
        else:
            report += "## ❌ Validation Failed\n\n"
            report += "Please address the errors above before proceeding.\n"
        
        return report