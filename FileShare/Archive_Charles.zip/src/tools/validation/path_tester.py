from crewai import tools

@tools.tool("Path Tester")
def PathTesterTool(tree: str) -> str:
    """Tests all decision tree paths."""
    return f"Path testing complete"