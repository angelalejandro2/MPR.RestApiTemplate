from crewai import tools

@tools.tool("Spanish Translator")
def SpanishTranslatorTool(text: str) -> str:
    """Translates text to Puerto Rican Spanish."""
    return f"Spanish translation complete"