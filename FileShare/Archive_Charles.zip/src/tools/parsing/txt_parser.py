from crewai import tools
import os
import logging

logger = logging.getLogger(__name__)

@tools.tool("TXT Parser")
def TxtParserTool(file_path: str) -> str:
    """Extracts text from TXT insurance forms.
    
    Args:
        file_path: Path to the TXT file to parse
        
    Returns:
        Extracted text content from the TXT file
    """
    try:
        if not os.path.exists(file_path):
            return f"Error: File {file_path} does not exist."
        
        with open(file_path, 'r', encoding='utf-8') as f:
            content = f.read()
        
        if not content.strip():
            return f"Error: File {file_path} is empty."
        
        return content
        
    except Exception as e:
        logger.error(f"TXT extraction error: {e}")
        return f"Error extracting from {file_path}: {str(e)}"