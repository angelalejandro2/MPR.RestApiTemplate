from crewai import tools
import PyPDF2
import pdfplumber
import logging
import os

logger = logging.getLogger(__name__)

@tools.tool("PDF Parser")
def PDFParserTool(file_path: str) -> str:
    """Extracts text and structure from PDF insurance forms with fallback strategies.
    
    Args:
        file_path: Path to the PDF file to parse
        
    Returns:
        Extracted text content from the PDF
    """
    try:
        if not os.path.exists(file_path):
            return f"Error: File {file_path} does not exist."
        
        content = _extract_with_pdfplumber(file_path)
        if content and len(content) > 100:
            return content
    except Exception as e:
        logger.warning(f"pdfplumber failed: {e}")
    
    try:
        content = _extract_with_pypdf2(file_path)
        if content and len(content) > 100:
            return content
    except Exception as e:
        logger.error(f"All PDF extraction methods failed: {e}")
        return f"Error: Could not extract content from {file_path}. Manual review required."

def _extract_with_pdfplumber(file_path: str) -> str:
    """Extract using pdfplumber - better for structured content"""
    content = []
    try:
        with pdfplumber.open(file_path) as pdf:
            # Limit to first 10 pages to prevent hanging
            max_pages = min(len(pdf.pages), 10)
            for page_num in range(max_pages):
                page = pdf.pages[page_num]
                text = page.extract_text()
                if text:
                    content.append(f"--- Page {page_num + 1} ---\n{text}")
                
                # Only extract tables from first 3 pages
                if page_num < 3:
                    tables = page.extract_tables()
                    for table in tables[:2]:  # Limit to 2 tables per page
                        content.append("\n[TABLE DATA]")
                        for row in table[:10]:  # Limit rows
                            if row:
                                content.append(" | ".join(str(cell)[:50] for cell in row if cell))
        
        return "\n\n".join(content)
    except Exception as e:
        logger.error(f"PDFPlumber extraction error: {e}")
        return f"Error extracting with pdfplumber: {str(e)}"

def _extract_with_pypdf2(file_path: str) -> str:
    """Fallback extraction using PyPDF2"""
    content = []
    try:
        with open(file_path, 'rb') as file:
            pdf_reader = PyPDF2.PdfReader(file)
            # Limit to first 10 pages to prevent hanging
            max_pages = min(len(pdf_reader.pages), 10)
            for page_num in range(max_pages):
                page = pdf_reader.pages[page_num]
                text = page.extract_text()
                if text:
                    content.append(f"--- Page {page_num + 1} ---\n{text}")
        
        return "\n\n".join(content)
    except Exception as e:
        logger.error(f"PyPDF2 extraction error: {e}")
        return f"Error extracting with PyPDF2: {str(e)}"