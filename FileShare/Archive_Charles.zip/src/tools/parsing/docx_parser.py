from crewai import tools
import docx
import logging
import os

logger = logging.getLogger(__name__)

@tools.tool("DOCX Parser")
def DocxParserTool(file_path: str) -> str:
    """Extracts text and structure from DOCX insurance forms.
    
    Args:
        file_path: Path to the DOCX file to parse
        
    Returns:
        Extracted text content from the DOCX file
    """
    try:
        if not os.path.exists(file_path):
            return f"Error: File {file_path} does not exist."
        
        doc = docx.Document(file_path)
        content = []
        
        for paragraph in doc.paragraphs:
            if paragraph.text.strip():
                content.append(paragraph.text)
        
        for table in doc.tables:
            content.append("\n[TABLE DATA]")
            for row in table.rows:
                cells = [cell.text.strip() for cell in row.cells]
                content.append(" | ".join(cells))
        
        return "\n\n".join(content)
        
    except Exception as e:
        logger.error(f"DOCX extraction failed: {e}")
        return f"Error: Could not extract content from {file_path}. {str(e)}"