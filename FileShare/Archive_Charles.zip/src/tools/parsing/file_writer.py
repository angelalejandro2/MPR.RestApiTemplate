from crewai import tools
import os
import logging

logger = logging.getLogger(__name__)

@tools.tool("File Writer")
def FileWriterTool(content: str, file_path: str) -> str:
    """Writes content to a file at the specified path.
    
    Args:
        content: The content to write to the file
        file_path: The absolute path where to save the file
        
    Returns:
        Success message or error details
    """
    try:
        # Ensure directory exists
        directory = os.path.dirname(file_path)
        if directory:
            os.makedirs(directory, exist_ok=True)
        
        # Write content to file
        with open(file_path, 'w', encoding='utf-8') as f:
            f.write(content)
        
        logger.info(f"Successfully wrote file: {file_path}")
        return f"Successfully saved file to: {file_path}"
        
    except Exception as e:
        error_msg = f"Error writing file {file_path}: {str(e)}"
        logger.error(error_msg)
        return error_msg