from crewai import tools
import subprocess
import os
import logging

logger = logging.getLogger(__name__)

@tools.tool("DOC Parser")
def DocParserTool(file_path: str) -> str:
    """Extracts text from DOC (old Word format) files.
    
    Args:
        file_path: Path to the DOC file to parse
        
    Returns:
        Extracted text content from the DOC file
    """
    try:
        if not os.path.exists(file_path):
            return f"Error: File {file_path} does not exist."
        
        # Try antiword first (most reliable for .doc files)
        try:
            result = subprocess.run(
                ['antiword', file_path], 
                capture_output=True, 
                text=True, 
                timeout=30
            )
            if result.returncode == 0 and result.stdout.strip():
                return result.stdout
        except (subprocess.TimeoutExpired, FileNotFoundError):
            logger.warning("antiword not available or timed out")
        
        # Fallback: try to read as binary and extract what we can
        with open(file_path, 'rb') as f:
            content = f.read()
            # Simple text extraction - look for readable ASCII text
            text_content = ''.join(chr(b) for b in content if 32 <= b <= 126 or b in [9, 10, 13])
            
            if len(text_content) > 100:
                return f"# DOC File Content (partial extraction)\n\n{text_content[:2000]}..."
        
        return "Error: Could not extract readable content from DOC file. Consider converting to DOCX format."
        
    except Exception as e:
        logger.error(f"DOC extraction failed: {e}")
        return f"Error: Could not extract content from {file_path}. {str(e)}"