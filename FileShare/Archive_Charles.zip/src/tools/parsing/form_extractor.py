from crewai import tools
import re

@tools.tool("Form Extractor")
def FormExtractorTool(text: str) -> str:
    """Extracts structured insurance form data including coverages, limits, and exclusions.
    
    Args:
        text: Raw text from insurance form to extract structured data
        
    Returns:
        Structured markdown format of extracted insurance data
    """
    extracted = {
        "policy_info": _extract_policy_info(text),
        "coverages": _extract_coverages(text),
        "limits": _extract_limits(text),
        "exclusions": _extract_exclusions(text),
        "definitions": _extract_definitions(text)
    }
    
    return _format_markdown(extracted)

def _extract_policy_info(text: str) -> dict:
    info = {}
    
    policy_patterns = {
        "policy_number": r"policy\s+(?:number|no\.?)\s*:?\s*([A-Z0-9-]+)",
        "effective_date": r"effective\s+date\s*:?\s*(\d{1,2}/\d{1,2}/\d{4})",
        "expiration_date": r"expir(?:ation|es?)\s+date\s*:?\s*(\d{1,2}/\d{1,2}/\d{4})"
    }
    
    for key, pattern in policy_patterns.items():
        match = re.search(pattern, text, re.IGNORECASE)
        if match:
            info[key] = match.group(1)
    
    return info

def _extract_coverages(text: str) -> list:
    coverages = []
    
    coverage_patterns = [
        r"coverage\s+[a-z]?\s*[-:]\s*([^.]+)",
        r"dwelling\s+coverage\s*:?\s*([^.]+)",
        r"personal\s+property\s*:?\s*([^.]+)",
        r"liability\s+coverage\s*:?\s*([^.]+)"
    ]
    
    for pattern in coverage_patterns:
        matches = re.finditer(pattern, text, re.IGNORECASE)
        for match in matches:
            coverages.append({
                "type": match.group(1).strip(),
                "context": _get_context(text, match.start(), match.end())
            })
    
    return coverages

def _extract_limits(text: str) -> list:
    limits = []
    
    limit_patterns = [
        r"limit\s*:?\s*\$?([\d,]+)",
        r"\$?([\d,]+)\s+limit",
        r"maximum\s+(?:of\s+)?\$?([\d,]+)"
    ]
    
    for pattern in limit_patterns:
        matches = re.finditer(pattern, text, re.IGNORECASE)
        for match in matches:
            limits.append({
                "amount": match.group(1),
                "context": _get_context(text, match.start(), match.end())
            })
    
    return limits

def _extract_exclusions(text: str) -> list:
    exclusions = []
    
    exclusion_sections = re.split(r'exclusions?\s*:?', text, flags=re.IGNORECASE)
    if len(exclusion_sections) > 1:
        exclusion_text = exclusion_sections[1]
        
        exclusion_items = re.split(r'\n\s*[a-z]\)|^\s*\d+\.|•|–|-', exclusion_text)
        for item in exclusion_items:
            clean_item = item.strip()
            if clean_item and len(clean_item) > 10:
                exclusions.append(clean_item)
    
    return exclusions

def _extract_definitions(text: str) -> list:
    definitions = []
    
    definition_sections = re.split(r'definitions?\s*:?', text, flags=re.IGNORECASE)
    if len(definition_sections) > 1:
        def_text = definition_sections[1]
        
        def_pattern = r'([A-Z][A-Za-z\s]+)\s*(?:means?|is|refers?\s+to)\s*([^.]+\.)'
        matches = re.finditer(def_pattern, def_text)
        
        for match in matches:
            definitions.append({
                "term": match.group(1).strip(),
                "definition": match.group(2).strip()
            })
    
    return definitions

def _get_context(text: str, start: int, end: int, context_length: int = 100) -> str:
    context_start = max(0, start - context_length)
    context_end = min(len(text), end + context_length)
    return text[context_start:context_end].strip()

def _format_markdown(extracted: dict) -> str:
    markdown = "# Insurance Form Analysis\n\n"
    
    if extracted["policy_info"]:
        markdown += "## Policy Information\n\n"
        for key, value in extracted["policy_info"].items():
            markdown += f"- **{key.replace('_', ' ').title()}**: {value}\n"
        markdown += "\n"
    
    if extracted["coverages"]:
        markdown += "## Coverages\n\n"
        for i, coverage in enumerate(extracted["coverages"], 1):
            markdown += f"### Coverage {i}\n"
            markdown += f"- **Type**: {coverage['type']}\n"
            markdown += f"- **Context**: {coverage['context']}\n\n"
    
    if extracted["limits"]:
        markdown += "## Coverage Limits\n\n"
        for limit in extracted["limits"]:
            markdown += f"- **Amount**: ${limit['amount']}\n"
            markdown += f"- **Context**: {limit['context']}\n\n"
    
    if extracted["exclusions"]:
        markdown += "## Exclusions\n\n"
        for exclusion in extracted["exclusions"]:
            markdown += f"- {exclusion}\n"
        markdown += "\n"
    
    if extracted["definitions"]:
        markdown += "## Definitions\n\n"
        for definition in extracted["definitions"]:
            markdown += f"**{definition['term']}**: {definition['definition']}\n\n"
    
    return markdown