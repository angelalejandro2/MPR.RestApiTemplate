from crewai import tools
from langchain_ollama import OllamaLLM

@tools.tool("Tree Builder")
def TreeBuilderTool(form_analysis: str, questions: str = "") -> str:
    """Builds comprehensive decision trees dynamically from actual policy content.
    
    Args:
        form_analysis: Complete form analysis with all policy details
        questions: Generated questions from the policy
    
    Returns:
        Dynamic decision tree based on actual policy content
    """
    
    # Initialize LLM for dynamic generation
    import os
    ollama_model = os.getenv("OLLAMA_MODEL", "gemma3:4b")
    ollama_base_url = os.getenv("OLLAMA_BASE_URL", "http://localhost:11434")
    
    llm = OllamaLLM(
        model=ollama_model,
        base_url=ollama_base_url,
        temperature=0.1
    )
    
    # Create structured prompt that analyzes ALL content but requests organized output
    tree_prompt = f"""Analiza EXHAUSTIVAMENTE toda la información de esta póliza y crea un árbol de decisión GRANULAR y COMPLETO en español para Puerto Rico:

ANÁLISIS COMPLETO DE LA PÓLIZA:
{form_analysis}

PREGUNTAS RELACIONADAS:
{questions}

REQUISITOS DE GRANULARIDAD:

1. **COMPLETITUD TOTAL**: Incluir CADA cobertura, límite, exclusión y condición mencionados
2. **MONTOS EXACTOS**: Usar TODOS los valores monetarios específicos ($X, $Y, $Z)
3. **DETALLES ESPECÍFICOS**: Incluir porcentajes, períodos, condiciones especiales
4. **MÚLTIPLES NIVELES**: Crear sub-decisiones para cada tipo de propiedad/evento
5. **EXCLUSIONES COMPLETAS**: Listar TODAS las exclusiones y limitaciones
6. **DEFINICIONES INCLUIDAS**: Incorporar términos técnicos importantes
7. **CASOS DE BORDE**: Cubrir situaciones especiales y excepciones

ESTRUCTURA GRANULAR REQUERIDA:
- Mínimo 8-12 secciones principales
- Sub-niveles detallados (X.1, X.1.1, X.1.2, etc.)
- Cada cobertura con sus límites específicos
- Cada exclusión claramente identificada
- Condiciones y requisitos detallados
- Próximos pasos específicos para cada resultado

FORMATO: Árbol de decisión en español, nivel 5to grado, con emojis, pero SIN OMITIR información técnica importante.

CRÍTICO: NO simplificar ni condensar. Usar TODA la información disponible en el documento para crear un árbol comprehensive que cubra cada aspecto de la póliza."""
    
    # Generate dynamic tree
    tree_content = llm.invoke(tree_prompt)
    
    return tree_content