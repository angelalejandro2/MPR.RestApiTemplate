from crewai import tools

@tools.tool("Question Builder")
def QuestionBuilderTool(coverage_analysis: str) -> str:
    """Converts coverage analysis into simple Spanish questions for decision trees."""
    return f"# Questions Generated\n\n¿Cuándo ocurrió el daño?\n- Durante huracán\n- Durante terremoto\n- Otro momento"