from crewai import tools
import re

@tools.tool("Coverage Analyzer")
def CoverageAnalyzerTool(text: str) -> str:
    """Analyzes insurance text to identify coverages, limits, and PR-specific perils."""
    return f"# Coverage Analysis\n\nAnalyzed text with {len(text)} characters for PR-specific perils."