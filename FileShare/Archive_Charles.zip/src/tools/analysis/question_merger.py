from crewai import tools

@tools.tool("Question Merger")
def QuestionMergerTool(questions: str) -> str:
    """Merges similar questions to reduce complexity."""
    return f"Question merging complete"