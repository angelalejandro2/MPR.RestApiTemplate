from src.agents.definitions.form_parser_agent import FormParserAgentDefinition
from src.agents.definitions.question_generator_agent import QuestionGeneratorAgentDefinition
from src.agents.definitions.tree_builder_agent import TreeBuilderAgentDefinition
from src.agents.definitions.tree_simplifier_agent import TreeSimplifierAgentDefinition
from src.agents.definitions.spanish_translator_agent import SpanishTranslatorAgentDefinition
from src.agents.definitions.qa_manager_agent import QAManagerAgentDefinition

class AgentFactory:
    """Factory for creating all agents"""
    
    def create_all_agents(self):
        """Create and return all agents"""
        return {
            'form_parser': FormParserAgentDefinition.create(),
            'question_generator': QuestionGeneratorAgentDefinition.create(),
            'tree_builder': TreeBuilderAgentDefinition.create(),
            'tree_simplifier': TreeSimplifierAgentDefinition.create(),
            'spanish_translator': SpanishTranslatorAgentDefinition.create(),
            'qa_manager': QAManagerAgentDefinition.create()
        }