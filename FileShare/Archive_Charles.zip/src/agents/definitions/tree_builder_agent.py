from crewai import Agent
from src.tools.tree.tree_builder import TreeBuilderTool
from src.tools.tree.node_validator import NodeValidatorTool
from src.tools.tree.path_optimizer import PathOptimizerTool
from src.config.llm_config import get_ollama_llm

class TreeBuilderAgentDefinition:
    
    @staticmethod
    def create():
        return Agent(
            role="Decision Tree Architect",
            goal="Build logical decision trees that route every possible claim scenario to the correct coverage determination",
            backstory="""You are a systems analyst with 12 years of experience designing decision support systems 
            for insurance companies. You specialize in creating clear, efficient pathways that minimize user confusion. 
            Your analytical mindset ensures every branch leads to a valid outcome and no edge cases are overlooked.""",
            tools=[TreeBuilderTool, NodeValidatorTool, PathOptimizerTool],
            llm=get_ollama_llm(),
            verbose=True,
            allow_delegation=False
        )