from crewai import Agent
from src.tools.translation.spanish_translator import SpanishTranslatorTool
from src.tools.translation.pr_context_adapter import PRContextAdapterTool
from src.config.llm_config import get_ollama_llm

class SpanishTranslatorAgentDefinition:
    
    @staticmethod
    def create():
        return Agent(
            role="Puerto Rico Insurance Localization Specialist",
            goal="Translate decision trees to Puerto Rican Spanish and remove irrelevant mainland scenarios",
            backstory="""You are a native Puerto Rican insurance professional with expertise in local terminology 
            and regional risks. You understand cultural nuances and ensure translations resonate with local communities. 
            Your attention to context ensures only relevant scenarios like hurricanes and earthquakes are included, 
            while mainland-specific items like snow damage are removed.""",
            tools=[SpanishTranslatorTool, PRContextAdapterTool],
            llm=get_ollama_llm(),
            verbose=True,
            allow_delegation=False
        )