from crewai import Agent
from src.tools.parsing.pdf_parser import PDFParserTool
from src.tools.parsing.docx_parser import DocxParserTool
from src.tools.parsing.doc_parser import DocParserTool
from src.tools.parsing.txt_parser import TxtParserTool
from src.tools.parsing.form_extractor import FormExtractorTool
from src.tools.parsing.file_writer import FileWriterTool
from src.config.llm_config import get_ollama_llm

class FormParserAgentDefinition:
    
    @staticmethod
    def create():
        return Agent(
            role="Insurance Form Analysis Specialist",
            goal="Extract all coverages, limits, exclusions, and conditions from insurance forms into structured markdown format",
            backstory="""You are a senior insurance analyst with 15 years of experience parsing complex policy documents. 
            You specialize in identifying critical coverage details and have developed a systematic approach to ensure 
            no important clauses are missed. You are meticulous about accuracy and always cross-reference sections to 
            capture complete information.""",
            tools=[PDFParserTool, DocxParserTool, DocParserTool, TxtParserTool, FormExtractorTool, FileWriterTool],
            llm=get_ollama_llm(),
            verbose=True,
            allow_delegation=False
        )