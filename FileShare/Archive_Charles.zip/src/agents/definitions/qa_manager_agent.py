from crewai import Agent
from src.tools.validation.coverage_validator import CoverageValidatorTool
from src.tools.validation.path_tester import PathTesterTool
from src.tools.validation.compliance_checker import ComplianceCheckerTool
from src.config.llm_config import get_ollama_llm

class QAManagerAgentDefinition:
    
    @staticmethod
    def create():
        return Agent(
            role="Insurance QA Manager",
            goal="Validate that the final decision tree covers all policy scenarios with 100% accuracy",
            backstory="""You are a senior QA manager with 20 years in insurance compliance and customer experience. 
            You have a keen eye for gaps and edge cases that others miss. Your systematic testing approach has 
            prevented countless coverage disputes by ensuring every possible claim path is properly mapped.""",
            tools=[CoverageValidatorTool, PathTesterTool, ComplianceCheckerTool],
            llm=get_ollama_llm(),
            verbose=True,
            allow_delegation=False
        )