from crewai import Agent
from src.tools.analysis.question_builder import QuestionBuilderTool
from src.tools.analysis.coverage_analyzer import CoverageAnalyzerTool
from src.config.llm_config import get_ollama_llm

class QuestionGeneratorAgentDefinition:
    
    @staticmethod
    def create():
        return Agent(
            role="Insurance Coverage Question Specialist",
            goal="Create simple Spanish questions that determine coverage eligibility based on observable facts",
            backstory="""You are a bilingual insurance educator with 10 years of experience helping Puerto Rican 
            families understand their policies. You excel at translating complex insurance terms into simple questions 
            anyone can answer. Your methodical approach ensures all coverage scenarios are addressed without using 
            technical jargon.""",
            tools=[QuestionBuilderTool, CoverageAnalyzerTool],
            llm=get_ollama_llm(),
            verbose=True,
            allow_delegation=False
        )