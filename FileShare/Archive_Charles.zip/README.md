# 🇵🇷 Insurance Claim Processing System - Puerto Rico

Sistema automatizado de procesamiento de reclamos de seguros específicamente diseñado para residentes de Puerto Rico. Genera árboles de decisión dinámicos en español basados en pólizas reales.

## 🎯 Características Principales

- ✅ **Procesamiento Dinámico**: Analiza cualquier póliza de seguro automáticamente
- ✅ **Multi-formato**: Soporta PDF, DOCX, DOC, TXT
- ✅ **Puerto Rico Específico**: Incluye huracanes, terremotos, contexto local
- ✅ **Español 5to Grado**: Lenguaje accesible con emojis y explicaciones simples
- ✅ **6 Pasos Automatizados**: Desde análisis hasta QA final
- ✅ **GPU Optimizado**: Soporte para Apple Silicon y NVIDIA

## 🚀 Instalación Rápida

### Prerrequisitos

1. **Python 3.8+**
   ```bash
   python --version  # Debe ser 3.8 o superior
   ```

2. **Ollama** (LLM local)
   ```bash
   # Instalar Ollama
   curl -fsSL https://ollama.ai/install.sh | sh
   
   # Instalar modelo requerido
   ollama pull gemma3:4b
   
   # Verificar que funciona
   ollama serve
   ```

### Instalación del Sistema

1. **Clonar y configurar**
   ```bash
   git clone <repository-url>
   cd insurance-claim-crew
   
   # Crear entorno virtual
   python -m venv venv
   
   # Activar entorno virtual
   # En macOS/Linux:
   source venv/bin/activate
   # En Windows:
   # venv\Scripts\activate
   
   # Instalar dependencias
   pip install -r requirements.txt
   ```

2. **Configurar directorios**
   ```bash
   # Los directorios se crean automáticamente, pero puedes verificar:
   mkdir -p data/input_forms
   mkdir -p data/form_results
   mkdir -p data/question_results
   mkdir -p data/decision_trees
   mkdir -p data/qa_reports
   ```

## 📋 Uso del Sistema

### Ejecutar Procesamiento Completo

1. **Colocar pólizas en la carpeta de entrada**
   ```bash
   # Copiar cualquier archivo de póliza a:
   cp tu_poliza.pdf data/input_forms/
   ```

2. **Ejecutar sistema optimizado**
   ```bash
   # Activar entorno virtual
   source venv/bin/activate
   
   # Ejecutar procesamiento completo
   python main.py --simple
   ```

3. **Resultados**
   ```
   📊 El sistema generará:
   ├── data/form_results/           # Análisis de cada póliza
   ├── data/question_results/       # Preguntas específicas
   ├── data/decision_trees/         # Árboles individuales + final
   └── data/qa_reports/            # Validación de calidad
   ```

### Formatos Soportados

- **✅ PDF** - Pólizas escaneadas o digitales
- **✅ DOCX** - Documentos Word modernos
- **✅ DOC** - Documentos Word antiguos  
- **✅ TXT** - Archivos de texto plano

### Ejemplo de Salida

```
📋 FORM 1/4: Microsoft Word - CP0010OV.pdf
  Step 1: Form Analysis... ✅
  Step 2: Question Generation... ✅
  Step 3: Individual Decision Tree... ✅

🎉 COMPLETE 6-STEP WORKFLOW FINISHED!
📊 ALL STEPS COMPLETED FOR ALL FORMS
🇵🇷 Ready for Puerto Rico residents!
```

## 🛠️ Configuración Avanzada

### Variables de Entorno (.env)

Crear archivo `.env` (opcional):
```bash
# Configuración Ollama
OLLAMA_BASE_URL=http://localhost:11434
OLLAMA_MODEL=gemma3:4b

# Directorios (opcional, usa defaults)
INPUT_FORMS_DIR=./data/input_forms
OUTPUT_DIR=./data
```

### Optimización de Rendimiento

1. **GPU Acceleration** (Automático)
   - ✅ Apple Silicon (Metal)
   - ✅ NVIDIA CUDA
   - ✅ CPU fallback

2. **Cambiar Modelo de Ollama**

   **Modelos Disponibles:**
   ```bash
   # Velocidad vs Precisión vs Recursos
   ollama pull gemma3:2b      # Más rápido, menos precisión (2GB RAM)
   ollama pull gemma3:4b      # Balanceado - RECOMENDADO (4GB RAM)
   ollama pull gemma3:7b      # Más preciso, más lento (8GB RAM)
   ollama pull llama3:8b      # Alternativa de Meta (8GB RAM)
   ollama pull mistral:7b     # Alternativa europea (7GB RAM)
   ```

   **Opción 1: Cambiar en .env**
   ```bash
   # Crear/editar archivo .env
   cp .env.example .env
   
   # Editar la línea del modelo:
   OLLAMA_MODEL=gemma3:2b     # Para más velocidad
   # o
   OLLAMA_MODEL=gemma3:7b     # Para más precisión
   # o 
   OLLAMA_MODEL=llama3:8b     # Modelo alternativo
   ```

   **Opción 2: Cambiar directamente en el código**
   ```bash
   # Editar main.py línea ~68:
   # Cambiar:
   model="gemma3:4b"
   # Por:
   model="gemma3:2b"  # o el modelo que prefieras
   ```

   **Opción 3: Cambiar temporalmente**
   ```bash
   # Descargar nuevo modelo
   ollama pull gemma3:7b
   
   # Editar temporalmente el código antes de ejecutar
   sed -i 's/gemma3:4b/gemma3:7b/g' main.py
   
   # Ejecutar
   python main.py --simple
   
   # Restaurar modelo original
   sed -i 's/gemma3:7b/gemma3:4b/g' main.py
   ```

   **Comparación de Modelos:**
   | Modelo | Tamaño | RAM Req. | Velocidad | Precisión | Recomendado Para |
   |--------|--------|----------|-----------|-----------|------------------|
   | gemma3:2b | 2GB | 3GB | ⚡⚡⚡ | ⭐⭐ | Pruebas rápidas |
   | gemma3:4b | 4GB | 5GB | ⚡⚡ | ⭐⭐⭐ | **Uso general** |
   | gemma3:7b | 7GB | 8GB | ⚡ | ⭐⭐⭐⭐ | Máxima calidad |
   | llama3:8b | 8GB | 10GB | ⚡ | ⭐⭐⭐⭐ | Alternativa precisa |

## 📁 Estructura del Proyecto

```
insurance-claim-crew/
├── main.py                    # Punto de entrada principal
├── requirements.txt           # Dependencias Python
├── README.md                 # Esta documentación
├── .env                      # Configuración (opcional)
├── data/                     # Datos y resultados
│   ├── input_forms/          # 📥 Pólizas a procesar
│   ├── form_results/         # 📄 Análisis de pólizas
│   ├── question_results/     # ❓ Preguntas generadas
│   ├── decision_trees/       # 🌳 Árboles de decisión
│   └── qa_reports/          # ✅ Reportes de calidad
└── src/                      # Código fuente
    ├── agents/              # Agentes CrewAI
    ├── tasks/               # Tareas del pipeline
    ├── tools/               # Herramientas de procesamiento
    ├── config/              # Configuración
    └── utils/               # Utilidades
```

## 🔧 Solución de Problemas

### Error: "Ollama not running"
```bash
# Iniciar Ollama
ollama serve

# En otra terminal, verificar:
curl http://localhost:11434/api/tags
```

### Error: "Model not found"
```bash
# Instalar modelo requerido
ollama pull gemma3:4b

# Verificar modelos instalados
ollama list
```

### Error: "Module not found"
```bash
# Verificar entorno virtual activado
source venv/bin/activate

# Reinstalar dependencias
pip install -r requirements.txt
```

### Error: "Permission denied"
```bash
# En macOS/Linux, dar permisos:
chmod +x main.py

# Verificar permisos de directorios:
chmod -R 755 data/
```

### Error: "Model not responding" o "Too slow"
```bash
# Cambiar a modelo más rápido:
ollama pull gemma3:2b

# Editar .env:
echo "OLLAMA_MODEL=gemma3:2b" > .env

# O cambiar temporalmente:
OLLAMA_MODEL=gemma3:2b python main.py --simple
```

### Error: "Out of memory" o "Model too large"
```bash
# Usar modelo más pequeño:
ollama pull gemma3:2b

# Verificar RAM disponible:
free -h  # Linux
top      # macOS

# Cambiar a modelo que quepa en tu RAM:
# 2GB RAM: gemma3:2b
# 4GB RAM: gemma3:4b  
# 8GB+ RAM: gemma3:7b o llama3:8b
```

## 🚀 Comandos de Inicio Rápido

```bash
# Setup completo desde cero
git clone <repo>
cd insurance-claim-crew
python -m venv venv
source venv/bin/activate  # En Windows: venv\Scripts\activate
pip install -r requirements.txt

# Instalar y configurar Ollama
curl -fsSL https://ollama.ai/install.sh | sh
ollama pull gemma3:4b  # Modelo recomendado
ollama serve &

# OPCIONAL: Cambiar modelo según tus recursos
# ollama pull gemma3:2b  # Para máquinas con poca RAM
# ollama pull gemma3:7b  # Para máxima calidad
# echo "OLLAMA_MODEL=gemma3:2b" > .env  # Aplicar cambio

# Procesar pólizas (en otra terminal)
source venv/bin/activate
cp mi_poliza.pdf data/input_forms/
python main.py --simple
```

### 🔧 Cambio Rápido de Modelo Durante Ejecución

```bash
# Probar con modelo más rápido:
OLLAMA_MODEL=gemma3:2b python main.py --simple

# Probar con modelo más preciso:
OLLAMA_MODEL=gemma3:7b python main.py --simple

# Usar modelo alternativo:
OLLAMA_MODEL=llama3:8b python main.py --simple
```

## 📊 Resultados Esperados

Después de ejecutar exitosamente:

- **4+ archivos** en `form_results/` (análisis de pólizas)
- **4+ archivos** en `question_results/` (preguntas específicas)
- **4+ archivos** en `decision_trees/tree_*.md` (árboles individuales)
- **1 archivo** `decision_trees/FINAL_TREE.md` (árbol consolidado)
- **1 archivo** `qa_reports/REAL_QA_VALIDATION.md` (validación)

## 🇵🇷 Contexto Puerto Rico

El sistema está específicamente optimizado para:

- **Riesgos locales**: Huracanes, terremotos, inundaciones
- **Idioma**: Español accesible (nivel 5to grado)
- **Cultura**: Contexto familiar y emojis relevantes
- **Exclusiones**: Elimina riesgos no aplicables (nieve, hielo)

## 📞 Soporte

Para problemas técnicos:
1. Verificar que Ollama esté corriendo
2. Confirmar que el modelo `gemma3:4b` esté instalado
3. Revisar logs en la consola para errores específicos
4. Verificar que las pólizas estén en formato soportado

---

**🎉 ¡Sistema listo para procesar pólizas de seguros para Puerto Rico!**