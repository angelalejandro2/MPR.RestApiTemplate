# Preguntas de Decisión: Microsoft Word - CP0010OV.pdf

Okay, here’s a breakdown of questions based on the provided text, formatted as markdown with clear yes/no questions.  I’ve categorized them for clarity.

---

**I. Coverage Amounts & Deductibles**

1.  **Question:** What is the maximum limit of insurance for Business Personal Property under this policy?
    *   **Answer:** $140,000 (This is derived from the example calculation).

2.  **Question:** Does the policy include a deductible?
    *   **Answer:** Yes.

3.  **Question:**  If the adjusted amount of loss is less than or equal to the deductible, will the insurance company pay out?
    *   **Answer:** No.

4.  **Question:**  Can the insurance company and the policyholder agree on a value of the property in the event of an appraisal?
    *   **Answer:** Yes.

5.  **Question:**  Does the deductible apply once per occurrence?
    *   **Answer:** Yes.

6.  **Question:**  If the loss is equal to or less than the deductible, will the insurance company pay out?
    *   **Answer:** No.

---

**II. Puerto Rico Risks (Hurricanes, Earthquakes)**

7.  **Question:** Does this policy specifically address risks associated with hurricanes?
    *   **Answer:** No. (The text doesn't mention specific coverage for hurricanes.)

8.  **Question:** Does this policy provide coverage for earthquake damage?
    *   **Answer:** No. (The text doesn’t mention earthquake coverage.)

9.  **Question:**  Does the policy cover damage from “sand, dust, sleet, snow, ice or rain” to property in a structure?
    *   **Answer:** Yes, but with a limitation. (It covers this, but the limitation applies to property in a portable storage unit.)

10. **Question:**  Does the policy cover damage from a portable storage unit?
    *   **Answer:** Yes, but with a limitation. (It covers this, but the limitation applies to property in a structure.)

---

**III. Policy Terms & Conditions**

11. **Question:** Does the policy include a Coinsurance clause?
    *   **Answer:** No. (The text explicitly states “This insurance: excess over the Additional Condition, Coinsurance, does not apply to these Extensions.”)

12. **Question:**  If an appraisal is required, who bears the expenses of the appraisal?
    *   **Answer:**  Both the insurance company and the policyholder share the expenses.

13. **Question:**  Can the insurance company deny a claim even after an appraisal?
    *   **Answer:** Yes. (The text states: “But the Deductible will be subtracted from the amount of loss payable for Building 1: If we and you d’agree on the value of the property and amount of loss.”)

14. **Question:**  Does the policy cover damage to a trailer used in business?
    *   **Answer:** Yes, under the Extension.

15. **Question:**  Does the policy cover damage to a trailer stored for 90 days or fewer?
    *   **Answer:** Yes, under the Extension.

16. **Question:**  Does the policy cover damage to outdoor fences?
    *   **Answer:** No. (The text specifically excludes outdoor fences.)

17. **Question:**  Does the policy cover damage to radio and television equipment?
    *   **Answer:** No. (The text specifically excludes outdoor fences, radio and television equipment.)

18. **Question:**  Does the policy cover damage to a trailer that becomes accidentally unhitched from a motor vehicle?
    *   **Answer:** No. (The text specifically excludes damage to a trailer that becomes accidentally unhitched from a motor vehicle.)

---

**Important Disclaimer:** *This analysis is based solely on the provided text. A full understanding of the policy requires reviewing the complete policy document. This is not legal or insurance advice.*
