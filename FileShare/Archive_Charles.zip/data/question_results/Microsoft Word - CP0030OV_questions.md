# Preguntas de Decisión: Microsoft Word - CP0030OV.pdf

Okay, here’s a markdown document outlining questions based on the provided insurance text, focusing on the key areas you requested.

---

# Insurance Policy Questions – Detailed Analysis

This document contains questions designed to assess your understanding of the insurance policy, specifically regarding coverage amounts, risk considerations, and policy terms.

## Section 1: Coverage Amounts & Deductibles

**Q1: What is the standard deductible for Business Income loss under this policy?**
   * Yes / No (Provide specific dollar amount)

**Q2:  What is the standard deductible for Extra Expense?**
   * Yes / No (Provide specific dollar amount)

**Q3:  The policy mentions “Agreed Value.”  Can you explain how this affects the maximum payout for Business Income loss?**
   * Yes / No (Brief explanation)

**Q4:  The policy outlines a Coinsurance requirement.  What does this mean, and how does it impact the amount paid out?**
   * Yes / No (Brief explanation)

**Q5:  If the Business Income Limit of Insurance is $150,000 and the Coinsurance percentage is 50%, what is the minimum amount of insurance required to meet the Coinsurance requirement?**
   * Yes / No (Provide specific dollar amount)

## Section 2: Puerto Rico Risks & Specific Considerations

**Q6:  Does this policy specifically address risks associated with hurricanes in Puerto Rico?**
   * Yes / No (Brief explanation – e.g., “Yes, it includes…” or “No, it’s primarily focused on…” )

**Q7:  Does the policy provide coverage for damage caused by earthquakes in Puerto Rico?**
   * Yes / No (Brief explanation)

**Q8:  The policy mentions “mining properties.”  Does this Optional Coverage apply to mining operations in Puerto Rico?**
   * Yes / No (Brief explanation)

**Q9:  The policy states “actual depletion commonly does not apply to this Coverage Form at the described premises to which this Optional Coverage applies.”  What does this mean in the context of Puerto Rico?**
   * Yes / No (Brief explanation)

**Q10:  The policy includes a 12-month period for reporting on the Work Sheet.  What is the purpose of this reporting period?**
   * Yes / No (Brief explanation)



## Section 3: Policy Terms & Conditions

**Q1: What is the definition of “Necessary Expenses” as used in the policy?**
   * Yes / No (Provide specific definition or key elements)

**Q2:  What is the “Agreed Value” and how is it determined?**
   * Yes / No (Brief explanation)

**Q3:  The policy states “If the Business Income Limit of Insurance is less than the Agreed Value, we will not pay more of any loss than the amount of loss multiplied by…” What is the multiplier?**
   * Yes / No (Provide specific dollar amount)

**Q4:  The policy mentions a 12-month period for reporting on the Work Sheet.  What is the purpose of this reporting period?**
   * Yes / No (Brief explanation – e.g., “Yes, it includes…” or “No, it’s primarily focused on…” )

**Q5:  The policy mentions a 12-month period for reporting on the Work Sheet.  What is the purpose of this reporting period?**
   * Yes / No (Brief explanation – e.g., “Yes, it includes…” or “No, it’s primarily focused on…” )

---

**Notes:**

*   This document is based solely on the provided text. A full understanding requires reviewing the complete insurance policy document.
*   The “Yes/No” questions are designed to gauge your understanding of key concepts.  Provide specific answers where possible.

Let me know if you’d like me to elaborate on any of these questions or create additional ones!