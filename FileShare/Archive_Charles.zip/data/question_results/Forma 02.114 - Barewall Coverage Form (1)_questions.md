# Preguntas de Decisión: Forma 02.114 - Barewall Coverage Form (1).pdf

Okay, here’s a set of questions based on the provided insurance excerpt, formatted as markdown with yes/no questions, categorized as requested:

## Insurance Excerpt Questions

**I. Coverage Amounts & Deductibles**

1.  **Question:** Does this Optional Coverage automatically include a deductible?
    *   **Answer:** No. It specifies that you may make a claim for loss or damage on an actual cash value basis, but doesn't state a deductible is included.

2.  **Question:** Can you claim loss or damage on an actual cash value basis without specifying a deductible?
    *   **Answer:** Yes. The excerpt states you *may* make a claim on an actual cash value basis.

3.  **Question:** Does the policy explicitly define the amount of the Limit of Insurance?
    *   **Answer:** No. It states the Limit of Insurance is applicable to the lost or damaged property.

4.  **Question:**  If you choose to settle loss on an actual cash value basis, does this automatically trigger a deductible?
    *   **Answer:** No. The excerpt states you *may* make a claim on an actual cash value basis.

5.  **Question:**  Can you claim for loss or damage on a replacement cost basis?
    *   **Answer:** Yes. The excerpt states you *may* make a claim on an actual cash value basis.

## Puerto Rico Risks

6.  **Question:** Does this Optional Coverage specifically address risks associated with hurricanes in Puerto Rico?
    *   **Answer:** No. The excerpt doesn’t mention specific risks like hurricanes or earthquakes.

7.  **Question:** Does the policy cover damage caused by earthquakes in Puerto Rico?
    *   **Answer:** No. The excerpt doesn’t mention earthquakes.

8.  **Question:** Does this policy cover damage to property due to flooding in Puerto Rico?
    *   **Answer:** No. The excerpt doesn’t mention flooding.

9.  **Question:** Does this policy cover damage to property due to seismic activity in Puerto Rico?
    *   **Answer:** No. The excerpt doesn’t mention earthquakes.

## Policy Terms & Conditions

10. **Question:** Does the policy allow you to claim for loss or damage on an actual cash value basis if you notify the insurer within 180 days of the loss?
    *   **Answer:** Yes. The excerpt states you *may* make a claim on an actual cash value basis if you notify us of your intent within 180 days after the loss or damage.

11. **Question:** Does the policy cover damage to “works of art, antiques or rare articles”?
    *   **Answer:** No. The excerpt specifically excludes this type of property.

12. **Question:** Does the policy cover damage to “contents of a residence”?
    *   **Answer:** No. The excerpt specifically excludes this type of property.

13. **Question:** Does the policy cover “Pollutants”?
    *   **Answer:** No. The excerpt defines “Pollutants” and explicitly excludes coverage for them.

14. **Question:** Does the policy cover damage to property of others?
    *   **Answer:** No. The excerpt specifically excludes this type of property.

15. **Question:** Does the policy cover damage to “Manuscripts”?
    *   **Answer:** No. The excerpt specifically excludes this type of property.

---

**Note:** This is based solely on the provided excerpt. A full insurance policy would contain significantly more detail.