# Insurance Form Analysis

## Coverages

### Coverage 1
- **Type**: COVERAGE FORM
Various provisions in this policy restrict coverage
- **Context**: --- Page 1 ---
COMMERCIAL PROPERTY
CP 00 10 10 12
BUILDING AND PERSONAL PROPERTY
COVERAGE FORM
Various provisions in this policy restrict coverage. Read the entire policy carefully to determine rights, duties and
what is and is not covered.
Throu

### Coverage 2
- **Type**: consists of the following property located in
We will pay for direct physical loss of or damage to
or on the building or structure described in
Covered Property at the premises described in the
the Declarations or in the open (or in a
Declarations caused by or resulting from any
vehicle) within 100 feet of the building or
Covered Cause of Loss
- **Context**: quotation marks have special meaning. Refer to Section H. Definitions.
A. Coverage b. Your Business Personal Property
consists of the following property located in
We will pay for direct physical loss of or damage to
or on the building or structure described in
Covered Property at the premises described in the
the Declarations or in the open (or in a
Declarations caused by or resulting from any
vehicle) within 100 feet of the building or
Covered Cause of Loss.
structure or within 100 feet of the premises
1. Covered Property described in the Declarations, wh

### Coverage 3
- **Type**: owned by
described in the Declarations, including: you and used in your business;
(1) Completed additions; (5) Labor, materials or services furnished or
arranged by you on personal property of
(2) Fixtures, including outdoor fixtures;
others;
(3) Permanently installed:
(6) Your use interest as tenant in
(a) Machinery; and improvements and betterments
- **Context**: or that type of property. (3) "Stock";
a. Building, meaning the building or structure (4) All other personal property owned by
described in the Declarations, including: you and used in your business;
(1) Completed additions; (5) Labor, materials or services furnished or
arranged by you on personal property of
(2) Fixtures, including outdoor fixtures;
others;
(3) Permanently installed:
(6) Your use interest as tenant in
(a) Machinery; and improvements and betterments.
(b) Equipment; Improvements and betterments are
fixtures, alterations, installations or
(4) Person

### Coverage 4
- **Type**: owned by you that is
additions:
used to maintain or service the building
or structure or its premises, including: (a) Made a part of the building or
structure you occupy but do not own;
(a) Fire-extinguishing equipment;
and
(b) Outdoor furniture;
(b) You acquired or made at your
(c) Floor coverings; and expense but cannot legally remove;
(d) Appliances used for refrigerating, (7) Leased personal property for which you
ventilating, cooking, dishwashing or have a contractual responsibility to
laundering; insure, unless otherwise provided for
(5) If not covered by other insurance: under Personal Property Of Others
- **Context**: rments.
(b) Equipment; Improvements and betterments are
fixtures, alterations, installations or
(4) Personal property owned by you that is
additions:
used to maintain or service the building
or structure or its premises, including: (a) Made a part of the building or
structure you occupy but do not own;
(a) Fire-extinguishing equipment;
and
(b) Outdoor furniture;
(b) You acquired or made at your
(c) Floor coverings; and expense but cannot legally remove;
(d) Appliances used for refrigerating, (7) Leased personal property for which you
ventilating, cooking, dishwashing or have a contractual responsibility to
laundering; insure, unless otherwise provided for
(5) If not covered by other insurance: under Personal Property Of Others.
(a) Additions under construction, c. Personal Property Of Others that is:
alterations and repairs

### Coverage 5
- **Type**: Of Others that is:
alterations and repairs to the building (1) In your care, custody or control; and
or structure;
(2) Located in or on the building or structure
(b) Materials, equipment, supplies and described in the Declarations or in the
temporary structures, on or within open (or in a vehicle) within 100 feet of
100 feet of the described premises, the building or structure or within 100
used for making additions, feet of the premises described in the
alterations or repairs to the building Declarations, whichever distance is
or structure
- **Context**: covered by other insurance: under Personal Property Of Others.
(a) Additions under construction, c. Personal Property Of Others that is:
alterations and repairs to the building (1) In your care, custody or control; and
or structure;
(2) Located in or on the building or structure
(b) Materials, equipment, supplies and described in the Declarations or in the
temporary structures, on or within open (or in a vehicle) within 100 feet of
100 feet of the described premises, the building or structure or within 100
used for making additions, feet of the premises described in the
alterations or repairs to the building Declarations, whichever distance is
or structure. greater.
CP 00 10 10 12 © Insurance Services Office, Inc.,2011 Page 1of 16

--- Page 2 ---
However

### Coverage 6
- **Type**: of others will the Additional Coverage, Electronic Data
- **Context**: ge 2 ---
However, our payment for loss of or n. Electronic data, except as provided under
damage to personal property of others will the Additional Coverage, Electronic Data.
only be for the account of the owner of the Electronic data means information, facts or
property.

### Coverage 7
- **Type**: while airborne or
for limited coverage for valuable papers and
waterborne;
records other than those which exist as
j
- **Context**: vegetated roof); Coverage Extension for Valuable Papers
And Records (Other Than Electronic Data)
i. Personal property while airborne or
for limited coverage for valuable papers and
waterborne;
records other than those which exist as
j. Bulkheads, pilings, piers, wharves or docks; electronic data;
k. Property that is covered under an

### Coverage 8
- **Type**: to rebuild at another premises, the apply to this Additional Coverage,
most we will pay for the Increased Electronic Data, subject to the following:
Cost of Construction, subject to the
(a) If the Causes Of Loss – Special
provisions of e
- **Context**: ed (3) The Covered Causes of Loss applicable
at the same premises, or if you elect to Your Business Personal Property
to rebuild at another premises, the apply to this Additional Coverage,
most we will pay for the Increased Electronic Data, subject to the following:
Cost of Construction, subject to the
(a) If the Causes Of Loss – Special
provisions of e.(6) of this Additional
Form applies, coverage under this
Coverage, is the increased cost of
Additio

### Coverage 9
- **Type**: Additional Coverage, Electronic Data, is
(a) If this policy covers Your Business
$2,500 (unless a higher limit is shown in
Personal Property, you may extend
the Declarations) for all loss or damage
that insurance to apply to:
sustained in any one policy year,
(i) Business personal property,
regardless of the number of occurrences
including such property that you
of loss or damage or the number of
newly acquire, at any location
premises, locations or computer
you acquire other than at fairs,
systems involved
- **Context**: ice, Inc.,2011 CP 00 10 10 12

--- Page 7 ---
(4) The most we will pay under this (2) Your Business Personal Property
Additional Coverage, Electronic Data, is
(a) If this policy covers Your Business
$2,500 (unless a higher limit is shown in
Personal Property, you may extend
the Declarations) for all loss or damage
that insurance to apply to:
sustained in any one policy year,
(i) Business personal property,
regardless of the number of occurrences
including such property that you
of loss or damage or the number of
newly acquire, at any location
premises, locations or computer
you acquire other than at fairs,
systems involved. If loss payment on the
trade shows or exhibitions; or
first occurrence does not exhaust this
amoun

### Coverage 10
- **Type**: ,
subsequent loss or damage sustained in including such property that you
but not after that policy year
- **Context**: ; or
first occurrence does not exhaust this
amount, then the balance is available for (ii) Business personal property,
subsequent loss or damage sustained in including such property that you
but not after that policy year. With newly acquire, located at your
respect to an occurrence which begins newly constructed or acq

### Coverage 11
- **Type**: of others that
Except as otherwise provided, the following
is temporarily in your possession
Extensions apply to property located in or on
in the course of installing or
the building described in the Declarations or in
performing work on such
the open (or in a vehicle) within 100 feet of the
property; or
described premises
- **Context**: $100,000 at each building.
began.
(b) This Extension does not apply to:
5. Coverage Extensions
(i) Personal property of others that
Except as otherwise provided, the following
is temporarily in your possession
Extensions apply to property located in or on
in the course of installing or
the building described in the Declarations or in
performing work on such
the open (or in a vehicle) within 100 feet of the
property; or
described premises.
(ii) Personal property of others that
If a Coinsurance percentage of 80% or more,
is temporarily i

### Coverage 12
- **Type**: of others that
If a Coinsurance percentage of 80% or more,
is temporarily in your possession
or a Value Reporting period symbol, is shown
in the course of your
in the Declarations, you may extend the
manufacturing or wholesaling
insurance provided by this Coverage Part as
activities
- **Context**: ork on such
the open (or in a vehicle) within 100 feet of the
property; or
described premises.
(ii) Personal property of others that
If a Coinsurance percentage of 80% or more,
is temporarily in your possession
or a Value Reporting period symbol, is shown
in the course of your
in the Declarations, you may extend the
manufacturing or wholesaling
insurance provided by this Coverage Part as
activities.
follows:
(3) Period Of Coverage
a. Newly Acquired Or Constructed
Property With respect to insuranc

### Coverage 13
- **Type**: to by this Coverage Form to apply to your
apply to: Covered Property while it is away from
the described premises, if it is:
(1) Personal effects owned by you, your
officers, your partners or members, your (a) Temporarily at a location you do not
managers or your employees
- **Context**: ou may extend the insurance that applies (1) You may extend the insurance provided
to Your Business Personal Property to by this Coverage Form to apply to your
apply to: Covered Property while it is away from
the described premises, if it is:
(1) Personal effects owned by you, your
officers, your partners or members, your (a) Temporarily at a location you do not
managers or your employees. This own, lease or operate;
Extension does not apply to loss or
(b) In storage at a location you l

### Coverage 14
- **Type**: of others in your care, after the beginning of the current
custody or control
- **Context**: oss or
(b) In storage at a location you lease,
damage by theft.
provided the lease was executed
(2) Personal property of others in your care, after the beginning of the current
custody or control. policy term; or
The most we will pay for loss or damage (c) At any fair, trade show or exhibition.

### Coverage 15
- **Type**: of others
(a) In or on a vehicle; or
will only be for the account of the owner of
the property
- **Context**: This Extension does not apply to
described premises. Our payment for loss
property:
of or damage to personal property of others
(a) In or on a vehicle; or
will only be for the account of the owner of
the property. (b) In the care, custody or control of
your salespersons, unless the
c. Valuable Papers And Record

### Coverage 16
- **Type**: to apply to the cost to replace (3) The most we will pay for loss or damage
under this Extension is $10,000
- **Context**: at a fair, trade show or
(1) You may extend the insurance that
exhibition.
applies to Your Business Personal
Property to apply to the cost to replace (3) The most we will pay for loss or damage
under this Extension is $10,000.
or restore the lost information on
valuable papers and records for which e. Outdoor Property
dupli

### Coverage 17
- **Type**: and, therefore, coverage of
such costs is not additional insurance
- **Context**: costs of blank material and labor are
subject to the applicable Limit of
Insurance on Your Business Personal
Property and, therefore, coverage of
such costs is not additional insurance.
Page 8 of 16 © Insurance Services Office, Inc.,2011 CP 00 10 10 12

--- Page 9 ---
Subject to all

### Coverage 18
- **Type**: has been placed in
(1) You may extend the insurance that the storage unit;
applies to Your Business Personal
(b) Does not apply if the storage unit
Property to apply to loss or damage to
itself has been in use at the
trailers that you do not own, provided
described premises for more than 90
that:
consecutive days, even if the
(a) The trailer is used in your business; business personal property has been
stored there for 90 or fewer days as
(b) The trailer is in your care, custody or
of the time of loss or damage
- **Context**: tension:
described premises.
(a) Will end 90 days after the business
f. Non-owned Detached Trailers
personal property has been placed in
(1) You may extend the insurance that the storage unit;
applies to Your Business Personal
(b) Does not apply if the storage unit
Property to apply to loss or damage to
itself has been in use at the
trailers that you do not own, provided
described premises for more than 90
that:
consecutive days, even if the
(a) The trailer is used in your business; business personal property has been
stored there for 90 or fewer days as
(b) The trailer is in your care, custody or
of the time of loss or damage.
control at the premises described in
the Declarations; and (4) Under this Extension, the most we w

### Coverage 19
- **Type**: is $10,000
to pay for loss or damage to the
(unless a higher limit is indicated in the
trailer
- **Context**: will
pay for the total of all loss or damage to
(c) You have a contractual responsibility
business personal property is $10,000
to pay for loss or damage to the
(unless a higher limit is indicated in the
trailer.
Declarations for such Extension)
(2) We will not pay for any loss or damage regardless of the numb

### Coverage 20
- **Type**: Temporarily See applicable Causes Of Loss form as shown in
In Portable Storage Units the Declarations
- **Context**: or not) from any other insurance
covering such property. B. Exclusions And Limitations
g. Business Personal Property Temporarily See applicable Causes Of Loss form as shown in
In Portable Storage Units the Declarations.
(1) You may extend the insurance that C. Limits Of Insurance
applies to Your Business Personal
The

## Exclusions

- to the extent that such
endorsed to add a Covered Cause of

## Definitions

**Your Business Personal Property
consists of the following property located in
We will pay for direct physical loss of or damage to
or on the building or structure described in
Covered Property at the prem**: es described in the
the Declarations or in the open (or in a
Declarations caused by or resulting from any
vehicle) within 100 feet of the building or
Covered Cause of Loss.

**Coverage distance**: greater:
Part, means the type of property described in
(1) Furniture and fixtures;
this section, A.

**Limit Of Insurance**: shown
in the Declarations for that type of property.

**Personal property owned by you that**: additions:
used to maintain or service the building
or structure or its premises, including: (a) Made a part of the building or
structure you occupy but do not own;
(a) Fire-extinguishing equipment;
and
(b) Outdoor furniture;
(b) You acquired or made at your
(c) Floor coverings; and expense but cannot legally remove;
(d) Appliances used for refrigerating, (7) Leased personal property for which you
ventilating, cooking, dishwashing or have a contractual responsibility to
laundering; insure, unless otherwise provided for
(5) If not covered by other insurance: under Personal Property Of Others.

**Personal Property Of Others that**: :
alterations and repairs to the building (1) In your care, custody or control; and
or structure;
(2) Located in or on the building or structure
(b) Materials, equipment, supplies and described in the Declarations or in the
temporary structures, on or within open (or in a vehicle) within 100 feet of
100 feet of the described premises, the building or structure or within 100
used for making additions, feet of the premises described in the
alterations or repairs to the building Declarations, whichever distance is
or structure.

**Electronic data**: information, facts or
property.

**Th**: e.

**Property that**: covered under another p.

**Retaining walls that are not part of a Th**: paragraph does not apply to:
building;
(a) Vehicles or self-propelled machines
m.

**Covered Property
under th**: Coverage Form;
(c) Rowboats or canoes out of water at
the described premises; or (e) Remove deposits of mud or earth
from the grounds of the described
(d) Trailers, but only to the extent
premises;
provided for in the Coverage
Extension for Non-owned Detached (f) Extract "pollutants" from land or
Trailers; or water; or
q.

**See applicable Causes Of Loss form as shown**: limited to 25% of the sum of the
in the Declarations.

**Debr**: Removal damage to the Covered Property that
has sustained loss or damage.

**Covered Property has
we will pay your expense to remove
sustained direct physical loss or
debr**: of Covered Property and other
damage, the most we will pay for
debris that is on the described premises,
removal of debris of other property (if
when such debris is caused by or
such removal is covered under this
results from a Covered Cause of Loss
Additional Coverage) is $5,000 at
that occurs during the policy period.

**Debr**: Removal does not apply to costs
Property, if one or both of the following
to:
circumstances apply:
(a) Remove debris of property of yours
(a) The total of the actual debris removal
that is not insured under this policy,
expense plus the amount we pay for
or property in your possession that is
direct physical loss or damage
not Covered Property;
exceeds the Limit of Insurance on
(b) Remove debris of property owned by the Covered Property that has
or leased to the landlord of the sustained loss or damage.

**The actual debris removal expense
prem**: es are located, unless you
exceeds 25% of the sum of the
have a contractual responsibility to
deductible plus the amount that we
insure such property and it is insured
pay for direct physical loss or
under this policy;
damage to the Covered Property that
(c) Remove any property that is has sustained loss or damage.

**The additional amount payable for debris removal
our total payment for direct physical loss expense is provided in accordance with the terms of
or damage and debr**: removal expense Paragraph (4), because the debris removal expense
may reach but will never exceed the ($40,000) exceeds 25% of the loss payable plus the
Limit of Insurance on the Covered deductible ($40,000 is 50% of $80,000), and because
Property that has sustained loss or the sum of the loss payable and debris removal
damage, plus $25,000.

**Examples
additional amount of covered debris removal expense
The following examples assume that**: $25,000, the maximum payable under Paragraph
there is no Coinsurance penalty.

**If it**: necessary to move Covered Property
Amount of Loss: $ 50,000
from the described premises to preserve it
Amount of Loss Payable: $ 49,500 from loss or damage by a Covered Cause
($50,000 – $500) of Loss, we will pay for any direct physical
loss or damage to that property:
Debris Removal Expense: $ 10,000
(1) While it is being moved or while
Debris Removal Expense Payable: $ 10,000
temporarily stored at another location;
($10,000 is 20% of $50,000.

**The debris removal expense**: less than 25% of the (2) Only if the loss or damage occurs within
sum of the loss payable plus the deductible.

**When the fire department is called to save
removal expense**: payable in accordance with the or protect Covered Property from a
terms of Paragraph (3).

**Such limit**: the most we will pay
Amount of Deductible: $ 500
regardless of the number of responding fire
Amount of Loss: $ 80,000 departments or fire units, and regardless of
Amount of Loss Payable: $ 79,500 the number or type of services performed.

**This Additional Coverage applies to your
Debr**: Removal Expense: $ 40,000 liability for fire department service charges:
Debris Removal Expense Payable (1) Assumed by contract or agreement prior
to loss; or
Basic Amount: $ 10,500
(2) Required by local ordinance.

**No Deductible applies to this Additional
The basic amount payable for debr**: removal
Coverage.

**Under th**: Additional Coverage, we will
not pay for:
We will pay your expense to extract
"pollutants" from land or water at the (a) The enforcement of or compliance
described premises if the discharge, with any ordinance or law which
dispersal, seepage, migration, release or requires demolition, repair,
escape of the "pollutants" is caused by or replacement, reconstruction,
results from a Covered Cause of Loss that remodeling or remediation of
occurs during the policy period.

**Th**: Additional Coverage does not apply to (b) Any costs associated with the
costs to test for, monitor or assess the enforcement of or compliance with
existence, concentration or effects of an ordinance or law which requires
"pollutants".

**The most we will pay under th**: Additional
or dry rot or bacteria.

**Coverage for each described premises**: $10,000 for the sum of all covered (6) The most we will pay under this
expenses arising out of Covered Causes of Additional Coverage, for each described
Loss occurring during each separate 12- building insured under this Coverage
month period of this policy.

**Increased Cost Of Construction
whichever**: less.

**This Additional Coverage applies only to**: covered under a blanket Limit of
buildings to which the Replacement Insurance which applies to more than
Cost Optional Coverage applies.

**In the event of damage by a Covered most we will pay under this Additional
Cause of Loss to a building that**: Coverage, for that damaged building, is
Covered Property, we will pay the the lesser of $10,000 or 5% times the
increased costs incurred to comply with value of the damaged building as of the
the minimum standards of an ordinance time of loss times the applicable
or law in the course of repair, rebuilding Coinsurance percentage.

**The amount payable under th**: property, subject to the limitations stated Additional Coverage is additional
in e.

**With respect to th**: Additional
(3) The ordinance or law referred to in e.

**Additional Coverage**: an
(a) We will not pay for the Increased
ordinance or law that regulates the
Cost of Construction:
construction or repair of buildings or
establishes zoning or land use (i) Until the property is actually
requirements at the described premises repaired or replaced at the same
and is in force at the time of loss.

**Under th**: Additional Coverage, we will (ii) Unless the repair or replacement
not pay any costs due to an ordinance is made as soon as reasonably
or law that: possible after the loss or
damage, not to exceed two
(a) You were required to comply with
years.

**We may extend th**: period
before the loss, even when the
in writing during the two years.

**If the building**: repaired or replaced (3) The Covered Causes of Loss applicable
at the same premises, or if you elect to Your Business Personal Property
to rebuild at another premises, the apply to this Additional Coverage,
most we will pay for the Increased Electronic Data, subject to the following:
Cost of Construction, subject to the
(a) If the Causes Of Loss – Special
provisions of e.

**Electronic
construction at the same prem**: es.

**Broad Form
prov**: ions of e.

**Electronic
construction at the new prem**: es.

**This Additional Coverage**: not subject in that form.

**If the Causes Of Loss form**: Exclusion to the extent that such
endorsed to add a Covered Cause of
Exclusion would conflict with the
Loss, the additional Covered Cause
provisions of this Additional Coverage.

**The costs addressed in the Loss coverage provided under th**: Payment and Valuation Conditions and Additional Coverage, Electronic
the Replacement Cost Optional Data.

**The amount payable under th**: electronic data) or a network to
Additional Coverage, as stated in e.

**But there**: no coverage
for loss or damage caused by or
(1) Under this Additional Coverage,
resulting from manipulation of a
electronic data has the meaning
computer system (including
described under Property Not Covered,
electronic data) by any employee,
Electronic Data.

**Th**: Additional
including a temporary or leased
Coverage does not apply to your "stock"
employee, or by an entity retained by
of prepackaged software, or to
you or for you to inspect, design,
electronic data which is integrated in
install, modify, maintain, repair or
and operates or controls the building's
replace that system.

**Subject to the provisions of th**: Additional Coverage, we will pay for the
cost to replace or restore electronic data
which has been destroyed or corrupted
by a Covered Cause of Loss.

**To the
extent that electronic data**: not
replaced or restored, the loss will be
valued at the cost of replacement of the
media on which the electronic data was
stored, with blank media of substantially
identical type.

**The most we will pay under th**: (2) Your Business Personal Property
Additional Coverage, Electronic Data, is
(a) If this policy covers Your Business
$2,500 (unless a higher limit is shown in
Personal Property, you may extend
the Declarations) for all loss or damage
that insurance to apply to:
sustained in any one policy year,
(i) Business personal property,
regardless of the number of occurrences
including such property that you
of loss or damage or the number of
newly acquire, at any location
premises, locations or computer
you acquire other than at fairs,
systems involved.

**The most we will pay for loss or
damage is deemed to be sustained in
damage under this Extension**: the policy year in which the occurrence
$100,000 at each building.

**Th**: Extension does not apply to:
5.

**Personal property of others that
Except as otherw**: e provided, the following
is temporarily in your possession
Extensions apply to property located in or on
in the course of installing or
the building described in the Declarations or in
performing work on such
the open (or in a vehicle) within 100 feet of the
property; or
described premises.

**Newly Acquired Or Constructed
Property With respect to insurance provided
under th**: Coverage Extension for
(1) Buildings
Newly Acquired Or Constructed
If this policy covers Building, you may Property, coverage will end when any of
extend that insurance to apply to: the following first occurs:
(a) Your new buildings while being built (a) This policy expires;
on the described premises; and
(b) 30 days expire after you acquire the
(b) Buildings you acquire at locations, property or begin construction of that
other than the described premises, part of the building that would qualify
intended for: as covered property; or
(i) Similar use as the building (c) You report values to us.

**The most we will pay for loss or damage
construction of that part of the building
under this Extension**: $250,000 at
that would qualify as covered property.

**You may extend the insurance provided
to Your Business Personal Property to by th**: Coverage Form to apply to your
apply to: Covered Property while it is away from
the described premises, if it is:
(1) Personal effects owned by you, your
officers, your partners or members, your (a) Temporarily at a location you do not
managers or your employees.

**Th**: own, lease or operate;
Extension does not apply to loss or
(b) In storage at a location you lease,
damage by theft.

**Extension**: $2,500 at each
(2) This Extension does not apply to
described premises.

**Other
property**: in such care, custody or
Than Electronic Data)
control at a fair, trade show or
(1) You may extend the insurance that
exhibition.

**The most we will pay for loss or damage
under this Extension**: $10,000.

**Outdoor Property
duplicates do not ex**: t.

**But this
You may extend the insurance provided by
Extension does not apply to valuable
this Coverage Form to apply to your
papers and records which ex**: t as
outdoor fences, radio and television
electronic data.

**Under th**: Extension, the most we will (5) Aircraft.

**The most we will pay for loss or damage
information**: $2,500 at each described
under this Extension is $1,000, but not
premises, unless a higher limit is shown
more than $250 for any one tree, shrub or
in the Declarations.

**Such amount**: plant.

**Coverage Loss form or endorsement contains a
Extension includes the expense of limitation or exclusion concerning loss or
removing from the described prem**: es the damage from sand, dust, sleet, snow,
debris of trees, shrubs and plants which are ice or rain to property in a structure,
the property of others, except in the such limitation or exclusion also applies
situation in which you are a tenant and such to property in a portable storage unit.

**Coverage under th**: Extension:
described premises.

**The trailer**: used in your business; business personal property has been
stored there for 90 or fewer days as
(b) The trailer is in your care, custody or
of the time of loss or damage.

**Under th**: Extension, the most we will
pay for the total of all loss or damage to
(c) You have a contractual responsibility
business personal property is $10,000
to pay for loss or damage to the
(unless a higher limit is indicated in the
trailer.

**Such limit**: part of, not in addition
(a) While the trailer is attached to any to, the applicable Limit of Insurance on
motor vehicle or motorized Your Business Personal Property.

**Extension will not increase the
conveyance**: in motion; applicable Limit of Insurance on Your
Business Personal Property.

**This Extension does not apply to loss or
becomes accidentally unhitched from damage otherwise covered under th**: a motor vehicle or motorized Coverage Form or any endorsement to
conveyance.

**Extension**: $5,000, unless a
higher limit is shown in the Declarations.

**Each of these Extensions is additional
insurance unless otherw**: e indicated.

**This insurance**: excess over the
Additional Condition, Coinsurance, does not
amount due (whether you can collect on
apply to these Extensions.

**Limits Of Insurance
applies to Your Business Personal
The most we will pay for loss or damage in any
Property to apply to such property while
one occurrence**: the applicable Limit Of
temporarily stored in a portable storage
Insurance shown in the Declarations.

**Th**: example, too, assumes there is no Coinsurance
1.

**If the adjusted amount of loss**: less than or equal Total amount of loss payable: $ 140,000
to the Deductible, we will not pay for that loss.

**Appra**: al
combined in determining application of the
Deductible.

**But the Deductible will be applied only If we and you d**: agree on the value of the
once per occurrence.

**In th**: event, each party will select a
(This example assumes there is no Coinsurance competent and impartial appraiser.

**The appra**: ers will state separately the value
of the property and amount of loss.

**A dec**: ion agreed to by any two
Loss to Building 2: $ 90,000 will be binding.

**Pay its chosen appra**: er; and
than the sum ($60,250) of the Limit of Insurance
b.

**Bear the other expenses of the appra**: al
applicable to Building 1 plus the Deductible.

**The Deductible will be subtracted from the amount of If there is an appra**: al, we will still retain our
loss in calculating the loss payable for Building 1: right to deny the claim.

**The Deductible applies once per occurrence and
therefore**: not subtracted in determining the amount (1) Notify the police if a law may have been
of loss payable for Building 2.

