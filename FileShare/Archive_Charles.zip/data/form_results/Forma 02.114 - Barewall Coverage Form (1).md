# Insurance Form Analysis

## Coverages

### Coverage 1
- **Type**: owned by, used by
(4) Personal property owned by you that is or in the care, custody or control of a unit own-
used to maintain or service the building er
- **Context**: floors and bare ceilings ba-
sis. Furthermore, Common Elements do not
(3) Outdoor fixtures;
include personal property owned by, used by
(4) Personal property owned by you that is or in the care, custody or control of a unit own-
used to maintain or service the building er.
or structure or its premises, including:
(a) Fire extinguishing equipment;
b. Your Business Person

### Coverage 2
- **Type**: located
(b) Outdoor furniture;
in or on the building described in the Decla-
(c) Floor coverings; and rations or in the open (or in a vehicle) within
100 feet of the described premises, consist-
(d) Appliances used for refrigerating,
ing of the following:
ventilating, cooking, dishwashing or
laundering that are not contained (1) Personal property owned by you or
within individual units; owned indivisibly by all unit-owners;
(5) If not covered by other insurance: (2) Your interest in the labor, materials or
services furnished or arranged by you
(a) Additions under construction, altera-
on personal property of others;
tions and repairs to the building or
structure; (3) Leased personal property for which you
have a contractual responsibility to in-
sure, unless otherwise provided for un-
der Personal Property of Others
- **Context**: ing er.
or structure or its premises, including:
(a) Fire extinguishing equipment;
b. Your Business Personal Property located
(b) Outdoor furniture;
in or on the building described in the Decla-
(c) Floor coverings; and rations or in the open (or in a vehicle) within
100 feet of the described premises, consist-
(d) Appliances used for refrigerating,
ing of the following:
ventilating, cooking, dishwashing or
laundering that are not contained (1) Personal property owned by you or
within individual units; owned indivisibly by all unit-owners;
(5) If not covered by other insurance: (2) Your interest in the labor, materials or
services furnished or arranged by you
(a) Additions under construction, altera-
on personal property of others;
tions and repairs to the building or
structure; (3) Leased personal property for which you
have a contractual responsibility to in-
sure, unless otherwise provided for un-
der Personal Property of Others.
But Your Business Personal Property does not
include personal property owned only by a unit-
owner

### Coverage 3
- **Type**: does not
include personal property owned only by a unit-
owner
- **Context**: y to in-
sure, unless otherwise provided for un-
der Personal Property of Others.
But Your Business Personal Property does not
include personal property owned only by a unit-
owner.
CBP 02.114 Ed.2/10 Page 1 of 10 


[TABLE DATA]

(6) All Other General, Procomunal and Limited

C

### Coverage 4
- **Type**: of Others that is: m
- **Context**: mon Elements do not include items of

real property owned only by a unit- owner.

--- Page 2 ---
c. Personal Property of Others that is: m. Underground pipes, flues or drains;
(1) In your care, custody or control; and n. The cost to resea

### Coverage 5
- **Type**: of others will only be for the
account of the owner of the property
- **Context**: d machines (includ-
However, our payment for loss of or damage to
ing aircraft or watercraft) that:
personal property of others will only be for the
account of the owner of the property. (1) Are licensed for use on public roads; or
2. Property Not Covered (2) Are operated principally

### Coverage 6
- **Type**: while airborne or water- in the Declarations
- **Context**: of Loss
is located), water, growing crops or lawns; See applicable Causes of Loss Form as shown
i. Personal property while airborne or water- in the Declarations.
borne;
4. Additional Coverages
j. Pilings, piers, wharves or docks; a. Debris Removal
k. Property

### Coverage 7
- **Type**: to ap-
or exhibitions
- **Context**: You may extend the insurance that applies
location you acquire other than at fairs
to Your Business Personal Property to ap-
or exhibitions.
ply to your costs to research, replace or re-
The most we will pay for loss or damage store the lo

### Coverage 8
- **Type**: to ap-
You may extend the insurance provided by
ply to:
this Coverage Form to apply to your out-
(1) Personal effects owned by you, your door fences, radio and television antennas,
officers, your partners or your employ- signs (other than signs attached to build-
ees
- **Context**: Extension is $5,000.
You may extend the insurance that applies e. Outdoor Property
to Your Business Personal Property to ap-
You may extend the insurance provided by
ply to:
this Coverage Form to apply to your out-
(1) Personal effects owned by you, your door fences, radio and television antennas,
officers, your partners or your employ- signs (other than signs attached to build-
ees. This extension does not apply to ings), trees, shrubs and plants, including
loss or damage by thef

### Coverage 9
- **Type**: of others in your care,
loss if they are Covered Causes of Loss:
custody or control
- **Context**: by theft. debris removal expense, caused by or re-
sulting from any of the following causes of
(2) Personal property of others in your care,
loss if they are Covered Causes of Loss:
custody or control.
(1) Fire;
The most we will pay for loss or damage
under this Extension is $2,500 at each de- (2) L

### Coverage 10
- **Type**: of others
(4) Riot or Civil Commotion; or
will only be for the account of the owner of
the property
- **Context**: 00 at each de- (2) Lightning;
scribed premises. Our payment for loss of
(3) Explosion;
or damage to personal property of others
(4) Riot or Civil Commotion; or
will only be for the account of the owner of
the property. (5) Aircraft.
The most we will pay for loss or damage
under this Extension is $1,000, but not
more

### Coverage 11
- **Type**: to conduct
Declarations, the following condition applies
- **Context**: ding is vacant when it does not contain If a Coinsurance percentage is shown in the
enough business personal property to conduct
Declarations, the following condition applies.
customary operations.
a. We will not pay the full amount of any loss if
Buildings under constructi

### Coverage 12
- **Type**: at
for it is $100,000
Location No
- **Context**: g. at Location No. 1 $ 75,000
for it is 80% Bldg. at Location No. 2 $100,000
The Limit of Insurance
Personal Property at
for it is $100,000
Location No. 2 $ 75,000
The Deductible is $250
$250,000
The amount of loss is $40,000
The Coinsurance
Step (1):

### Coverage 13
- **Type**: at
Example No
- **Context**: e will pay no more than $19,750. The re-
at Location No. 2 $ 30,000
maining $20,250 is not covered.
Personal Property at
Example No. 2 (Adequate Insurance):
Location No. 2. $ 20,000
When: The value of the property is $250,000 $ 50,

## Exclusions

- Property Conditions.
See applicable Causes of Loss Form as shown in 1. Abandonment
the Declarations.
There can be no abandonment of any property
C. LIMITS OF INSURANCE to us.
The most we will pay for loss or damage in any 2. Appraisal
one occurrence is the applicable Limit of Insur
- If we and you disagree on the value of the
ance shown in the Declarations.
property or the amount of loss, either may
The most we will pay for loss or damage to out
- make written demand for an appraisal of the
door signs attached to buildings is $1,000 per sign loss. In this event, each party will select a
in any one occurrence. competent and impartial appraiser. The two
appraisers will select an umpire. If they cannot
The limits applicable to the Coverage Extensions
agree, either may request that selection be
and the Fire Department Service Charge and Pol
- made by a judge of a court having jurisdiction.
lutant Clean Up and Removal Additional Coverag
- The appraisers will state separately the value
es are in addition to the Limits of Insurance.
of the property and amount of loss. If they fail
Payments under the following Additional Coverag
- to agree, they will submit their differences to
es will not increase the applicable Limit of Insur
- the umpire. A decision agreed to by any two
ance:
will be binding. Each party will:
1. Preservation of Property; or a. Pay its chosen appraiser; and
2. Debris Removal; but if:
b. Bear the other expenses of the appraisal
a. The sum of direct physical loss or damage and umpire equally.
and debris removal expense exceeds the
If there is an appraisal, we will still retain our
Limit of Insurance; or
right to deny the claim.
b. The debris removal expense exceeds the 3. Duties in the Event of Loss or Damage
amount payable under the 25% limitation in
You must see that the following are done in the
the Debris Removal Additional Coverage;
event of loss or damage to Covered Property:
we will pay up to an additional $5,000 for each
a. Notify the police if a law may have been
location in any one occurrence under the De
- broken.
bris Removal Additional Coverage.
b. Give us prompt notice of the loss or dam
- D. DEDUCTIBLE
age. Include a description of the property
We will not pay for loss or damage in any one oc
- involved.
currence until the amount of loss or damage ex
- c. As soon as possible, give us a description
ceeds the Deductible shown in the Declarations.
of how, when and where the loss or dam
- We will then pay the amount of loss or damage in
age occurred.
excess of the Deductible, up to the applicable Lim
- it of Insurance.
CBP 02.114 Ed.2/10 Page 5 of 10 
- d. Take all reasonable steps to protect the b. We will give notice of our intentions within
Covered Property from further damage by a 30 days after we receive the sworn state
- Covered Cause of Loss. If feasible, set the ment of loss.
damaged property aside and in the best
c. We will not pay you more than your finan
- possible order for examination. Also keep a
cial interest in the Covered Property.
record of your expenses for emergency and
d. We may adjust losses with the owners of
temporary repairs, for consideration in the
settlement of the claim. This will not in
- lost or damaged property if other than you.
crease the Limit of Insurance. If we pay the owners, such payments will
satisfy your claims against us for the own
- e. At our request, give us complete inventories
ers' property. We will not pay the owners
of the damaged and undamaged property.
more than their financial interest in the
Include quantities, costs, values and
Covered Property.
amount of loss claimed.
e. We may elect to defend you against suits
f. Permit us to inspect the property and rec
- arising from claims of owners of property.
ords proving the loss or damage.
We will do this at our expense.
Also permit us to take samples of damaged
f. We will pay for covered loss or damage to
property for inspection, testing and analy
- Covered Property within 30 days after we
sis.
receive the sworn statement of loss, if:
g. If requested, permit us to question you
(1) You have complied with all of the terms
under oath at such times as may be rea
- of this Coverage Part; and
sonably required about any matter relating
(2) (a) We have reached agreement with
to this insurance or your claim, including
you on the amount of loss; or
your books and records. In such event, your
answers must be signed. (b) An appraisal award has been made.
h. Send us a signed, sworn statement of loss If you name an insurance trustee, we will
containing the information we request to in
- adjust losses with you, but we will pay the
vestigate the claim. You must do this within insurance trustee. If we pay the trustee, the
60 days after our request. We will supply payments will satisfy your claims against
you with the necessary forms. us.
i. Cooperate with us in the investigation or 5. Recovered Property
settlement of the claim.
If either you or we recover any property after
4. Loss Payment loss settlement, that party must give the other
prompt notice. At your option, the property will
a. In the event of loss or damage covered by
this Coverage Form, at our option, we will be returned to you. You must then return to us
either: the amount we paid to you for the property. We
will pay recovery expenses and the expenses
(1) Pay the value of lost or damaged prop
- to repair the recovered property, subject to the
erty;
Limit of Insurance.
(2) Pay the cost of repairing or replacing the
6. Unit
- Owner's Insurance
lost or damaged property;
A unit
- owner may have other insurance cover
- (3) Take all or any part of the property at an
ing the same property as this insurance. This
agreed or appraised value; or
insurance is intended to be primary, and not to
(4) Repair, rebuild or replace the property contribute with such other insurance.
with other property of like kind and quali
- ty.
CBP 02.114 Ed.2/10 Page 6 of 10 
- 7. Vacancy d. Valuable Papers and Records, including
those which exist on electronic or magnetic
If the building where loss or damage occurs
media (other than pre
- packaged software
has been vacant for more than 60 consecutive
programs), at the cost of:
days before that loss or damage, we will:
(1) Blank materials for reproducing the
a. Not pay for any loss or damage caused by
records; and
any of the following even if they are Cov
- ered Causes of Loss: (2) Labor to transcribe or copy the records
when there is a duplicate.
(1) Vandalism;
9. Waiver of Rights of Recovery
(2) Sprinkler leakage, unless you have
protected the system against freezing; We waive our rights to recover payment from
any unit
- owner of the condominium that is
(3) Building glass breakage;
shown in the Declarations.
(4) Water damage;
F. ADDITIONAL CONDITIONS
(5) Theft; or
The following conditions apply in addition to the
(6) Attempted theft. Common Policy Conditions and the Commercial
b. Reduce the amount we would otherwise Property Conditions.
pay for the loss or damage by 15%.
1. Coinsurance
A building is vacant when it does not contain If a Coinsurance percentage is shown in the
enough business personal property to conduct
Declarations, the following condition applies.
customary operations.
a. We will not pay the full amount of any loss if
Buildings under construction are not consid
- the value of Covered Property at the time of
ered vacant. loss times the Coinsurance percentage
8. Valuation shown for it in the Declarations is greater
than the Limit of Insurance for the property.
We will determine the value of Covered Prop
- erty in the event of loss or damage as follows: Instead, we will determine the most we will
pay using the following steps:
a. At actual cash value as of the time of loss
or damage, except as provided in b., c. and (1) Multiply the value of Covered Property
d. below. at the time of loss by the Coinsurance
percentage;
b. If the Limit of Insurance for Building satis
- fies the Additional Condition, Coinsurance, (2) Divide the Limit of Insurance of the
and the cost to repair or replace the dam
- property by the figure determined in step
aged building property is $2,500 or less, we (1);
will pay the cost of building repairs or re
- (3) Multiply the total amount of loss, before
placement.
the application of any deductible, by the
This provision does not apply to the follow
- figure determined in step (2); and
ing even when attached to the building: (4) Subtract the deductible from the figure
(1) Awnings or floor coverings; determined in step (3).
(2) Appliances for refrigerating, ventilating, We will pay the amount determined in step (4)
cooking, dishwashing or laundering; or or the limit of insurance, whichever is less. For
the remainder, you will either have to rely on
(3) Outdoor equipment or furniture.
other insurance or absorb the loss yourself.
c. Glass at the cost of replacement with safety
glazing material if required by law.
CBP 02.114 Ed.2/10 Page 7 of 10 
- Example No. 1 (Underinsurance): Example No. 3:
When: The value of property is $250,000 When: The value of property is:
The Coinsurance percentage Bldg. at Location No. 1 $ 75,000
for it is 80% Bldg. at Location No. 2 $100,000
The Limit of Insurance
Personal Property at
for it is $100,000
Location No. 2 $ 75,000
The Deductible is $250
$250,000
The amount of loss is $40,000
The Coinsurance
Step (1): $250,000 x 80% = $200,000
percentage for it is 90%
(the minimum amount of insurance to meet
The Limit of Insurance for
your Coinsurance requirements)
Buildings and Personal
Step (2): $100,000  $200,000 = .50 Property at Location
Step (3): $40,000 x .50 = $20,000 Nos. 1 and 2 is $180,000
Step (4): $20,000
- $250 = $19,750 The Deductible is $ 1,000
The amount of loss is Bldg.
We will pay no more than $19,750. The re
- at Location No. 2 $ 30,000
maining $20,250 is not covered.
Personal Property at
Example No. 2 (Adequate Insurance):
Location No. 2. $ 20,000
When: The value of the property is $250,000 $ 50,000
The Coinsurance percentage
Step (1): $250,000 x 90% = $225,000
for it is 80%
(the minimum amount of insurance to meet
The Limit of Insurance
your Coinsurance requirements and to
for it is $200,000
avoid the penalty shown below)
The Deductible is $250
The amount of loss is $40,000 Step (2): $180,000  $225,000 = .80
Step (3): $ 50,000 x .80 = $40,000
Step (1): $250,000 x 80% = $200,000
(the minimum amount of insurance to meet Step (4): $ 40,000
- $1,000 = $39,000
your Coinsurance requirements)
We will pay no more than $39,000. The re
- Step (2): $200,000  $200,000 = 1.00 maining $11,000 is not covered.
Step (3): $ 40,000 x 1.00 = $ 40,000 2. Mortgage Holders
Step (4): $ 40,000
- $250 = $ 39,750 a. The term "mortgage holder" includes trus
- We will cover the $39,750 loss in excess of tee.
the Deductible. No penalty applies. b. We will pay for covered loss of or damage
to buildings or structures to each mortgage
b. If one Limit of Insurance applies to two or
more separate items, this condition will ap
- holder shown in the Declarations in their
ply to the total of all property to which the order of precedence, as interests may ap
- limit applies. pear.
c. The mortgage holder has the right to re
- ceive loss payment even if the mortgage
holder has started foreclosure or similar ac
- tion on the building or structure.
CBP 02.114 Ed.2/10 Page 8 of 10 
- d. If we deny your claim because of your acts g. If we elect not to renew this policy, we will
or because you have failed to comply with give written notice to the mortgage holder at
the terms of this Coverage Part, the mort
- least 10 days before the expiration date of
gage holder will still have the right to re
- this policy.
ceive loss payment if the mortgage holder:
G. OPTIONAL COVERAGES
(1) Pays any premium due under this Cov
- If shown in the Declarations, the following Optional
erage Part at our request if you have
Coverages apply separately to each item.
failed to do so;
1. Agreed Value
(2) Submits a signed, sworn statement of
loss within 60 days after receiving notice a. The Additional Condition, Coinsurance,
from us of your failure to do so; and does not apply to Covered Property to
which this Optional Coverage applies. We
(3) Has notified us of any change in owner
- will pay no more for loss of or damage to
ship, occupancy or substantial change
that property than the proportion that the
in risk known to the mortgage holder.
Limit of Insurance under this Coverage Part
All of the terms of this Coverage Part will for the property bears to the Agreed Value
then apply directly to the mortgage holder. shown for it in the Declarations.
e. If we pay the mortgage holder for any loss b. If the expiration date for this Optional Cov
- or damage and deny payment to you be
- erage shown in the Declarations is not ex
- cause of your acts or because you have tended, the Additional Condition, Coinsur
- failed to comply with the terms of this Cov
- ance, is reinstated and this Optional Cover
- erage Part: age expires.
(1) The mortgage holder's rights under the c. The terms of this Optional Coverage apply
mortgage will be transferred to us to the only to loss or damage that occurs:
extent of the amount we pay; and
(1) On or after the effective date of this
(2) The mortgage holder's right to recover Optional Coverage; and
the full amount of the mortgage holder's
(2) Before the Agreed Value expiration date
claim will not be impaired.
shown in the Declarations or the policy
At our option, we may pay to the mort
- expiration date, whichever occurs first.
gage holder the whole principal on the
2. Inflation Guard
mortgage plus any accrued interest. In
a. The Limit of Insurance for property to which
this event, your mortgage and note will
this Optional Coverage applies will auto
- be transferred to us and you will pay
matically increase by the annual percent
- your remaining mortgage debt to us.
age shown in the Declarations.
f. If we cancel this policy, we will give written
b. The amount of increase will be:
notice to the mortgage holder at least:
(1) 10 days before the effective date of (1) The Limit of Insurance that applied on
cancellation if we cancel for your non
- the most recent of the policy inception
payment of premium; or date, the policy anniversary date, or any
other policy change amending the Limit
(2) 30 days before the effective date of
of Insurance, times
cancellation if we cancel for any other
reason. (2) The percentage of annual increase
shown in the Declarations, expressed as
a decimal (example: 8% is .08), times
CBP 02.114 Ed.2/10 Page 9 of 10 
- (3) The number of days since the beginning d. We will not pay on a replacement cost basis
of the current policy year or the effective for any loss or damage:
date of the most recent policy change
(1) Until the lost or damaged property is
amending the Limit of Insurance, divided
actually repaired or replaced; and
by 365.
(2) Unless the repairs or replacement are
Example:
made as soon as reasonably possible
If: The applicable Limit after the loss or damage.
of Insurance is $100,000
e. We will not pay more for loss or damage on
The annual percentage
a replacement cost basis than the least of:
increase is 8%
The number of days (1) The Limit of Insurance applicable to the
since the beginning lost or damaged property;
of the policy year (2) The cost to replace, on the same prem
- (or last policy ises, the lost or damaged property with
change) is 146 other property:
The amount of increase is
(a) Of comparable material and quality;
$100,000 x .08 x 146  365 = $3,200
and
3. Replacement Cost
(b) Used for the same purpose; or
a. Replacement Cost (without deduction for
(3) The amount you actually spend that is
depreciation) replaces Actual Cash Value in
necessary to repair or replace the lost or
the Loss Condition, Valuation, of this Cov
- damaged property.
erage Form.
H. DEFINITIONS
b. This Optional Coverage does not apply to:
"Pollutants" means any solid, liquid, gaseous or
(1) Property of others;
thermal irritant or contaminant, including smoke,
(2) Contents of a residence; vapor, soot, fumes, acids, alkalis, chemicals and
waste. Waste includes materials to be recycled,
(3) Manuscripts; or
reconditioned or reclaimed.
(4) Works of art, antiques or rare articles,
including etchings, pictures, statuary,
marbles, bronzes, porcelains and bric
- brac.
c. You may make a claim for loss or damage
covered by this insurance on an actual cash
value basis instead of on a replacement
cost basis. In the event you elect to have
loss or damage settled on an actual cash
value basis, you may still make a claim for
the additional coverage this Optional Cov
- erage provides if you notify us of your intent
to do so within 180 days after the loss or
damage.
CBP 02.114 Ed.2/10 Page 10 of 10 

## Definitions

**Th**: Optional Coverage does not apply to:
"Pollutants" means any solid, liquid, gaseous or
(1) Property of others;
thermal irritant or contaminant, including smoke,
(2) Contents of a residence; vapor, soot, fumes, acids, alkalis, chemicals and
waste.

**You may make a claim for loss or damage
covered by this insurance on an actual cash
value bas**: instead of on a replacement
cost basis.

**In the event you elect to have
loss or damage settled on an actual cash
value bas**: , you may still make a claim for
the additional coverage this Optional Cov-
erage provides if you notify us of your intent
to do so within 180 days after the loss or
damage.

