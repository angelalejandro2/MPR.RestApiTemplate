# Insurance Form Analysis

## Coverages

### Coverage 1
- **Type**: in the building or
(2) Containers of property held for sale
- **Context**: n. restriction does not apply to:
c. The interior of any building or structure, or (1) Glass; or
to personal property in the building or
(2) Containers of property held for sale.
structure, caused by or resulting from rain,
snow, sleet, ice, sand or dust, whether c. Builders'

### Coverage 2
- **Type**: ;
damaged parts of fire-extinguishing equipment
or
if the damage:
(5) Weight of rain that collects on a roof
- **Context**: t (3) Breakage of building glass;
we will pay the cost to repair or replace
(4) Weight of people or personal property;
damaged parts of fire-extinguishing equipment
or
if the damage:
(5) Weight of rain that collects on a roof.
a. Results in discharge of any substance from
an automatic fire protection system; or 3. This Addi

### Coverage 3
- **Type**: abruptly falls down or Limited Coverage, the term loss or damage
caves in and such collapse is not the result of means:
abrupt collapse of a building, we will pay for a
- **Context**: r loss or damage by "fungus",
this Coverage Form. wet or dry rot or bacteria. As used in this
5. If personal property abruptly falls down or Limited Coverage, the term loss or damage
caves in and such collapse is not the result of means:
abrupt collapse of a building, we will pay for a. Direct physical loss or damage to Covered
loss or damage to Covered Property caused by Property ca

### Coverage 4
- **Type**: only if: or bacteria, including the cost of removal of
a
- **Context**: r damage to Covered Property caused by Property caused by "fungus", wet or dry rot
such collapse of personal property only if: or bacteria, including the cost of removal of
a. The collapse of personal property was the "fungus", wet or dry rot or bacteria;
caused by a cause

### Coverage 5
- **Type**: was the "fungus", wet or dry rot or bacteria;
caused by a cause of loss listed in 2
- **Context**: apse of personal property only if: or bacteria, including the cost of removal of
a. The collapse of personal property was the "fungus", wet or dry rot or bacteria;
caused by a cause of loss listed in 2.a. b. The cost to tear out and replace any part of
through 2.d.; the building or other property as

### Coverage 6
- **Type**: which collapses is gain access to the "fungus", wet or dry rot
inside a building; and or bacteria; and
c
- **Context**: o tear out and replace any part of
through 2.d.; the building or other property as needed to
b. The personal property which collapses is gain access to the "fungus", wet or dry rot
inside a building; and or bacteria; and
c. The property which collapses is not of a c. The cost of testing performed after removal,
kind list

### Coverage 7
- **Type**: or real property
- **Context**: or restoration of the
kind of property is considered to be damaged property is completed, provided
personal property or real property. there is a reason to believe that "fungus",
wet or dry rot or bacteria are present.
The coverage s

### Coverage 8
- **Type**: if marring and/or 3
- **Context**: wet or dry rot or bacteria are present.
The coverage stated in this Paragraph 5. does
not apply to personal property if marring and/or 3. The coverage described under E.2. of this
scratching is the only damage to that personal Limited C

### Coverage 9
- **Type**: that has not abruptly
"specified causes of loss" (other than fire or
fallen down or caved in, even if the personal
lightning) and Flood which take place in a 12-
property shows evidence of cracking, bulging,
month period (starting with the beginning of the
sagging, bending, leaning, settling, shrinkage
present annual policy period)
- **Context**: r
6. This Additional Coverage, Collapse, does not
damage arising out of all occurrences of
apply to personal property that has not abruptly
"specified causes of loss" (other than fire or
fallen down or caved in, even if the personal
lightning) and Flood which take place in a 12-
property shows evidence of cracking, bulging,
month period (starting with the beginning of the
sagging, bending, leaning, settling, shrinkage
present annual policy period). With respect to a
or expansion.
particular occurrence of loss which results in
7. This Additional

### Coverage 10
- **Type**: to which this form applies
- **Context**: Covered Property. If
a particular occurrence results in loss or This Extension applies only to your personal
property to which this form applies.
damage by "fungus", wet or dry rot or bacteria,
and other loss or damage, we will not pay a. You m

### Coverage 11
- **Type**: (other than property in
affected Covered Property
- **Context**: l loss or damage, than this Coverage Part to apply to your
the applicable Limit of Insurance on the personal property (other than property in
affected Covered Property. the care, custody or control of your
salespersons) in transit more than 100 feet
If there is cover

### Coverage 12
- **Type**: in the open; or is no coverage for loss or damage caused
by or related to weather-induced flooding
(2) The interior of a building or structure, or
which follows or is exacerbated by pipe
property inside a building or structure,
breakage or cracking attributable to wear
unless the roof or an outside wall of the
and tear
- **Context**: another example, and also in accordance
damage to: with the terms of the Water Exclusion, there
(1) Personal property in the open; or is no coverage for loss or damage caused
by or related to weather-induced flooding
(2) The interior of a building or structure, or
which follows or is exacerbated by pipe
property inside a building or structure,
breakage or cracking attributable to wear
unless the roof or an outside wall of the
and tear.
building or structure is first damaged by
a falling object. To the extent that accidental discharg

### Coverage 13
- **Type**: Form
(b) The time required to reproduce
"finished stock"
- **Context**: se; or
(a) Damage or destruction of "finished
(c) Any other consequential loss.
stock"; or
c. Legal Liability Coverage Form
(b) The time required to reproduce
"finished stock". (1) The following exclusions do not apply to
insurance under this Coverage Form:
This exclusion do

## Coverage Limits

- **Amount**: $,
- **Context**: the extent that coverage is provided
(6) Mechanical breakdown, including
in the Additional Coverage, Limited
rupture or bursting caused by centrifugal
Coverage For "Fungus", Wet Rot, Dry
force. But if mecha

## Exclusions

- expansion, freezing, thawing, erosion,
1. We will not pay for loss or damage caused improperly compacted soil and the
directly or indirectly by any of the following. action of water under the ground
Such loss or damage is excluded regardless of surface.
any other cause or event that contributes But if Earth Movement, as described in
concurrently or in any sequence to the loss. b.(1) through (4) above, results in fire or
a. Ordinance Or Law explosion, we will pay for the loss or
damage caused by that fire or explosion.
The enforcement of or compliance with any
ordinance or law: (5) Volcanic eruption, explosion or effusion.
But if volcanic eruption, explosion or
(1) Regulating the construction, use or
effusion results in fire, building glass
repair of any property; or
breakage or Volcanic Action, we will pay
(2) Requiring the tearing down of any for the loss or damage caused by that
property, including the cost of removing fire, building glass breakage or Volcanic
its debris. Action.
This

## Definitions

**When Special**: shown in the Declarations,
conditions which cause settling,
Covered Causes of Loss means direct physical
cracking or other disarrangement of
loss unless the loss is excluded or limited in this
foundations or other parts of realty.

**Such loss or damage**: excluded regardless of surface.

**Th**: exclusion, Ordinance Or Law, applies Volcanic Action means direct loss or
whether the loss results from: damage resulting from the eruption of a
(a) An ordinance or law that is enforced volcano when the loss or damage is
even if the property has not been caused by:
damaged; or (a) Airborne volcanic blast or airborne
(b) The increased costs incurred to shock waves;
comply with an ordinance or law in (b) Ash, dust or particulate matter; or
the course of construction, repair,
(c) Lava flow.

**Th**: exclusion applies regardless of
of a man-made mine, whether or not whether any of the above, in Paragraphs
mining activity has ceased; (1) through (5), is caused by an act of
nature or is otherwise caused.

**Water that backs up or overflows or**: But if nuclear reaction or radiation, or
otherwise discharged from a sewer,
radioactive contamination, results in fire, we
drain, sump, sump pump or related
will pay for the loss or damage caused by
equipment;
that fire.

**Originates away from the described
prem**: es; or (c) Doors, windows or other openings;
or
(2) Originates at the described premises,
but only if such failure involves (5) Waterborne material carried or
equipment used to supply the utility otherwise moved by any of the water
service to the described premises from referred to in Paragraph (1), (3) or (4),
a source away from the described or material carried or otherwise moved
premises.

**Failure of any utility service includes lack of Th**: exclusion applies regardless of
sufficient capacity and reduction in supply.

**Loss or damage caused by a surge of
nature or is otherw**: e caused.

**An example
power**: also excluded, if the surge would
of a situation to which this exclusion applies
not have occurred but for an event causing
is the situation where a dam, levee, seawall
a failure of power.

**Th**: exclusion does not apply: (5) Nesting or infestation, or discharge or
release of waste products or secretions,
(1) When "fungus", wet or dry rot or bacteria
by insects, birds, rodents or other
result from fire or lightning; or
animals.

**To the extent that coverage**: provided
(6) Mechanical breakdown, including
in the Additional Coverage, Limited
rupture or bursting caused by centrifugal
Coverage For "Fungus", Wet Rot, Dry
force.

**But if an excluded cause of loss that**: (1) Electrical or electronic wire, device, listed in 2.

**For the purpose of th**: exclusion, electrical,
e.

**To collapse caused by one or more
the supply if the heat**: not maintained.

**Th**: exclusion: the "specified causes of loss".

**But if the
d**: charge, dispersal, seepage, migration,
(1) Applies whether or not an act occurs
release or escape of "pollutants" results in a
during your normal hours of operation;
"specified cause of loss", we will pay for the
(2) Does not apply to acts of destruction by
loss or damage caused by that "specified
your employees (including temporary
cause of loss".

**Th**: exclusion, I.

**But th**: exclusion only
property: applies if weather conditions contribute in
any way with a cause or event excluded in
(1) An abrupt falling down or caving in;
Paragraph 1.

**Acts or dec**: ions, including the failure to act
property in danger of falling down or
or decide, of any person, group,
caving in; or
organization or governmental body.

**Loss at the described prem**: es, we will repair, construction, renovation,
pay for the loss or damage caused by that remodeling, grading, compaction;
Covered Cause of Loss.

**Th**: exclusion, k.

**To the extent that coverage**: (4) Maintenance;
provided under the Additional of part or all of any property on or off the
Coverage, Collapse; or described premises.

**The following prov**: ions apply only to the b.

**The following exclusions do not apply to
insurance under th**: Coverage Form:
This exclusion does not apply to Extra
(a) Paragraph B.

**The following additional exclusions
replacing the property or resuming
apply to insurance under th**: Coverage
"operations", due to interference at
Form:
the location of the rebuilding, repair
or replacement by strikers or other (a) Contractual Liability
persons; or We will not defend any claim or
(b) Suspension, lapse or cancellation of "suit", or pay damages that you are
any license, lease or contract.

**But th**: "suspension" of "operations", we will exclusion does not apply to a written
cover such loss that affects your lease agreement in which you have
Business Income during the "period assumed liability for building damage
of restoration" and any extension of resulting from an actual or attempted
the "period of restoration" in burglary or robbery, provided that:
accordance with the terms of the (i) Your assumption of liability was
Extended Business Income executed prior to the accident;
Additional Coverage and the and
Extended Period Of Indemnity
(ii) The building is Covered Property
Optional Coverage or any variation
under this Coverage Form.

**The following prov**: ions apply only to the
caused by or resulting from theft.

**Builders R**: k Coverage Form;
by or resulting from error or omission by any
or
person or entity (including those having
possession under an arrangement where work (2) Business Income Coverage or Extra
or a portion of the work is outsourced) in any Expense Coverage.

**Property that is m**: sing, where the only
the product, including planning, testing,
evidence of the loss or damage is a
processing, packaging, installation,
shortage disclosed on taking inventory, or
maintenance or repair.

**This exclusion applies
other instances where there is no physical
to any effect that comprom**: es the form,
evidence to show what happened to the
substance or quality of the product.

**Hot water boilers or other water heating their destruction**: made necessary.

**Th**: equipment, other than an explosion.

**If the property**: located on or within
snow, sleet, ice, sand or dust enters; or
100 feet of the described premises,
(2) The loss or damage is caused by or unless the premises is insured under the
results from thawing of snow, sleet or Builders Risk Coverage Form; or
ice on the building or structure.

**The collapse of a building or any part of a building
special limit applies to any one occurrence of that is insured under th**: Coverage Form or
theft, regardless of the types or number of that contains Covered Property insured under
articles that are lost or damaged in that this Coverage Form, if such collapse is caused
occurrence.

**Building decay that**: hidden from view,
a.

**Insect or vermin damage that**: hidden
movements, jewels, pearls, precious and from view, unless the presence of such
semiprecious stones, bullion, gold, silver, damage is known to an insured prior to
platinum and other precious alloys or collapse;
metals.

**Th**: limit does not apply to jewelry
c.

**Th**: limitation, C.

**A cause of loss l**: ted in 2.

**Results in d**: charge of any substance from
an automatic fire protection system; or 3.

**Th**: Additional Coverage – Collapse does
not apply to:
b.

**A building or any part of a building that**: in
However, this limitation does not apply to
danger of falling down or caving in;
Business Income Coverage or to Extra
Expense Coverage.

**A part of a building that**: standing, even if
it has separated from another part of the
D.

**The coverage provided under th**: Additional
c.

**A building that**: standing or any part of a
Coverage, Collapse, applies only to an abrupt
building that is standing, even if it shows
collapse as described and limited in D.

**For the purpose of th**: Additional Coverage, expansion.

**Outdoor radio or telev**: ion antennas
building or part of the building cannot be (including satellite dishes) and their lead-in
occupied for its intended purpose.

**Such loss or damage is a direct result of Th**: Additional Coverage does not apply to
the abrupt collapse of a building insured lawns, trees, shrubs or plants which are part of
under this Coverage Form; and a vegetated roof.

**The property**: Covered Property under 2.

**As used in th**: 5.

**The personal property which collapses**: gain access to the "fungus", wet or dry rot
inside a building; and or bacteria; and
c.

**The property which collapses**: not of a c.

**The coverage stated in th**: Paragraph 5.

**Limited Coverage**: limited to $15,000.

**Th**: Additional Coverage, Collapse, does not
damage arising out of all occurrences of
apply to personal property that has not abruptly
"specified causes of loss" (other than fire or
fallen down or caved in, even if the personal
lightning) and Flood which take place in a 12-
property shows evidence of cracking, bulging,
month period (starting with the beginning of the
sagging, bending, leaning, settling, shrinkage
present annual policy period).

**Th**: Additional Coverage, Collapse, will not "fungus", wet or dry rot or bacteria, we will not
increase the Limits of Insurance provided in pay more than a total of $15,000 even if the
this Coverage Part.

**The coverage provided under th**: Limited F.

**If
a particular occurrence results in loss or This Extension applies only to your personal
property to which th**: form applies.

**If there is covered loss or damage to Covered
from the described prem**: es.

**Loss or damage must be caused by or
such increase in the loss will be subject to the result from one of the following causes of
terms of th**: Limited Coverage.

**The terms of th**: Limited Coverage do not (1) Fire, lightning, explosion, windstorm or
increase or reduce the coverage provided hail, riot or civil commotion, or
under Paragraph F.

**Other vandal**: m.

**Vehicle coll**: ion, upset or overturn.

**Causes Of Loss form or under the
Collision**: accidental contact of
Additional Coverage, Collapse.

**It does not**: your vehicle's
Business Income and/or Extra Expense contact with the roadbed.

**Coverage applies to the described prem**: es
(3) Theft of an entire bale, case or package
and only if the "suspension" of "operations"
by forced entry into a securely locked
satisfies all terms and conditions of the
body or compartment of the vehicle.

**Extra
There must be v**: ible marks of the
Expense Coverage Form:
forced entry.

**The most we will pay for loss or damage
dry rot or bacteria does not in itself
under this Extension**: $5,000.

**This Coverage Extension**: additional
loss or damage to property caused by insurance.

**Powder Or
Extra Expense**: limited to the amount of Molten Material Damage
loss and/or expense sustained in a period
If loss or damage caused by or resulting from
of not more than 30 days.

**Th**: Coverage
bacteria prolongs the "period of restoration", Extension does not increase the Limit of
we will pay for loss and/or expense Insurance.

**We will pay for expenses incurred to put up**: limited to 30 days.

**Water damage**: :
remove or replace obstructions when
(1) Accidental discharge or leakage of
repairing or replacing glass that is part of a
water or steam as the direct result of the
building.

**This does not include removing or
breaking apart or cracking of a
replacing window d**: plays.

**Th**: Coverage Extension F.

