# Insurance Form Analysis

## Coverages

### Coverage 1
- **Type**: in the
open or personal property in a
Coverage is provided as described and limited
vehicle); and
below for one or more of the following options
for which a Limit Of Insurance is shown in the (c) Any area within the building or at the
Declarations: described premises, if that area
services, or is used to gain access
(1) Business Income Including "Rental
to, the portion of the building which
Value"
- **Context**: et Income includes greater (with respect to loss of or
the net sales value of production. damage to personal property in the
open or personal property in a
Coverage is provided as described and limited
vehicle); and
below for one or more of the following options
for which a Limit Of Insurance is shown in the (c) Any area within the building or at the
Declarations: described premises, if that area
services, or is used to gain access
(1) Business Income Including "Rental
to, the portion of the building which
Value".
you rent, lease or occupy.
(2) Business Income Other Than "Rental
2. Extra Expense
Value".
a. Extr

### Coverage 2
- **Type**: in the open or personal
property in a vehicle, the described premises
include the area within 100 feet of such
premises
- **Context**: red Cause of
replacement location or temporary
Loss. With respect to loss of or damage to
location.
personal property in the open or personal
property in a vehicle, the described premises
include the area within 100 feet of such
premises.
CP 00 30 10 12 © Insurance Services Office, Inc.,2011 Page 1of 9

--- Page 2 ---
(2) Minimize the

## Exclusions

- And
damage to property other than property at
Limitations
the described premises, we will pay for the
See applicable Causes Of Loss form as shown actual loss of Business Income you sustain
in the Declarations. and necessary Extra Expense caused by
action of civil authority that prohibits access
4. Additional Limitation
- Interruption Of
to the described premises, provided that
Computer Operations
both of the following apply:
a. Coverage for Business Income does not
(1) Access to the area immediately
apply when a "suspension" of "operations"
surrounding the damaged property is
is caused by destruction or corruption of
prohibited by civil authority as a result of
electronic data, or any loss or damage to
the damage, and the described
electronic data, except as provided under
premises are within that area but are not
the Additional Coverage, Interruption Of
more than one mile from the damaged
Computer Operations.
property; and
b. Coverage for Extra Expense does not apply
(2) The action of civil authority is taken in
when action is taken to avoid or minimize a
response to dangerous physical
"suspension" of "operations" caused by
conditions resulting from the damage or
destruction or corruption of electronic data,
continuation of the Covered Cause of
or any loss or damage to electronic data,
Loss that caused the damage, or the
except as provided under the Additional
action is taken to enable a civil authority
Coverage, Interruption Of Computer
to have unimpeded access to the
Operations.
damaged property.
c. Electronic data means information, facts or
Civil Authority Coverage for Business
computer programs stored as or on,
Income will begin 72 hours after the time of
created or used on, or transmitted to or
the first action of civil authority that prohibits
from computer software (including systems
access to the described premises and will
and applications software), on hard or
apply for a period of up to four consecutive
floppy disks, CD
- ROMs, tapes, drives, cells,
weeks from the date on which such
data processing devices or any other
coverage began.
repositories of computer software which are
used with electronically controlled Civil Authority Coverage for Extra Expense
equipment. The term computer programs, will begin immediately after the time of the
referred to in the foregoing description of first action of civil authority that prohibits
electronic data, means a set of related access to the described premises and will
electronic instructions which direct the end:
operations and functions of a computer or
(1) Four consecutive weeks after the date
device connected to it, which enable the
of that action; or
computer or device to receive, process,
(2) When your Civil Authority Coverage for
store, retrieve or send data.
Business Income ends;
d. This Additional Limitation does not apply
whichever is later.
when loss or damage to electronic data
involves only electronic data which is
integrated in and operates or controls a
building's elevator, lighting, heating,
ventilation, air conditioning or security
system.
Page 2 of 9 © Insurance Services Office, Inc.,2011 CP 00 30 10 12
- b. Alterations And New Buildings However, Extended Business Income
does not apply to loss of Business
We will pay for the actual loss of Business
Income incurred as a result of
Income you sustain and necessary Extra
unfavorable business conditions caused
Expense you incur due to direct physical
by the impact of the Covered Cause of
loss or damage at the described premises
Loss in the area where the described
caused by or resulting from any Covered
premises are located.
Cause of Loss to:
Loss of Business Income must be
(1) New buildings or structures, whether
caused by direct physical loss or
complete or under construction;
damage at the described premises
(2) Alterations or additions to existing caused by or resulting from any Covered
buildings or structures; and Cause of Loss.
(3) Machinery, equipment, supplies or (2) "Rental Value"
building materials located on or within
If the necessary "suspension" of your
100 feet of the described premises and:
"operations" produces a "Rental Value"
(a) Used in the construction, alterations loss payable under this policy, we will
or additions; or pay for the actual loss of "Rental Value"
(b) Incidental to the occupancy of new you incur during the period that:
buildings. (a) Begins on the date property is
If such direct physical loss or damage actually repaired, rebuilt or replaced
delays the start of "operations", the "period and tenantability is restored; and
of restoration" for Business Income (b) Ends on the earlier of:
Coverage will begin on the date
(i) The date you could restore tenant
"operations" would have begun if the direct
occupancy, with reasonable
physical loss or damage had not occurred.
speed, to the level which would
c. Extended Business Income generate the "Rental Value" that
(1) Business Income Other Than "Rental would have existed if no direct
Value" physical loss or damage had
occurred; or
If the necessary "suspension" of your
"operations" produces a Business (ii) 60 consecutive days after the
Income loss payable under this policy, date determined in (2)(a) above.
we will pay for the actual loss of However, Extended Business Income
Business Income you incur during the does not apply to loss of "Rental Value"
period that: incurred as a result of unfavorable
(a) Begins on the date property (except business conditions caused by the
"finished stock") is actually repaired, impact of the Covered Cause of Loss in
rebuilt or replaced and "operations" the area where the described premises
are resumed; and are located.
(b) Ends on the earlier of: Loss of "Rental Value" must be caused
by direct physical loss or damage at the
(i) The date you could restore your
described premises caused by or
"operations", with reasonable
resulting from any Covered Cause of
speed, to the level which would
Loss.
generate the business income
amount that would have existed if d. Interruption Of Computer Operations
no direct physical loss or damage
(1) Under this Additional Coverage,
had occurred; or electronic data has the meaning
(ii) 60 consecutive days after the described under Additional Limitation
- date determined in (1)(a) above. Interruption Of Computer Operations.
CP 00 30 10 12 © Insurance Services Office, Inc.,2011 Page 3of 9
- (2) Subject to all provisions of this (4) The most we will pay under this
Additional Coverage, you may extend Additional Coverage, Interruption Of
the insurance that applies to Business Computer Operations, is $2,500 (unless
Income and Extra Expense to apply to a a higher limit is shown in the
"suspension" of "operations" caused by Declarations) for all loss sustained and
an interruption in computer operations expense incurred in any one policy year,
due to destruction or corruption of regardless of the number of
electronic data due to a Covered Cause interruptions or the number of premises,
of Loss. However, we will not provide locations or computer systems involved.
coverage under this Additional If loss payment relating to the first
Coverage when the Additional Limitation interruption does not exhaust this
- Interruption Of Computer Operations amount, then the balance is available for
does not apply based on Paragraph loss or expense sustained or incurred as
A.4.d. therein. a result of subsequent interruptions in
that policy year. A balance remaining at
(3) With respect to the coverage provided
the end of a policy year does not
under this Additional Coverage, the
increase the amount of insurance in the
Covered Causes of Loss are subject to
next policy year. With respect to any
the following:
interruption which begins in one policy
(a) If the Causes Of Loss
- Special year and continues or results in
Form applies, coverage under this additional loss or expense in a
Additional Coverage, Interruption Of subsequent policy year(s), all loss and
Computer Operations, is limited to expense is deemed to be sustained or
the "specified causes of loss" as incurred in the policy year in which the
defined in that form and Collapse as interruption began.
set forth in that form.
(5) This Additional Coverage, Interruption
(b) If the Causes Of Loss
- Broad Form Of Computer Operations, does not apply
applies, coverage under this to loss sustained or expense incurred
Additional Coverage, Interruption Of after the end of the "period of
Computer Operations, includes restoration", even if the amount of
Collapse as set forth in that form. insurance stated in (4) above has not
(c) If the Causes Of Loss form is been exhausted.
endorsed to add a Covered Cause of
6. Coverage Extension
Loss, the additional Covered Cause
If a Coinsurance percentage of 50% or more is
of Loss does not apply to the
shown in the Declarations, you may extend the
coverage provided under this
insurance provided by this Coverage Part as
Additional Coverage, Interruption Of
follows:
Computer Operations.
Newly Acquired Locations
(d) The Covered Causes of Loss include
a virus, harmful code or similar a. You may extend your Business Income and
instruction introduced into or enacted Extra Expense Coverages to apply to
on a computer system (including property at any location you acquire other
electronic data) or a network to than fairs or exhibitions.
which it is connected, designed to
b. The most we will pay under this Extension,
damage or destroy any part of the
for the sum of Business Income loss and
system or disrupt its normal
Extra Expense incurred, is $100,000 at
operation. But there is no coverage
each location, unless a higher limit is shown
for an interruption related to
in the Declarations.
manipulation of a computer system
c. Insurance under this Extension for each
(including electronic data) by any
newly acquired location will end when any
employee, including a temporary or
of the following first occurs:
leased employee, or by an entity
retained by you or for you to inspect, (1) This policy expires;
design, install, maintain, repair or
replace that system.
Page 4 of 9 © Insurance Services Office, Inc.,2011 CP 00 30 10 12
- (2) 30 days expire after you acquire or 2. Duties In The Event Of Loss
begin to construct the property; or
a. You must see that the following are done in
(3) You report values to us. the event of loss:
We will charge you additional premium for (1) Notify the police if a law may have been
values reported from the date you acquire broken.
the property.
(2) Give us prompt notice of the direct
The Additional Condition, Coinsurance, does physical loss or damage. Include a
not apply to this Extension. description of the property involved.
B. Limits Of Insurance (3) As soon as possible, give us a
description of how, when and where the
The most we will pay for loss in any one
direct physical loss or damage occurred.
occurrence is the applicable Limit Of Insurance
shown in the Declarations. (4) Take all reasonable steps to protect the
Covered Property from further damage,
Payments under the following coverages will not
and keep a record of your expenses
increase the applicable Limit of Insurance:
necessary to protect the Covered
1. Alterations And New Buildings; Property, for consideration in the
2. Civil Authority; settlement of the claim. This will not
increase the Limit of Insurance.
3. Extra Expense; or
However, we will not pay for any
4. Extended Business Income. subsequent loss or damage resulting
The amounts of insurance stated in the from a cause of loss that is not a
Interruption Of Computer Operations Additional Covered Cause of Loss. Also, if
Coverage and the Newly Acquired Locations feasible, set the damaged property
Coverage Extension apply in accordance with the aside and in the best possible order for
terms of those coverages and are separate from examination.
the Limit(s) Of Insurance shown in the (5) As often as may be reasonably required,
Declarations for any other coverage. permit us to inspect the property proving
C. Loss Conditions the loss or damage and examine your
books and records.
The following conditions apply in addition to the
Common Policy Conditions and the Commercial Also permit us to take samples of
Property Conditions: damaged and undamaged property for
inspection, testing and analysis, and
1. Appraisal
permit us to make copies from your
If we and you disagree on the amount of Net books and records.
Income and operating expense or the amount
(6) Send us a signed, sworn proof of loss
of loss, either may make written demand for an
containing the information we request to
appraisal of the loss. In this event, each party
investigate the claim. You must do this
will select a competent and impartial appraiser.
within 60 days after our request. We will
The two appraisers will select an umpire. If supply you with the necessary forms.
they cannot agree, either may request that
(7) Cooperate with us in the investigation or
selection be made by a judge of a court having
settlement of the claim.
jurisdiction. The appraisers will state separately
the amount of Net Income and operating (8) If you intend to continue your business,
expense or amount of loss. If they fail to agree, you must resume all or part of your
they will submit their differences to the umpire. "operations" as quickly as possible.
A decision agreed to by any two will be b. We may examine any insured under oath,
binding. Each party will: while not in the presence of any other
a. Pay its chosen appraiser; and insured and at such times as may be
reasonably required, about any matter
b. Bear the other expenses of the appraisal
relating to this insurance or the claim,
and umpire equally.
including an insured's books and records. In
If there is an appraisal, we will still retain our the event of an examination, an insured's
right to deny the claim. answers must be signed.
CP 00 30 10 12 © Insurance Services Office, Inc.,2011 Page 5of 9
- 3. Loss Determination c. Resumption Of Operations
a. The amount of Business Income loss will be We will reduce the amount of your:
determined based on:
(1) Business Income loss, other than Extra
(1) The Net Income of the business before Expense, to the extent you can resume
the direct physical loss or damage your "operations", in whole or in part, by
occurred; using damaged or undamaged property
(including merchandise or stock) at the
(2) The likely Net Income of the business if
described premises or elsewhere.
no physical loss or damage had
occurred, but not including any Net (2) Extra Expense loss to the extent you
Income that would likely have been can return "operations" to normal and
earned as a result of an increase in the discontinue such Extra Expense.
volume of business due to favorable
d. If you do not resume "operations", or do not
business conditions caused by the
resume "operations" as quickly as possible,
impact of the Covered Cause of Loss on
we will pay based on the length of time it
customers or on other businesses;
would have taken to resume "operations" as
(3) The operating expenses, including quickly as possible.
payroll expenses, necessary to resume
4. Loss Payment
"operations" with the same quality of
We will pay for covered loss within 30 days
service that existed just before the direct
after we receive the sworn proof of loss, if you
physical loss or damage; and
have complied with all of the terms of this
(4) Other relevant sources of information,
Coverage Part, and:
including:
a. We have reached agreement with you on
(a) Your financial records and
the amount of loss; or
accounting procedures;
b. An appraisal award has been made.
(b) Bills, invoices and other vouchers;
and D. Additional Condition
COINSURANCE
(c) Deeds, liens or contracts.
If a Coinsurance percentage is shown in the
b. The amount of Extra Expense will be
Declarations, the following condition applies in
determined based on:
addition to the Common Policy Conditions and the
(1) All expenses that exceed the normal
Commercial Property Conditions.
operating expenses that would have
been incurred by "operations" during the We will not pay the full amount of any Business
Income loss if the Limit of Insurance for Business
"period of restoration" if no direct
Income is less than:
physical loss or damage had occurred.
We will deduct from the total of such 1. The Coinsurance percentage shown for
expenses: Business Income in the Declarations; times
(a) The salvage value that remains of 2. The sum of:
any property bought for temporary
a. The Net Income (Net Profit or Loss before
use during the "period of restoration",
income taxes), and
once "operations" are resumed; and
b. Operating expenses, including payroll
(b) Any Extra Expense that is paid for by
expenses,
other insurance, except for insurance
that is written subject to the same that would have been earned or incurred (had
plan, terms, conditions and no loss occurred) by your "operations" at the
provisions as this insurance; and described premises for the 12 months following
the inception, or last previous anniversary date,
(2) Necessary expenses that reduce the
of this policy (whichever is later).
Business Income loss that otherwise
would have been incurred.
Page 6 of 9 © Insurance Services Office, Inc.,2011 CP 00 30 10 12
- Instead, we will determine the most we will pay Example 1 (Underinsurance)
using the following steps:
When: The Net Income and operating
Step (1): Multiply the Net Income and operating
expenses for the 12 months
expense for the 12 months following the
following the inception, or last
inception, or last previous anniversary
previous anniversary date, of
date, of this policy by the Coinsurance
this policy at the described
percentage;
premises would have been: $400,000
Step (2): Divide the Limit of Insurance for the
The Coinsurance percentage is: 50%
described premises by the figure
The Limit of Insurance is: $150,000
determined in Step (1); and
The amount of loss is: $ 80,000
Step (3): Multiply the total amount of loss by the
figure determined in Step (2). Step (1): $400,000 x 50% = $200,000
We will pay the amount determined in Step (3) or (the minimum amount of insurance to
the limit of insurance, whichever is less. For the meet your Coinsurance requirements)
remainder, you will either have to rely on other Step (2): $150,000 ÷ $200,000 = .75
insurance or absorb the loss yourself.
Step (3): $80,000 x .75 = $60,000
In determining operating expenses for the purpose
We will pay no more than $60,000. The remaining
of applying the Coinsurance condition, the
$20,000 is not covered.
following expenses, if applicable, shall be
deducted from the total of all operating expenses: Example 2 (Adequate Insurance)
(1) Prepaid freight
- outgoing;
When: The Net Income and operating
(2) Returns and allowances; expenses for the 12 months
following the inception, or last
(3) Discounts;
previous anniversary date, of
(4) Bad debts;
this policy at the described
(5) Collection expenses; premises would have been: $400,000
(6) Cost of raw stock and factory supplies The Coinsurance percentage is: 50%
consumed (including transportation The Limit of Insurance is: $200,000
charges);
The amount of loss is: $ 80,000
(7) Cost of merchandise sold (including
The minimum amount of insurance to meet your
transportation charges);
Coinsurance requirement is $200,000 ($400,000 x
(8) Cost of other supplies consumed 50%). Therefore, the Limit of Insurance in this
(including transportation charges); example is adequate and no penalty applies. We will
(9) Cost of services purchased from pay no more than $80,000 (amount of loss).
outsiders (not employees) to resell, that This condition does not apply to Extra Expense
do not continue under contract; Coverage.
(10) Power, heat and refrigeration expenses E. Optional Coverages
that do not continue under contract (if
If shown as applicable in the Declarations, the
Form CP 15 11 is attached);
following Optional Coverages apply separately to
(11) All payroll expenses or the amount of each item.
payroll expense excluded (if Form CP
1. Maximum Period Of Indemnity
15 10 is attached); and
a. The Additional Condition, Coinsurance,
(12) Special deductions for mining properties
does not apply to this Coverage Form at the
(royalties unless specifically included in
described premises to which this Optional
coverage; actual depletion commonly
Coverage applies.
known as unit or cost depletion
- not
percentage depletion; welfare and
retirement fund charges based on
tonnage; hired trucks).
CP 00 30 10 12 © Insurance Services Office, Inc.,2011 Page 7of 9
- b. The most we will pay for the total of (b) Estimated for the 12 months
Business Income loss and Extra Expense is immediately following the inception
the lesser of: of this Optional Coverage.
(1) The amount of loss sustained and (2) The Declarations must indicate that the
expenses incurred during the 120 days Business Income Agreed Value Optional
immediately following the beginning of Coverage applies, and an Agreed Value
the "period of restoration"; or must be shown in the Declarations. The
Agreed Value should be at least equal
(2) The Limit Of Insurance shown in the
to:
Declarations.
(a) The Coinsurance percentage shown
2. Monthly Limit Of Indemnity
in the Declarations; multiplied by
a. The Additional Condition, Coinsurance,
(b) The amount of Net Income and
does not apply to this Coverage Form at the
operating expenses for the following
described premises to which this Optional
12 months you report on the Work
Coverage applies.
Sheet.
b. The most we will pay for loss of Business
b. The Additional Condition, Coinsurance, is
Income in each period of 30 consecutive
suspended until:
days after the beginning of the "period of
restoration" is: (1) 12 months after the effective date of this
Optional Coverage; or
(1) The Limit of Insurance, multiplied by
(2) The expiration date of this policy;
(2) The fraction shown in the Declarations
for this Optional Coverage. whichever occurs first.
Example c. We will reinstate the Additional Condition,
Coinsurance, automatically if you do not
When: The Limit of Insurance is: $ 120,000
submit a new Work Sheet and Agreed
The fraction shown in the Value:
Declarations for this Optional
(1) Within 12 months of the effective date of
Coverage is: 1/4
this Optional Coverage; or
The most we will pay for loss in
(2) When you request a change in your
each period of 30 consecutive
Business Income Limit of Insurance.
days is: $ 30,000
d. If the Business Income Limit of Insurance is
($120,000 x 1/4 = $30,000)
less than the Agreed Value, we will not pay
If, in this example, the actual
more of any loss than the amount of loss
amount of loss is:
multiplied by:
Days 1
- 30: $ 40,000
(1) The Business Income Limit of
Days 31
- 60: $ 20,000 Insurance; divided by
Days 61
- 90: $ 30,000 (2) The Agreed Value.
$ 90,000
Example
We will pay:
When: The Limit of Insurance is: $100,000
Days 1
- 30: $ 30,000
The Agreed Value is: $200,000
Days 31
- 60: $ 20,000
The amount of loss is: $ 80,000
Days 61
- 90: $ 30,000
Step (1): $100,000 ÷$200,000 = .50
$ 80,000
Step (2): .50 x $80,000 = $40,000
The remaining $10,000 is not covered.
We will pay $40,000. The remaining $40,000 is not
3. Business Income Agreed Value
covered.
a. To activate this Optional Coverage:
4. Extended Period Of Indemnity
(1) A Business Income Report/Work Sheet
Under Paragraph A.5.c., Extended Business
must be submitted to us and must show
Income, the number 60 in Subparagraphs
financial data for your "operations":
(1)(b) and (2)(b) is replaced by the number
(a) During the 12 months prior to the
shown in the Declarations for this Optional
date of the Work Sheet; and
Coverage.
Page 8 of 9 © Insurance Services Office, Inc.,2011 CP 00 30 10 12
- F. Definitions (2) Requires any insured or others to test
for, monitor, clean up, remove, contain,
1. "Finished stock" means stock you have
treat, detoxify or neutralize, or in any
manufactured.
way respond to, or assess the effects of
"Finished stock" also includes whiskey and "pollutants".
alcoholic products being aged, unless there is
The expiration date of this policy will not cut
a Coinsurance percentage shown for Business
short the "period of restoration".
Income in the Declarations.
4. "Pollutants" means any solid, liquid, gaseous or
"Finished stock" does not include stock you
thermal irritant or contaminant, including
have manufactured that is held for sale on the
smoke, vapor, soot, fumes, acids, alkalis,
premises of any retail outlet insured under this
chemicals and waste. Waste includes materials
Coverage Part.
to be recycled, reconditioned or reclaimed.
2. "Operations" means:
5. "Rental Value" means Business Income that
a. Your business activities occurring at the consists of:
described premises; and
a. Net Income (Net Profit or Loss before
b. The tenantability of the described premises, income taxes) that would have been earned
if coverage for Business Income Including or incurred as rental income from tenant
"Rental Value" or "Rental Value" applies. occupancy of the premises described in the
3. "Period of restoration" means the period of time Declarations as furnished and equipped by
that: you, including fair rental value of any
portion of the described premises which is
a. Begins:
occupied by you; and
(1) 72 hours after the time of direct physical
b. Continuing normal operating expenses
loss or damage for Business Income
incurred in connection with that premises,
Coverage; or
including:
(2) Immediately after the time of direct
(1) Payroll; and
physical loss or damage for Extra
Expense Coverage; (2) The amount of charges which are the
legal obligation of the tenant(s) but
caused by or resulting from any Covered
would otherwise be your obligations.
Cause of Loss at the described premises;
and 6. "Suspension" means:
b. Ends on the earlier of: a. The slowdown or cessation of your
business activities; or
(1) The date when the property at the
described premises should be repaired, b. That a part or all of the described premises
rebuilt or replaced with reasonable is rendered untenantable, if coverage for
speed and similar quality; or Business Income Including "Rental Value"
or "Rental Value" applies.
(2) The date when business is resumed at a
new permanent location.
"Period of restoration" does not include any
increased period required due to the
enforcement of or compliance with any
ordinance or law that:
(1) Regulates the construction, use or
repair, or requires the tearing down, of
any property; or
CP 00 30 10 12 © Insurance Services Office, Inc.,2011 Page 9of 9

## Definitions

**Business Income**: the:
(a) The portion of the building which you
a.

**Continuing normal operating expenses prem**: es described in the
incurred, including payroll.

**For manufacturing r**: ks, Net Income includes greater (with respect to loss of or
the net sales value of production.

**Coverage**: provided as described and limited
vehicle); and
below for one or more of the following options
for which a Limit Of Insurance is shown in the (c) Any area within the building or at the
Declarations: described premises, if that area
services, or is used to gain access
(1) Business Income Including "Rental
to, the portion of the building which
Value".

**Extra Expense Coverage**: provided at the
(3) "Rental Value".

**If Income Coverage applies at that prem**: es.

**Extra Expense means necessary expenses
Income will**: "Rental Value" only.

**Declarations and for which a Business
replacement premises or temporary
Income Limit Of Insurance**: shown in the
locations, including relocation expenses
Declarations.

**Civil Authority
We will also pay Extra Expense to repair or
In th**: Additional Coverage, Civil Authority,
replace property, but only to the extent it
the described premises are premises to
reduces the amount of loss that otherwise
which this Coverage Form applies, as
would have been payable under this
shown in the Declarations.

**Exclusions And
damage to property other than property at
Limitations
the described prem**: es, we will pay for the
See applicable Causes Of Loss form as shown actual loss of Business Income you sustain
in the Declarations.

**Interruption Of
to the described prem**: es, provided that
Computer Operations
both of the following apply:
a.

**The action of civil authority is taken in
when action**: taken to avoid or minimize a
response to dangerous physical
"suspension" of "operations" caused by
conditions resulting from the damage or
destruction or corruption of electronic data,
continuation of the Covered Cause of
or any loss or damage to electronic data,
Loss that caused the damage, or the
except as provided under the Additional
action is taken to enable a civil authority
Coverage, Interruption Of Computer
to have unimpeded access to the
Operations.

**Electronic data**: information, facts or
Civil Authority Coverage for Business
computer programs stored as or on,
Income will begin 72 hours after the time of
created or used on, or transmitted to or
the first action of civil authority that prohibits
from computer software (including systems
access to the described premises and will
and applications software), on hard or
apply for a period of up to four consecutive
floppy disks, CD-ROMs, tapes, drives, cells,
weeks from the date on which such
data processing devices or any other
coverage began.

**This Additional Limitation does not apply
whichever**: later.

**Extended Business Income
does not apply to loss of Business
We will pay for the actual loss of Business
Income incurred as a result of
Income you sustain and necessary Extra
unfavorable business conditions caused
Expense you incur due to direct physical
by the impact of the Covered Cause of
loss or damage at the described premises
Loss in the area where the described
caused by or resulting from any Covered
prem**: es are located.

**Alterations or additions to ex**: ting caused by or resulting from any Covered
buildings or structures; and Cause of Loss.

**Begins on the date property**: If such direct physical loss or damage actually repaired, rebuilt or replaced
delays the start of "operations", the "period and tenantability is restored; and
of restoration" for Business Income (b) Ends on the earlier of:
Coverage will begin on the date
(i) The date you could restore tenant
"operations" would have begun if the direct
occupancy, with reasonable
physical loss or damage had not occurred.

**Rental would have ex**: ted if no direct
Value" physical loss or damage had
occurred; or
If the necessary "suspension" of your
"operations" produces a Business (ii) 60 consecutive days after the
Income loss payable under this policy, date determined in (2)(a) above.

**The date you could restore your
described prem**: es caused by or
"operations", with reasonable
resulting from any Covered Cause of
speed, to the level which would
Loss.

**Under th**: Additional Coverage,
had occurred; or electronic data has the meaning
(ii) 60 consecutive days after the described under Additional Limitation –
date determined in (1)(a) above.

**Subject to all provisions of th**: (4) The most we will pay under this
Additional Coverage, you may extend Additional Coverage, Interruption Of
the insurance that applies to Business Computer Operations, is $2,500 (unless
Income and Extra Expense to apply to a a higher limit is shown in the
"suspension" of "operations" caused by Declarations) for all loss sustained and
an interruption in computer operations expense incurred in any one policy year,
due to destruction or corruption of regardless of the number of
electronic data due to a Covered Cause interruptions or the number of premises,
of Loss.

**Additional If loss payment relating to the first
Coverage when the Additional Limitation interruption does not exhaust th**: – Interruption Of Computer Operations amount, then the balance is available for
does not apply based on Paragraph loss or expense sustained or incurred as
A.

**With respect to the coverage provided
the end of a policy year does not
under th**: Additional Coverage, the
increase the amount of insurance in the
Covered Causes of Loss are subject to
next policy year.

**Th**: Additional Coverage, Interruption
(b) If the Causes Of Loss – Broad Form Of Computer Operations, does not apply
applies, coverage under this to loss sustained or expense incurred
Additional Coverage, Interruption Of after the end of the "period of
Computer Operations, includes restoration", even if the amount of
Collapse as set forth in that form.

**If the Causes Of Loss form**: been exhausted.

**The most we will pay under th**: Extension,
damage or destroy any part of the
for the sum of Business Income loss and
system or disrupt its normal
Extra Expense incurred, is $100,000 at
operation.

**But there**: no coverage
each location, unless a higher limit is shown
for an interruption related to
in the Declarations.

**Insurance under th**: Extension for each
(including electronic data) by any
newly acquired location will end when any
employee, including a temporary or
of the following first occurs:
leased employee, or by an entity
retained by you or for you to inspect, (1) This policy expires;
design, install, maintain, repair or
replace that system.

**Include a
not apply to th**: Extension.

**Th**: will not
increase the Limit of Insurance.

**The amounts of insurance stated in the from a cause of loss that**: not a
Interruption Of Computer Operations Additional Covered Cause of Loss.

**Appraisal
permit us to make copies from your
If we and you d**: agree on the amount of Net books and records.

**In th**: event, each party
investigate the claim.

**You must do this
will select a competent and impartial appra**: er.

**We will
The two appra**: ers will select an umpire.

**The appra**: ers will state separately
the amount of Net Income and operating (8) If you intend to continue your business,
expense or amount of loss.

**A dec**: ion agreed to by any two will be b.

**Pay its chosen appra**: er; and insured and at such times as may be
reasonably required, about any matter
b.

**Bear the other expenses of the appraisal
relating to th**: insurance or the claim,
and umpire equally.

**In
If there is an appra**: al, we will still retain our the event of an examination, an insured's
right to deny the claim.

**The likely Net Income of the business if
described prem**: es or elsewhere.

**An appra**: al award has been made.

**If a Coinsurance percentage**: shown in the
b.

**Income**: less than:
physical loss or damage had occurred.

**Any Extra Expense that**: paid for by
expenses,
other insurance, except for insurance
that is written subject to the same that would have been earned or incurred (had
plan, terms, conditions and no loss occurred) by your "operations" at the
provisions as this insurance; and described premises for the 12 months following
the inception, or last previous anniversary date,
(2) Necessary expenses that reduce the
of this policy (whichever is later).

**Business Income loss that otherw**: e
would have been incurred.

**Coinsurance
th**: policy at the described
percentage;
premises would have been: $400,000
Step (2): Divide the Limit of Insurance for the
The Coinsurance percentage is: 50%
described premises by the figure
The Limit of Insurance is: $150,000
determined in Step (1); and
The amount of loss is: $ 80,000
Step (3): Multiply the total amount of loss by the
figure determined in Step (2).

**Cost of raw stock and factory supplies The Coinsurance percentage**: : 50%
consumed (including transportation The Limit of Insurance is: $200,000
charges);
The amount of loss is: $ 80,000
(7) Cost of merchandise sold (including
The minimum amount of insurance to meet your
transportation charges);
Coinsurance requirement is $200,000 ($400,000 x
(8) Cost of other supplies consumed 50%).

**Limit of Insurance in th**: (including transportation charges); example is adequate and no penalty applies.

**Th**: condition does not apply to Extra Expense
do not continue under contract; Coverage.

**Special deductions for mining properties
does not apply to th**: Coverage Form at the
(royalties unless specifically included in
described premises to which this Optional
coverage; actual depletion commonly
Coverage applies.

**Business Income loss and Extra Expense**: immediately following the inception
the lesser of: of this Optional Coverage.

**The amount of Net Income and
does not apply to this Coverage Form at the
operating expenses for the following
described premises to which th**: Optional
12 months you report on the Work
Coverage applies.

**The expiration date of th**: policy;
(2) The fraction shown in the Declarations
for this Optional Coverage.

**The Limit of Insurance**: : $ 120,000
submit a new Work Sheet and Agreed
The fraction shown in the Value:
Declarations for this Optional
(1) Within 12 months of the effective date of
Coverage is: 1/4
this Optional Coverage; or
The most we will pay for loss in
(2) When you request a change in your
each period of 30 consecutive
Business Income Limit of Insurance.

**If the Business Income Limit of Insurance**: ($120,000 x 1/4 = $30,000)
less than the Agreed Value, we will not pay
If, in this example, the actual
more of any loss than the amount of loss
amount of loss is:
multiplied by:
Days 1–30: $ 40,000
(1) The Business Income Limit of
Days 31–60: $ 20,000 Insurance; divided by
Days 61–90: $ 30,000 (2) The Agreed Value.

**The Limit of Insurance**: : $100,000
Days 1–30: $ 30,000
The Agreed Value is: $200,000
Days 31–60: $ 20,000
The amount of loss is: $ 80,000
Days 61–90: $ 30,000
Step (1): $100,000 ÷$200,000 = .

**To activate th**: Optional Coverage:
4.

**Declarations for th**: Optional
date of the Work Sheet; and
Coverage.

