## Árbol: Seguro de Propiedad en Puerto Rico

**1.0 ¿Su propiedad está ubicada en Puerto Rico?**
   1.1 SÍ → 2.0
   1.2 NO → No aplica. No se necesita cobertura.

**2.0 ¿Qué tipo de riesgo enfrenta?**
   2.1 ¿Está preocupado por un huracán?
      2.1.1 SÍ → 3.0
      2.1.2 NO → 4.0

**3.0 Cobertura por Huracán**
   3.1 ¿Su propiedad está construida en un área de alto riesgo de huracán? (Considerar zonas de inundación y proximidad a la costa)
      3.1.1 SÍ → 4.1
      3.1.2 NO → 4.2

   3.1.1 Cobertura mínima: $250,000 para daños por viento y agua.
   3.1.2 Cobertura mínima: $150,000 para daños por viento y agua.

**4.0 Cobertura por Terremoto**
   4.1 ¿Su propiedad está en una zona sísmicamente activa de Puerto Rico? (Considerar áreas montañosas y zonas costeras)
      4.1.1 SÍ → 4.2
      4.1.2 NO → 4.3

   4.2 Cobertura mínima: $100,000 para daños por terremoto.
   4.3 Cobertura:  La cobertura por terremotos es limitada en Puerto Rico.  Se recomienda consultar con un agente de seguros para opciones adicionales.  Cobertura mínima: $50,000.

**IMPORTANTE:**  Este árbol de decisión es una guía simplificada.  Es crucial hablar con un agente de seguros en Puerto Rico para obtener una cobertura adecuada a sus necesidades específicas.  Considerar los riesgos de huracanes y terremotos al elegir su póliza.
