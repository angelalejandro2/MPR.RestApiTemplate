## Árbol de Decisión: Seguro para Residentes de Puerto Rico

**IMPORTANTE:** Este árbol de decisión simplificado ayuda a entender los riesgos cubiertos por un seguro.  Consulta con un agente de seguros para obtener asesoramiento personalizado.

## Árbol: [Tipo]

**1.0 ¿Vives en Puerto Rico?**
    1.1 SÍ → 2.0
    1.2 NO → No aplica.  Este árbol de decisión es solo para residentes de Puerto Rico.

**2.0 ¿Qué tipo de riesgo?**
    2.1 ¿El riesgo es un HURACÁN?
        2.1.1 SÍ → 3.0
        2.1.2 NO → 4.0

**3.0 Cobertura por HURACÁN:**
    3.1 ¿La cobertura es para daños a la casa?
        3.1.1 SÍ → Cobertura: $10,000 - $25,000 (dependiendo de la antigüedad y construcción)
        3.1.2 NO → 3.2
    3.2 ¿La cobertura es para daños a objetos dentro de la casa?
        3.2.1 SÍ → Cobertura: $5,000 - $10,000 (para muebles, electrodomésticos, etc.)
        3.2.2 NO → No aplica.  La cobertura es solo para daños estructurales.

**4.0 Cobertura por TERREMOTO:**
    4.1 ¿La cobertura es para daños a la casa?
        4.1.1 SÍ → Cobertura: $5,000 - $15,000 (dependiendo de la construcción)
        4.1.2 NO → 4.2
    4.2 ¿La cobertura es para daños a objetos dentro de la casa?
        4.2.1 SÍ → Cobertura: $2,000 - $5,000 (para muebles, electrodomésticos, etc.)
        4.2.2 NO → No aplica. La cobertura es solo para daños estructurales.

**IMPORTANTE:**  Estos montos son ejemplos.  El costo de la cobertura dependerá de la póliza específica y de la evaluación del riesgo.  Es crucial hablar con un agente de seguros para obtener una cotización precisa.
