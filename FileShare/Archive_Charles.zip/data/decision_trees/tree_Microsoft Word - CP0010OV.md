## Árbol: Análisis de Formulario de Seguro

**1.0 ¿Su casa está en Puerto Rico?**
   1.1 SÍ → 2.0
   1.2 NO → Fin del análisis. No aplica.

**2.0 ¿Qué riesgo principal enfrenta?**
   2.1 ¿Es probable un huracán en su zona?
      2.1.1 SÍ → 3.0 (Cobertura Huracán)
      2.1.2 NO → 4.0 (Considerar Terremotos)
   2.2 ¿Es posible un terremoto en su zona?
      2.2.1 SÍ → 4.0 (Cobertura Terremoto)
      2.2.2 NO → Fin del análisis. No aplica.

**3.0 Cobertura Huracán (Si es huracán)**
   3.1 Monto Máximo de Cobertura por Huracán: $250,000
   3.2  Esto cubre daños por:
       * Viento fuerte
       * Inundaciones causadas por el huracán
       * Daños a la estructura de su casa

**4.0 Cobertura Terremoto (Si es terremoto)**
   4.1 Monto Máximo de Cobertura por Terremoto: $100,000
   4.2 Esto cubre daños a la estructura de su casa debido a un temblor.
   4.3  **Importante:** La cobertura de terremotos en Puerto Rico es limitada.  Verifique cuidadosamente los detalles.
