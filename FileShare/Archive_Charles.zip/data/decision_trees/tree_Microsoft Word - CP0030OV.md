## Árbol de Decisión: Seguro para Residentes de Puerto Rico

**¡Importante!** Este árbol de decisión es una guía simplificada. Consulta con un agente de seguros para obtener asesoramiento personalizado.

## Árbol: [Tipo de Riesgo]
1.0 ¿Su casa está en Puerto Rico?
    1.1 SÍ → 2.0
    1.2 NO → No necesita cobertura.

2.0 ¿Qué riesgo principal?
    2.1 ¿Es probable un HURACANE?
        2.1.1 SÍ → Cobertura: $500,000 (Para daños a la propiedad y pérdida de ingresos).
        2.1.2 NO → 3.0
    2.2 ¿Es posible un TERREMOTO?
        2.2.1 SÍ → Cobertura: $100,000 (Para daños a la propiedad).
        2.2.2 NO → 4.0

4.0 ¿Necesita cobertura adicional?
    4.1 ¿Su casa está cerca de la costa? →  Considere una cobertura adicional para inundaciones. (Monto no especificado)
    4.2 NO →  Cobertura básica para daños por huracán y terremoto.

---

**Notas Importantes:**

*   **Monto de Cobertura:** Los montos son ejemplos y pueden variar según la póliza.
*   **Inundaciones:** Las inundaciones no están generalmente cubiertas por las pólizas de seguro estándar.
*   **Terremotos:** La cobertura de terremotos en Puerto Rico suele ser limitada.
*   **Revisión:** Revise su póliza de seguro regularmente para asegurarse de que sigue siendo adecuada para sus necesidades.

**¡Recuerde!**  Este árbol de decisión es una guía básica. Hablar con un agente de seguros en Puerto Rico es crucial para entender completamente sus opciones y necesidades.
