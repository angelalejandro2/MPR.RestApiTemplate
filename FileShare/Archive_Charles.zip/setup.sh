#!/bin/bash

# 🇵🇷 Insurance Claim Processing System - Setup Script
# Automated installation for Puerto Rico insurance processing

set -e  # Exit on any error

echo "🇵🇷 Setting up Insurance Claim Processing System..."
echo "======================================================"

# Check Python version
echo "🔍 Checking Python version..."
python_version=$(python3 --version 2>&1 | awk '{print $2}' | cut -d. -f1,2)
required_version="3.8"

if ! python3 -c "import sys; exit(0 if sys.version_info >= (3,8) else 1)" 2>/dev/null; then
    echo "❌ Error: Python 3.8+ required. Found: $python_version"
    echo "Please install Python 3.8 or higher and try again."
    exit 1
fi
echo "✅ Python $python_version - OK"

# Create virtual environment
echo "🔧 Creating virtual environment..."
if [ ! -d "venv" ]; then
    python3 -m venv venv
    echo "✅ Virtual environment created"
else
    echo "✅ Virtual environment already exists"
fi

# Activate virtual environment
echo "🔧 Activating virtual environment..."
source venv/bin/activate

# Upgrade pip
echo "🔧 Upgrading pip..."
pip install --upgrade pip

# Install requirements
echo "📦 Installing Python dependencies..."
pip install -r requirements.txt
echo "✅ Python dependencies installed"

# Create data directories
echo "📁 Creating data directories..."
mkdir -p data/input_forms
mkdir -p data/form_results
mkdir -p data/question_results
mkdir -p data/decision_trees
mkdir -p data/qa_reports
mkdir -p logs
echo "✅ Data directories created"

# Check if Ollama is installed
echo "🔍 Checking Ollama installation..."
if command -v ollama &> /dev/null; then
    echo "✅ Ollama is already installed"
    
    # Check if Ollama is running
    if curl -s http://localhost:11434/api/tags > /dev/null 2>&1; then
        echo "✅ Ollama is running"
    else
        echo "⚠️  Starting Ollama service..."
        ollama serve &
        sleep 3
        
        if curl -s http://localhost:11434/api/tags > /dev/null 2>&1; then
            echo "✅ Ollama service started"
        else
            echo "⚠️  Please start Ollama manually: ollama serve"
        fi
    fi
    
    # Check if required model is installed
    echo "🔍 Checking for required model (gemma3:4b)..."
    if ollama list | grep -q "gemma3:4b"; then
        echo "✅ Model gemma3:4b is already installed"
    else
        echo "📥 Installing model gemma3:4b (this may take a few minutes)..."
        ollama pull gemma3:4b
        echo "✅ Model gemma3:4b installed"
    fi
    
else
    echo "❌ Ollama not found. Installing Ollama..."
    
    # Install Ollama
    curl -fsSL https://ollama.ai/install.sh | sh
    
    # Start Ollama
    echo "🔧 Starting Ollama service..."
    ollama serve &
    sleep 5
    
    # Install required model
    echo "📥 Installing model gemma3:4b..."
    ollama pull gemma3:4b
    echo "✅ Ollama and model installed"
fi

# Create sample .env file if it doesn't exist
if [ ! -f ".env" ]; then
    echo "📝 Creating sample .env file..."
    cat > .env << EOF
# Insurance Claim Processing System Configuration
# Optional: Override defaults if needed

# Ollama Configuration
OLLAMA_BASE_URL=http://localhost:11434
OLLAMA_MODEL=gemma3:4b

# Input/Output Directories (optional)
INPUT_FORMS_DIR=./data/input_forms
OUTPUT_DIR=./data

# Processing Options
BATCH_SIZE=4
ENABLE_GPU=true
EOF
    echo "✅ Sample .env file created"
fi

# Set proper permissions
echo "🔧 Setting permissions..."
chmod +x main.py
chmod -R 755 data/
echo "✅ Permissions set"

# Run a quick test
echo "🧪 Running system test..."
python3 -c "
import sys
import os
sys.path.append('.')

try:
    from src.config.constants import OUTPUT_DIRECTORIES
    from src.utils.ollama_check import check_ollama_connection
    
    # Test Ollama connection
    is_connected, message = check_ollama_connection()
    if is_connected:
        print('✅ Ollama connection test: PASSED')
    else:
        print(f'⚠️  Ollama connection test: {message}')
        
    # Test imports
    from langchain_ollama import OllamaLLM
    print('✅ LangChain imports: PASSED')
    
    print('✅ System test: PASSED')
    
except Exception as e:
    print(f'⚠️  System test warning: {e}')
    print('This may be normal - try running the full system.')
"

echo ""
echo "🎉 Setup completed successfully!"
echo "======================================================"
echo ""
echo "🚀 Quick Start Commands:"
echo ""
echo "1. Add your insurance policy files to: ./data/input_forms/"
echo "   Example: cp my_policy.pdf ./data/input_forms/"
echo ""
echo "2. Run the processing system:"
echo "   source venv/bin/activate"
echo "   python main.py --simple"
echo ""
echo "3. Check results in: ./data/decision_trees/FINAL_TREE.md"
echo ""
echo "📋 For more information, see README.md"
echo "🇵🇷 ¡Sistema listo para procesar pólizas de Puerto Rico!"
echo ""